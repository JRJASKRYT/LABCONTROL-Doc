# LABCONTROL – Iteración 1 (HU-01 a HU-07)

Blazor Web App (.NET 10, Interactive Server) + SQLite + Entity Framework Core. Grupo SQLitos.

## Cómo ejecutar
1. Abrir `LABCONTROL.slnx` (o `LABCONTROL.sln`) en Visual Studio (o `cd BlazorAppLab && dotnet run`).
2. La primera vez se restauran los paquetes NuGet y se crea `labcontrol.db` con datos de prueba.

## Usuarios de prueba (clave: Labcontrol123!)
| Rol | Correo |
|---|---|
| Administrador | admin@labcontrol.test |
| Encargado | encargado@labcontrol.test |
| Docente | docente@labcontrol.test |
| Estudiante | estudiante@labcontrol.test |

## Historias cubiertas
| HU | Dónde |
|---|---|
| HU-01 Inicio de sesión | `/login` (cookie + roles) |
| HU-02 Disponibilidad | `/disponibilidad` |
| HU-03 Horarios | `/horarios` |
| HU-04 Info de laboratorio | `/laboratorios` |
| HU-05 Solicitar uso | `/solicitudes/nueva` (Estudiante/Docente) |
| HU-06 Mis solicitudes | `/solicitudes` |
| HU-07 Estado de solicitud | columna Estado en `/solicitudes` (Pendiente/Aprobada/Rechazada) |

Aprobar/rechazar (HU-08) queda para la iteración 2.
