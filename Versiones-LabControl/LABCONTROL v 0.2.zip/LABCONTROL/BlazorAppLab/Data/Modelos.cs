using System.ComponentModel.DataAnnotations;

namespace BlazorAppLab.Data;

public static class Roles
{
    public const string Estudiante = "Estudiante";
    public const string Docente = "Docente";
    public const string Encargado = "Encargado";
    public const string Administrador = "Administrador";
}

public static class EstadosSolicitud
{
    public const string Pendiente = "Pendiente";
    public const string Aprobada = "Aprobada";
    public const string Rechazada = "Rechazada";
}

public static class EstadosLaboratorio
{
    public const string Disponible = "Disponible";
    public const string Mantenimiento = "Mantenimiento";
}

public static class Configuracion
{
    // Periodo académico vigente (simplificado para la iteración 1)
    public const string PeriodoActual = "2026-2";
}

public class Usuario
{
    public int Id { get; set; }
    [Required, MaxLength(120)] public string Nombre { get; set; } = "";
    [Required, MaxLength(120)] public string Correo { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    [Required, MaxLength(30)] public string Rol { get; set; } = Roles.Estudiante;
}

public class Laboratorio
{
    public int Id { get; set; }
    [Required, MaxLength(80)] public string Nombre { get; set; } = "";
    [MaxLength(120)] public string Ubicacion { get; set; } = "";
    public int Capacidad { get; set; }
    [MaxLength(30)] public string Estado { get; set; } = EstadosLaboratorio.Disponible;
    [MaxLength(300)] public string Descripcion { get; set; } = "";
    public List<Horario> Horarios { get; set; } = new();
}

public class Horario
{
    public int Id { get; set; }
    public int LaboratorioId { get; set; }
    public Laboratorio? Laboratorio { get; set; }
    [MaxLength(10)] public string Periodo { get; set; } = Configuracion.PeriodoActual;
    public DayOfWeek DiaSemana { get; set; }
    public TimeOnly HoraInicio { get; set; }
    public TimeOnly HoraFin { get; set; }
    [MaxLength(120)] public string Descripcion { get; set; } = "";
}

public class Solicitud
{
    public int Id { get; set; }
    public int UsuarioId { get; set; }
    public Usuario? Usuario { get; set; }
    public int LaboratorioId { get; set; }
    public Laboratorio? Laboratorio { get; set; }
    public DateOnly Fecha { get; set; }
    public TimeOnly HoraInicio { get; set; }
    public TimeOnly HoraFin { get; set; }
    [MaxLength(300)] public string Motivo { get; set; } = "";
    [MaxLength(20)] public string Estado { get; set; } = EstadosSolicitud.Pendiente;
    public DateTime FechaCreacion { get; set; } = DateTime.Now;
}
