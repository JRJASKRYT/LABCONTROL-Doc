using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.Data;

public class LabControlDbContext : DbContext
{
    public LabControlDbContext(DbContextOptions<LabControlDbContext> options) : base(options) { }

    public DbSet<Usuario> Usuarios => Set<Usuario>();
    public DbSet<Laboratorio> Laboratorios => Set<Laboratorio>();
    public DbSet<Horario> Horarios => Set<Horario>();
    public DbSet<Solicitud> Solicitudes => Set<Solicitud>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Usuario>().HasIndex(u => u.Correo).IsUnique();
    }
}
