using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.Data;

public record ResultadoDisponibilidad(Laboratorio Laboratorio, bool Disponible, string Detalle);

public static class Disponibilidad
{
    private static bool Traslapa(TimeOnly a1, TimeOnly a2, TimeOnly b1, TimeOnly b2) => a1 < b2 && b1 < a2;

    /// <summary>
    /// Un laboratorio está disponible si no está en mantenimiento, no tiene clase (horario del periodo)
    /// en ese día/hora y no tiene otra solicitud pendiente/aprobada que se traslape.
    /// </summary>
    public static async Task<List<ResultadoDisponibilidad>> ConsultarAsync(
        LabControlDbContext db, DateOnly fecha, TimeOnly inicio, TimeOnly fin, int? laboratorioId = null)
    {
        var labs = await db.Laboratorios.Include(l => l.Horarios).OrderBy(l => l.Nombre).ToListAsync();
        if (laboratorioId.HasValue) labs = labs.Where(l => l.Id == laboratorioId.Value).ToList();

        var solicitudes = (await db.Solicitudes.Where(s => s.Fecha == fecha).ToListAsync())
            .Where(s => s.Estado != EstadosSolicitud.Rechazada).ToList();

        var resultado = new List<ResultadoDisponibilidad>();
        foreach (var lab in labs)
        {
            if (lab.Estado != EstadosLaboratorio.Disponible)
            {
                resultado.Add(new(lab, false, $"Estado: {lab.Estado}"));
                continue;
            }

            var clase = lab.Horarios.FirstOrDefault(h => h.Periodo == Configuracion.PeriodoActual
                && h.DiaSemana == fecha.DayOfWeek && Traslapa(h.HoraInicio, h.HoraFin, inicio, fin));
            if (clase != null)
            {
                resultado.Add(new(lab, false, $"Ocupado por horario: {clase.Descripcion} ({clase.HoraInicio:HH\\:mm}-{clase.HoraFin:HH\\:mm})"));
                continue;
            }

            var sol = solicitudes.FirstOrDefault(s => s.LaboratorioId == lab.Id
                && Traslapa(s.HoraInicio, s.HoraFin, inicio, fin));
            if (sol != null)
            {
                resultado.Add(new(lab, false, $"Ya existe una solicitud {sol.Estado.ToLower()} ({sol.HoraInicio:HH\\:mm}-{sol.HoraFin:HH\\:mm})"));
                continue;
            }

            resultado.Add(new(lab, true, "Disponible"));
        }
        return resultado;
    }
}
