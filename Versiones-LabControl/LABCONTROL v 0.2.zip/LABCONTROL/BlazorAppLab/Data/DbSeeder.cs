using Microsoft.AspNetCore.Identity;

namespace BlazorAppLab.Data;

public static class DbSeeder
{
    public const string PasswordDemo = "Labcontrol123!";

    public static void Inicializar(LabControlDbContext db)
    {
        db.Database.EnsureCreated();
        if (db.Usuarios.Any()) return;

        var hasher = new PasswordHasher<Usuario>();
        Usuario Crear(string nombre, string correo, string rol)
        {
            var u = new Usuario { Nombre = nombre, Correo = correo, Rol = rol };
            u.PasswordHash = hasher.HashPassword(u, PasswordDemo);
            return u;
        }

        db.Usuarios.AddRange(
            Crear("Administrador", "admin@labcontrol.test", Roles.Administrador),
            Crear("Encargado Centro de Cómputo", "encargado@labcontrol.test", Roles.Encargado),
            Crear("Docente Demo", "docente@labcontrol.test", Roles.Docente),
            Crear("Estudiante Demo", "estudiante@labcontrol.test", Roles.Estudiante));

        Horario H(DayOfWeek d, int hi, int hf, string desc) => new()
        {
            DiaSemana = d,
            HoraInicio = new TimeOnly(hi, 0),
            HoraFin = new TimeOnly(hf, 0),
            Periodo = Configuracion.PeriodoActual,
            Descripcion = desc
        };

        db.Laboratorios.AddRange(
            new Laboratorio
            {
                Nombre = "Laboratorio 1", Ubicacion = "Bloque A, Piso 1", Capacidad = 30,
                Estado = EstadosLaboratorio.Disponible,
                Descripcion = "Laboratorio de programación con 30 equipos.",
                Horarios =
                {
                    H(DayOfWeek.Monday, 8, 10, "Programación I"),
                    H(DayOfWeek.Wednesday, 8, 10, "Programación I"),
                    H(DayOfWeek.Friday, 14, 16, "Base de Datos")
                }
            },
            new Laboratorio
            {
                Nombre = "Laboratorio 2", Ubicacion = "Bloque A, Piso 2", Capacidad = 25,
                Estado = EstadosLaboratorio.Disponible,
                Descripcion = "Laboratorio de redes y sistemas operativos.",
                Horarios =
                {
                    H(DayOfWeek.Tuesday, 10, 12, "Redes"),
                    H(DayOfWeek.Thursday, 10, 12, "Sistemas Operativos")
                }
            },
            new Laboratorio
            {
                Nombre = "Laboratorio 3", Ubicacion = "Bloque B, Piso 1", Capacidad = 20,
                Estado = EstadosLaboratorio.Mantenimiento,
                Descripcion = "Laboratorio en mantenimiento de equipos.",
            });

        db.SaveChanges();
    }
}
