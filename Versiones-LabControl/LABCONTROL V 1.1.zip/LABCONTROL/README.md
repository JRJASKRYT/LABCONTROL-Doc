# LABCONTROL — Sistema Web para la Gestión y Control de Laboratorios

Grupo SQLitos · Proyecto de Sistemas I · Centro de Cómputo Univalle La Paz

Estructura igual a la del proyecto de referencia (BlazorAppJorgeCA): cliente **Blazor WebAssembly** + **Web API** + librería **Shared** + base de datos **SQL Server** con script en `BaseDatos`.

| Proyecto | Qué contiene |
|---|---|
| `BlazorAppLab` | Cliente Blazor WebAssembly (páginas, layout, servicios que llaman a la API) |
| `BlazorAppLab.API` | Web API (controladores, modelos de EF Core, seguridad) |
| `ClassLibraryLab.Shared` | Clases `...CLS` compartidas entre cliente y API, constantes de roles y estados |
| `BaseDatos/bdlabcontrol.sql` | Script que crea la base `BDLABCONTROL`, sus tablas y datos de ejemplo |

## Cómo ejecutarlo (.NET 10 y SQL Server)

1. En SQL Server Management Studio abre y ejecuta **completo** `BaseDatos/bdlabcontrol.sql` (borra y vuelve a crear `BDLABCONTROL`).
2. Revisa la cadena de conexión `CadenaSQL` en `BlazorAppLab.API/appsettings.json` (por defecto usa `(localdb)\MSSQLLocalDB`; cámbiala si tu SQL Server es otro, por ejemplo `Server=localhost;...`). Debe ser la misma instancia donde ejecutaste el script.
3. Inicia los dos proyectos:
   - Visual Studio: abre `LABCONTROL.slnx` y usa el perfil de inicio **API + Web**, o
   - Doble clic en `INICIAR_TODO.bat`, o
   - Dos terminales: `dotnet run --project BlazorAppLab.API` y `dotnet run --project BlazorAppLab`.
4. API: `http://localhost:5333` (Swagger en `/swagger`) · Web: `http://localhost:5309`.
   Si cambias el puerto de la API, actualiza `urlApi` en `BlazorAppLab/Program.cs`.

### Usuarios de prueba (contraseña de todos: `Lab2026*`)

| Usuario | Rol |
|---|---|
| admin | Administrador |
| encargado | Encargado |
| tecnico | Técnico |
| docente | Docente |
| estudiante | Estudiante |

## Historias de usuario → dónde están

| HU | Funcionalidad | Página (ruta) | Roles |
|----|---------------|---------------|-------|
| HU-01 | Inicio de sesión y acceso por rol | `/login` | Todos |
| HU-02 | Consultar disponibilidad por fecha y horario | `/disponibilidad` | Todos |
| HU-03 | Consultar horarios de un laboratorio y periodo | `/horarios` | Todos |
| HU-04 | Ficha del laboratorio | `/laboratorios` | Todos |
| HU-05 | Solicitar uso (valida datos y disponibilidad; estado inicial Pendiente) | `/nueva-solicitud` | Docente, Estudiante |
| HU-06 | Consultar mis solicitudes (solo las del usuario) | `/mis-solicitudes` | Docente, Estudiante |
| HU-07 | Estado de la solicitud (Pendiente / Aprobada / Rechazada) | `/mis-solicitudes` | Docente, Estudiante |
| HU-08 | Aprobar o rechazar solicitudes | `/gestion-solicitudes` | Encargado, Administrador |
| HU-09 | Registrar utilización de laboratorio/equipo | `/utilizacion` | Encargado, Administrador |
| HU-10 | Administrar laboratorios (y sus equipos) | `/admin-laboratorios` | Encargado, Administrador |
| HU-11 | Administrar horarios y periodos | `/admin-horarios` | Encargado, Administrador |
| HU-12 | Administrar usuarios y roles | `/admin-usuarios` | Administrador |
| HU-13 | Reportar incidencia | `/nueva-incidencia` | Todos |
| HU-14 | Consultar estado/detalle de incidencias | `/mis-incidencias` | Todos (propias; el personal autorizado ve todas) |
| HU-15 | Gestionar incidencias (estado, fecha de atención, observación técnica) | `/gestion-incidencias` | Encargado, Técnico, Administrador |
| HU-16 | Historial de solicitudes con filtros | `/historial-solicitudes` | Encargado, Administrador |
| HU-17 | Historial de incidencias con filtros | `/historial-incidencias` | Encargado, Administrador |
| HU-18 | Reportes de solicitudes, utilización e incidencias | `/reportes` | Encargado, Administrador |
| HU-19 | Notificaciones | `/notificaciones` (+ contador en el menú) | Todos |
| HU-20 | Indicadores y estadísticas | `/indicadores` | Encargado, Administrador |

## Seguridad (qué se hizo distinto a la referencia)

- La referencia valida el rol solo en el cliente. Aquí **la API también valida**: al iniciar sesión devuelve un token firmado (HMAC-SHA256) que el cliente envía en `Authorization: Bearer ...`. Cada endpoint usa `[Autorizar(Roles.X)]` (carpeta `Seguridad`), así que aunque alguien llame a la API directamente, no puede ver ni modificar lo que su rol no permite. El usuario que registra una solicitud o incidencia sale del token, no de lo que envíe el cliente.
- Las contraseñas se guardan con **PBKDF2-SHA256 + sal** (no SHA-256 simple). El script SQL ya trae los hashes de los usuarios de prueba.
- **Antes de entregar o publicar cambia `Seguridad:ClaveToken`** en `appsettings.json` por una clave larga y secreta propia.
- La sesión se guarda en el `sessionStorage` del navegador (sobrevive a F5 y se borra al cerrar la pestaña).

## Reglas de negocio

- Un laboratorio **no está disponible** si su estado no es *Disponible*, si choca con un horario de clase del periodo vigente, o si ya tiene una solicitud **aprobada** que se cruza.
- Al aprobar se vuelve a verificar la disponibilidad (evita reservas dobles). Rechazar exige una observación.
- Reportar una incidencia con equipo lo marca *En falla*; al pasar a *En atención* queda *En mantenimiento*; al *Resolverse* vuelve a *Operativo*.
- Notificaciones automáticas: nueva solicitud → encargados y administradores; solicitud resuelta → solicitante; nueva incidencia → encargados y técnicos; cambio de estado → quien la reportó.
- Baja lógica (estado *Inactivo*, columna `BHABILITADO`) en lugar de borrado físico, para conservar el historial. Solo los horarios se eliminan físicamente.

## Base de datos

Tablas: `TipoUsuario`, `Usuario`, `Laboratorio`, `Equipo`, `PeriodoAcademico`, `Horario`, `Solicitud`, `Utilizacion`, `Incidencia`, `Notificacion`, con llaves foráneas, índices únicos (usuario, correo, nombre de laboratorio, código de equipo) y `CHECK` para los estados. Los modelos de `BlazorAppLab.API/Models` siguen la nomenclatura del Scaffold de la referencia (`Iidusuario`, `Bhabilitado`...); si cambias la base puedes regenerarlos con `Scaffold-DbContext` como en la guía del docente.
