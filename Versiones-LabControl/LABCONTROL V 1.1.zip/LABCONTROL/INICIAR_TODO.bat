@echo off
setlocal
cd /d "%~dp0"

echo Iniciando API en http://localhost:5333 ...
start "LABCONTROL API" cmd /k "dotnet run --project "BlazorAppLab.API\BlazorAppLab.API.csproj" --launch-profile http"

timeout /t 3 /nobreak >nul

echo Iniciando WEB en http://localhost:5309 ...
start "LABCONTROL WEB" cmd /k "dotnet run --project "BlazorAppLab\BlazorAppLab.csproj" --launch-profile http"

timeout /t 5 /nobreak >nul
start "" "http://localhost:5309"
endlocal
