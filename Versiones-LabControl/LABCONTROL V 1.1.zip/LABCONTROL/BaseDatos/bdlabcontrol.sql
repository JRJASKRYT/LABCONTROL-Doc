﻿/* =========================================================
   BDLABCONTROL  -  LABCONTROL (Grupo SQLitos)
   Sistema Web para la Gestion y Control de Laboratorios del Centro de Computo.
   Script de creacion de la base de datos y datos iniciales.
   Ejecutar completo en SQL Server Management Studio.
   Usuarios de prueba (contrasena de todos: Lab2026*):
   admin, encargado, tecnico, docente, estudiante
   ========================================================= */

USE master
GO

IF DB_ID('BDLABCONTROL') IS NOT NULL
BEGIN
    ALTER DATABASE BDLABCONTROL SET SINGLE_USER WITH ROLLBACK IMMEDIATE
    DROP DATABASE BDLABCONTROL
END
GO

CREATE DATABASE BDLABCONTROL
GO

USE [BDLABCONTROL]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* ---------------- Tablas ---------------- */

CREATE TABLE [dbo].[TipoUsuario](
    [IIDTIPOUSUARIO] [int] IDENTITY(1,1) NOT NULL,
    [NOMBRE] [nvarchar](50) NOT NULL,
    [BHABILITADO] [int] NOT NULL CONSTRAINT [DF_TipoUsuario_BHABILITADO] DEFAULT (1),
    CONSTRAINT [PK_TipoUsuario] PRIMARY KEY CLUSTERED ([IIDTIPOUSUARIO] ASC)
)
GO

CREATE TABLE [dbo].[Usuario](
    [IIDUSUARIO] [int] IDENTITY(1,1) NOT NULL,
    [NOMBRECOMPLETO] [nvarchar](120) NOT NULL,
    [LOGIN] [nvarchar](50) NOT NULL,
    [CORREO] [nvarchar](120) NOT NULL,
    [PASSWORD] [nvarchar](200) NOT NULL,
    [IIDTIPOUSUARIO] [int] NOT NULL,
    [BHABILITADO] [int] NOT NULL CONSTRAINT [DF_Usuario_BHABILITADO] DEFAULT (1),
    [FECHAREGISTRO] [datetime2](0) NOT NULL CONSTRAINT [DF_Usuario_FECHAREGISTRO] DEFAULT (GETDATE()),
    CONSTRAINT [PK_Usuario] PRIMARY KEY CLUSTERED ([IIDUSUARIO] ASC)
)
GO

CREATE TABLE [dbo].[Laboratorio](
    [IIDLABORATORIO] [int] IDENTITY(1,1) NOT NULL,
    [NOMBRE] [nvarchar](100) NOT NULL,
    [UBICACION] [nvarchar](150) NOT NULL,
    [CAPACIDAD] [int] NOT NULL,
    [ESTADO] [nvarchar](20) NOT NULL CONSTRAINT [DF_Laboratorio_ESTADO] DEFAULT (N'Disponible'),
    [DESCRIPCION] [nvarchar](500) NULL,
    CONSTRAINT [PK_Laboratorio] PRIMARY KEY CLUSTERED ([IIDLABORATORIO] ASC)
)
GO

CREATE TABLE [dbo].[Equipo](
    [IIDEQUIPO] [int] IDENTITY(1,1) NOT NULL,
    [IIDLABORATORIO] [int] NOT NULL,
    [CODIGO] [nvarchar](30) NOT NULL,
    [NOMBRE] [nvarchar](100) NOT NULL,
    [ESTADO] [nvarchar](20) NOT NULL CONSTRAINT [DF_Equipo_ESTADO] DEFAULT (N'Operativo'),
    CONSTRAINT [PK_Equipo] PRIMARY KEY CLUSTERED ([IIDEQUIPO] ASC)
)
GO

CREATE TABLE [dbo].[PeriodoAcademico](
    [IIDPERIODO] [int] IDENTITY(1,1) NOT NULL,
    [NOMBRE] [nvarchar](50) NOT NULL,
    [FECHAINICIO] [date] NOT NULL,
    [FECHAFIN] [date] NOT NULL,
    [BVIGENTE] [int] NOT NULL CONSTRAINT [DF_PeriodoAcademico_BVIGENTE] DEFAULT (1),
    CONSTRAINT [PK_PeriodoAcademico] PRIMARY KEY CLUSTERED ([IIDPERIODO] ASC)
)
GO

CREATE TABLE [dbo].[Horario](
    [IIDHORARIO] [int] IDENTITY(1,1) NOT NULL,
    [IIDLABORATORIO] [int] NOT NULL,
    [IIDPERIODO] [int] NOT NULL,
    [DIA] [int] NOT NULL,
    [HORAINICIO] [time](0) NOT NULL,
    [HORAFIN] [time](0) NOT NULL,
    [ACTIVIDAD] [nvarchar](150) NULL,
    CONSTRAINT [PK_Horario] PRIMARY KEY CLUSTERED ([IIDHORARIO] ASC)
)
GO

CREATE TABLE [dbo].[Solicitud](
    [IIDSOLICITUD] [int] IDENTITY(1,1) NOT NULL,
    [IIDUSUARIO] [int] NOT NULL,
    [IIDLABORATORIO] [int] NOT NULL,
    [FECHA] [date] NOT NULL,
    [HORAINICIO] [time](0) NOT NULL,
    [HORAFIN] [time](0) NOT NULL,
    [MOTIVO] [nvarchar](300) NOT NULL,
    [ESTADO] [nvarchar](20) NOT NULL CONSTRAINT [DF_Solicitud_ESTADO] DEFAULT (N'Pendiente'),
    [FECHACREACION] [datetime2](0) NOT NULL CONSTRAINT [DF_Solicitud_FECHACREACION] DEFAULT (GETDATE()),
    [IIDUSUARIOGESTION] [int] NULL,
    [FECHAGESTION] [datetime2](0) NULL,
    [OBSERVACIONGESTION] [nvarchar](300) NULL,
    CONSTRAINT [PK_Solicitud] PRIMARY KEY CLUSTERED ([IIDSOLICITUD] ASC)
)
GO

CREATE TABLE [dbo].[Utilizacion](
    [IIDUTILIZACION] [int] IDENTITY(1,1) NOT NULL,
    [IIDUSUARIO] [int] NOT NULL,
    [IIDLABORATORIO] [int] NOT NULL,
    [IIDEQUIPO] [int] NULL,
    [FECHA] [datetime2](0) NOT NULL,
    [OBSERVACION] [nvarchar](300) NULL,
    [IIDUSUARIOREGISTRO] [int] NOT NULL,
    CONSTRAINT [PK_Utilizacion] PRIMARY KEY CLUSTERED ([IIDUTILIZACION] ASC)
)
GO

CREATE TABLE [dbo].[Incidencia](
    [IIDINCIDENCIA] [int] IDENTITY(1,1) NOT NULL,
    [IIDUSUARIO] [int] NOT NULL,
    [IIDLABORATORIO] [int] NOT NULL,
    [IIDEQUIPO] [int] NULL,
    [DESCRIPCION] [nvarchar](500) NOT NULL,
    [FECHAREPORTE] [datetime2](0) NOT NULL CONSTRAINT [DF_Incidencia_FECHAREPORTE] DEFAULT (GETDATE()),
    [ESTADO] [nvarchar](20) NOT NULL CONSTRAINT [DF_Incidencia_ESTADO] DEFAULT (N'Pendiente'),
    [FECHAATENCION] [datetime2](0) NULL,
    [OBSERVACIONTECNICA] [nvarchar](500) NULL,
    [IIDUSUARIOATENCION] [int] NULL,
    CONSTRAINT [PK_Incidencia] PRIMARY KEY CLUSTERED ([IIDINCIDENCIA] ASC)
)
GO

CREATE TABLE [dbo].[Notificacion](
    [IIDNOTIFICACION] [int] IDENTITY(1,1) NOT NULL,
    [IIDUSUARIO] [int] NOT NULL,
    [MENSAJE] [nvarchar](300) NOT NULL,
    [ENLACE] [nvarchar](100) NULL,
    [FECHA] [datetime2](0) NOT NULL CONSTRAINT [DF_Notificacion_FECHA] DEFAULT (GETDATE()),
    [BLEIDA] [int] NOT NULL CONSTRAINT [DF_Notificacion_BLEIDA] DEFAULT (0),
    CONSTRAINT [PK_Notificacion] PRIMARY KEY CLUSTERED ([IIDNOTIFICACION] ASC)
)
GO

/* ---------------- Llaves foraneas ---------------- */

ALTER TABLE [dbo].[Usuario]     ADD CONSTRAINT [FK_Usuario_TipoUsuario]      FOREIGN KEY ([IIDTIPOUSUARIO]) REFERENCES [dbo].[TipoUsuario]([IIDTIPOUSUARIO])
ALTER TABLE [dbo].[Equipo]      ADD CONSTRAINT [FK_Equipo_Laboratorio]       FOREIGN KEY ([IIDLABORATORIO]) REFERENCES [dbo].[Laboratorio]([IIDLABORATORIO])
ALTER TABLE [dbo].[Horario]     ADD CONSTRAINT [FK_Horario_Laboratorio]      FOREIGN KEY ([IIDLABORATORIO]) REFERENCES [dbo].[Laboratorio]([IIDLABORATORIO])
ALTER TABLE [dbo].[Horario]     ADD CONSTRAINT [FK_Horario_Periodo]          FOREIGN KEY ([IIDPERIODO])     REFERENCES [dbo].[PeriodoAcademico]([IIDPERIODO])
ALTER TABLE [dbo].[Solicitud]   ADD CONSTRAINT [FK_Solicitud_Usuario]        FOREIGN KEY ([IIDUSUARIO])     REFERENCES [dbo].[Usuario]([IIDUSUARIO])
ALTER TABLE [dbo].[Solicitud]   ADD CONSTRAINT [FK_Solicitud_Laboratorio]    FOREIGN KEY ([IIDLABORATORIO]) REFERENCES [dbo].[Laboratorio]([IIDLABORATORIO])
ALTER TABLE [dbo].[Solicitud]   ADD CONSTRAINT [FK_Solicitud_UsuarioGestion] FOREIGN KEY ([IIDUSUARIOGESTION]) REFERENCES [dbo].[Usuario]([IIDUSUARIO])
ALTER TABLE [dbo].[Utilizacion] ADD CONSTRAINT [FK_Utilizacion_Usuario]      FOREIGN KEY ([IIDUSUARIO])     REFERENCES [dbo].[Usuario]([IIDUSUARIO])
ALTER TABLE [dbo].[Utilizacion] ADD CONSTRAINT [FK_Utilizacion_Laboratorio]  FOREIGN KEY ([IIDLABORATORIO]) REFERENCES [dbo].[Laboratorio]([IIDLABORATORIO])
ALTER TABLE [dbo].[Utilizacion] ADD CONSTRAINT [FK_Utilizacion_Equipo]       FOREIGN KEY ([IIDEQUIPO])      REFERENCES [dbo].[Equipo]([IIDEQUIPO])
ALTER TABLE [dbo].[Utilizacion] ADD CONSTRAINT [FK_Utilizacion_Registro]     FOREIGN KEY ([IIDUSUARIOREGISTRO]) REFERENCES [dbo].[Usuario]([IIDUSUARIO])
ALTER TABLE [dbo].[Incidencia]  ADD CONSTRAINT [FK_Incidencia_Usuario]       FOREIGN KEY ([IIDUSUARIO])     REFERENCES [dbo].[Usuario]([IIDUSUARIO])
ALTER TABLE [dbo].[Incidencia]  ADD CONSTRAINT [FK_Incidencia_Laboratorio]   FOREIGN KEY ([IIDLABORATORIO]) REFERENCES [dbo].[Laboratorio]([IIDLABORATORIO])
ALTER TABLE [dbo].[Incidencia]  ADD CONSTRAINT [FK_Incidencia_Equipo]        FOREIGN KEY ([IIDEQUIPO])      REFERENCES [dbo].[Equipo]([IIDEQUIPO])
ALTER TABLE [dbo].[Incidencia]  ADD CONSTRAINT [FK_Incidencia_Atencion]      FOREIGN KEY ([IIDUSUARIOATENCION]) REFERENCES [dbo].[Usuario]([IIDUSUARIO])
ALTER TABLE [dbo].[Notificacion] ADD CONSTRAINT [FK_Notificacion_Usuario]    FOREIGN KEY ([IIDUSUARIO])     REFERENCES [dbo].[Usuario]([IIDUSUARIO])
GO

/* ---------------- Reglas de integridad ---------------- */

CREATE UNIQUE INDEX [UX_Usuario_Login]     ON [dbo].[Usuario]([LOGIN])
CREATE UNIQUE INDEX [UX_Usuario_Correo]    ON [dbo].[Usuario]([CORREO])
CREATE UNIQUE INDEX [UX_Laboratorio_Nombre] ON [dbo].[Laboratorio]([NOMBRE])
CREATE UNIQUE INDEX [UX_Equipo_Codigo]     ON [dbo].[Equipo]([CODIGO])
GO

ALTER TABLE [dbo].[Laboratorio] ADD CONSTRAINT [CK_Laboratorio_Estado] CHECK ([ESTADO] IN (N'Disponible', N'EnMantenimiento', N'Inactivo'))
ALTER TABLE [dbo].[Equipo]      ADD CONSTRAINT [CK_Equipo_Estado]      CHECK ([ESTADO] IN (N'Operativo', N'EnFalla', N'EnMantenimiento', N'DadoDeBaja'))
ALTER TABLE [dbo].[Solicitud]   ADD CONSTRAINT [CK_Solicitud_Estado]   CHECK ([ESTADO] IN (N'Pendiente', N'Aprobada', N'Rechazada'))
ALTER TABLE [dbo].[Incidencia]  ADD CONSTRAINT [CK_Incidencia_Estado]  CHECK ([ESTADO] IN (N'Pendiente', N'EnAtencion', N'Resuelta'))
ALTER TABLE [dbo].[Horario]     ADD CONSTRAINT [CK_Horario_Dia]        CHECK ([DIA] BETWEEN 1 AND 7)
ALTER TABLE [dbo].[Horario]     ADD CONSTRAINT [CK_Horario_Horas]      CHECK ([HORAFIN] > [HORAINICIO])
ALTER TABLE [dbo].[Solicitud]   ADD CONSTRAINT [CK_Solicitud_Horas]    CHECK ([HORAFIN] > [HORAINICIO])
ALTER TABLE [dbo].[Laboratorio] ADD CONSTRAINT [CK_Laboratorio_Capacidad] CHECK ([CAPACIDAD] > 0)
GO

/* ---------------- Datos iniciales ---------------- */

INSERT INTO [dbo].[TipoUsuario] ([NOMBRE]) VALUES
    (N'Administrador'), (N'Encargado'), (N'Tecnico'), (N'Docente'), (N'Estudiante')
GO

/* Contrasena de los usuarios de prueba: Lab2026*  (guardada con PBKDF2-SHA256 + sal, no en texto plano) */
INSERT INTO [dbo].[Usuario] ([NOMBRECOMPLETO], [LOGIN], [CORREO], [PASSWORD], [IIDTIPOUSUARIO]) VALUES
    (N'Administrador del Sistema', N'admin', N'admin@labcontrol.edu.bo', N'100000./ZyT2o1GEajMdjQbA4M5jQ==.FKK7xj1Tm16n3RSmD47W0LsZ6dYDyeW6cPiWvdbVXpw=', 1),
    (N'Encargado Centro de Cómputo', N'encargado', N'encargado@labcontrol.edu.bo', N'100000.6v68N6mjnMAYZZFoHQisQA==.4X29hZD0hfiZV36x259wtAoPZ+ox8d7GWn9H2+BH3yM=', 2),
    (N'Técnico de Soporte', N'tecnico', N'tecnico@labcontrol.edu.bo', N'100000.fvuZGINtA4KaN8r0LOI2wQ==.ABw2cZ+ijBDkINm9/alNOU2w/dC31E1bszERkU3Vvxo=', 3),
    (N'Docente de Prueba', N'docente', N'docente@labcontrol.edu.bo', N'100000./N/rddWXJOErEruP+OhBtQ==.t7cfWmuPxTgoaYObxc/PH+eqTup+85L3E85Pkqprl7o=', 4),
    (N'Estudiante de Prueba', N'estudiante', N'estudiante@labcontrol.edu.bo', N'100000.IxDWu/A1jpxEAyPU7a+Tfg==.Trmbn5W3zTTyKVtpW8QpD/a1v2yvkbRmCL3g7K4Q90o=', 5)
GO

INSERT INTO [dbo].[Laboratorio] ([NOMBRE], [UBICACION], [CAPACIDAD], [ESTADO], [DESCRIPCION]) VALUES
    (N'Laboratorio 1', N'Bloque A, Piso 1', 30, N'Disponible',      N'Laboratorio de programación con 30 equipos de escritorio.'),
    (N'Laboratorio 2', N'Bloque A, Piso 2', 25, N'Disponible',      N'Laboratorio para bases de datos y redes.'),
    (N'Laboratorio 3', N'Bloque B, Piso 1', 20, N'Disponible',      N'Laboratorio de uso general y talleres.'),
    (N'Laboratorio 4', N'Bloque B, Piso 2', 20, N'EnMantenimiento', N'Laboratorio en remodelación.')
GO

DECLARE @lab INT = 1, @i INT, @n INT = 1
WHILE @lab <= 4
BEGIN
    SET @i = 1
    WHILE @i <= 5
    BEGIN
        INSERT INTO [dbo].[Equipo] ([IIDLABORATORIO], [CODIGO], [NOMBRE])
        VALUES (@lab, 'PC-' + RIGHT('000' + CAST(@n AS VARCHAR(3)), 3),
                N'Computadora ' + CAST(@i AS NVARCHAR(2)) + N' - Laboratorio ' + CAST(@lab AS NVARCHAR(2)))
        SET @i += 1
        SET @n += 1
    END
    SET @lab += 1
END
GO

INSERT INTO [dbo].[PeriodoAcademico] ([NOMBRE], [FECHAINICIO], [FECHAFIN], [BVIGENTE])
VALUES (N'2026-II', '2026-08-03', '2026-12-12', 1)
GO

/* DIA: 1 = Lunes ... 6 = Sabado */
INSERT INTO [dbo].[Horario] ([IIDLABORATORIO], [IIDPERIODO], [DIA], [HORAINICIO], [HORAFIN], [ACTIVIDAD]) VALUES
    (1, 1, 1, '08:00', '10:00', N'Programación I'),
    (1, 1, 3, '10:00', '12:00', N'Estructuras de Datos'),
    (2, 1, 2, '14:00', '16:00', N'Bases de Datos I'),
    (2, 1, 4, '08:00', '10:00', N'Redes'),
    (3, 1, 5, '10:00', '12:00', N'Taller de Ofimática')
GO

/* Datos de ejemplo para probar los flujos de solicitudes e incidencias */
INSERT INTO [dbo].[Solicitud] ([IIDUSUARIO], [IIDLABORATORIO], [FECHA], [HORAINICIO], [HORAFIN], [MOTIVO])
VALUES (5, 3, DATEADD(DAY, 2, CAST(GETDATE() AS DATE)), '14:00', '16:00', N'Práctica grupal de Proyecto de Sistemas I')

INSERT INTO [dbo].[Incidencia] ([IIDUSUARIO], [IIDLABORATORIO], [IIDEQUIPO], [DESCRIPCION])
VALUES (4, 1, 2, N'El equipo no enciende al presionar el botón de poder.')
UPDATE [dbo].[Equipo] SET [ESTADO] = N'EnFalla' WHERE [IIDEQUIPO] = 2

INSERT INTO [dbo].[Notificacion] ([IIDUSUARIO], [MENSAJE], [ENLACE]) VALUES
    (1, N'Nueva solicitud de Estudiante de Prueba para Laboratorio 3.', N'gestion-solicitudes'),
    (2, N'Nueva solicitud de Estudiante de Prueba para Laboratorio 3.', N'gestion-solicitudes'),
    (2, N'Nueva incidencia en Laboratorio 1 (PC-002) reportada por Docente de Prueba.', N'gestion-incidencias'),
    (3, N'Nueva incidencia en Laboratorio 1 (PC-002) reportada por Docente de Prueba.', N'gestion-incidencias')
GO

PRINT 'BDLABCONTROL creada correctamente.'
GO
