using System;

namespace BlazorAppLab.entities
{
    /// <summary>Nombres de los tipos de usuario (tabla TipoUsuario) y grupos de roles para los permisos.</summary>
    public static class Roles
    {
        public const string Administrador = "Administrador";
        public const string Encargado = "Encargado";
        public const string Tecnico = "Tecnico";
        public const string Docente = "Docente";
        public const string Estudiante = "Estudiante";

        public const string Todos = "Administrador,Encargado,Tecnico,Docente,Estudiante";
        public const string Solicitantes = "Docente,Estudiante";
        public const string Gestion = "Administrador,Encargado";
        public const string AtencionIncidencias = "Administrador,Encargado,Tecnico";

        public static bool Contiene(string grupo, string rol) =>
            grupo.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries).Contains(rol);
    }

    /// <summary>Valores permitidos de las columnas ESTADO (coinciden con los CHECK de la base de datos).</summary>
    public static class Estados
    {
        // Laboratorio
        public const string Disponible = "Disponible";
        public const string EnMantenimiento = "EnMantenimiento";
        public const string Inactivo = "Inactivo";

        // Equipo
        public const string Operativo = "Operativo";
        public const string EnFalla = "EnFalla";
        public const string DadoDeBaja = "DadoDeBaja";

        // Solicitud
        public const string Pendiente = "Pendiente";
        public const string Aprobada = "Aprobada";
        public const string Rechazada = "Rechazada";

        // Incidencia
        public const string EnAtencion = "EnAtencion";
        public const string Resuelta = "Resuelta";

        public static readonly string[] Laboratorio = { Disponible, EnMantenimiento, Inactivo };
        public static readonly string[] Equipo = { Operativo, EnFalla, EnMantenimiento, DadoDeBaja };
        public static readonly string[] Solicitud = { Pendiente, Aprobada, Rechazada };
        public static readonly string[] Incidencia = { Pendiente, EnAtencion, Resuelta };

        public static string Texto(string? estado) => estado switch
        {
            "EnMantenimiento" => "En mantenimiento",
            "EnFalla" => "En falla",
            "DadoDeBaja" => "Dado de baja",
            "EnAtencion" => "En atención",
            "Tecnico" => "Técnico",
            null => "",
            _ => estado
        };

        /// <summary>Clase de Bootstrap para pintar el estado como insignia.</summary>
        public static string Badge(string? estado) => estado switch
        {
            "Aprobada" or "Resuelta" or "Disponible" or "Operativo" => "bg-success",
            "Rechazada" or "EnFalla" or "Inactivo" or "DadoDeBaja" => "bg-danger",
            "Pendiente" => "bg-warning text-dark",
            "EnAtencion" or "EnMantenimiento" => "bg-info text-dark",
            _ => "bg-secondary"
        };
    }

    /// <summary>Días de la semana: 1 = Lunes ... 6 = Sábado, 7 = Domingo.</summary>
    public static class Dias
    {
        public static readonly int[] Laborables = { 1, 2, 3, 4, 5, 6 };

        public static string Nombre(int dia) => dia switch
        {
            1 => "Lunes", 2 => "Martes", 3 => "Miércoles", 4 => "Jueves",
            5 => "Viernes", 6 => "Sábado", _ => "Domingo"
        };

        public static int DeFecha(DateOnly fecha) => ((int)fecha.DayOfWeek + 6) % 7 + 1;
    }
}
