using System;
using System.ComponentModel.DataAnnotations;

namespace BlazorAppLab.entities
{
    public class UsuarioLoginCLS
    {
        [Required(ErrorMessage = "Ingrese su usuario o correo")]
        public string Login { get; set; } = string.Empty;

        [Required(ErrorMessage = "Ingrese su contraseña")]
        public string Password { get; set; } = string.Empty;
    }

    public class UsuarioSesionCLS
    {
        public int IdUsuario { get; set; }
        public string Login { get; set; } = string.Empty;
        public string NombreCompleto { get; set; } = string.Empty;
        public int IdTipoUsuario { get; set; }
        public string NombreTipoUsuario { get; set; } = string.Empty;
        public string Token { get; set; } = string.Empty;
    }

    public class TipoUsuarioCLS
    {
        public int IdTipoUsuario { get; set; }
        public string Nombre { get; set; } = string.Empty;
    }

    /// <summary>Usuario para el listado y el formulario de administración (HU-12).</summary>
    public class UsuarioCLS
    {
        public int IdUsuario { get; set; }

        [Required(ErrorMessage = "El nombre completo es obligatorio")]
        [MaxLength(120)]
        public string NombreCompleto { get; set; } = string.Empty;

        [Required(ErrorMessage = "El usuario es obligatorio")]
        [MaxLength(50)]
        public string Login { get; set; } = string.Empty;

        [Required(ErrorMessage = "El correo es obligatorio")]
        [EmailAddress(ErrorMessage = "Correo no válido")]
        [MaxLength(120)]
        public string Correo { get; set; } = string.Empty;

        /// <summary>Solo se envía al crear o cuando se quiere cambiar. Nunca se devuelve desde la API.</summary>
        public string? Password { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Seleccione un rol")]
        public int IdTipoUsuario { get; set; }
        public string NombreTipoUsuario { get; set; } = string.Empty;

        public bool Habilitado { get; set; } = true;
    }
}
