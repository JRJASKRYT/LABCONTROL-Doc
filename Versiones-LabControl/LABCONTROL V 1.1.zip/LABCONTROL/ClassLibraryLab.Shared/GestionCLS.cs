using System;
using System.ComponentModel.DataAnnotations;

namespace BlazorAppLab.entities
{
    public class SolicitudCLS
    {
        public int IdSolicitud { get; set; }
        public int IdUsuario { get; set; }
        public string NombreSolicitante { get; set; } = string.Empty;
        public string RolSolicitante { get; set; } = string.Empty;

        [Range(1, int.MaxValue, ErrorMessage = "Seleccione un laboratorio")]
        public int IdLaboratorio { get; set; }
        public string NombreLaboratorio { get; set; } = string.Empty;

        public DateOnly Fecha { get; set; } = DateOnly.FromDateTime(DateTime.Today);
        public TimeOnly HoraInicio { get; set; } = new TimeOnly(8, 0);
        public TimeOnly HoraFin { get; set; } = new TimeOnly(10, 0);

        [Required(ErrorMessage = "Indique el motivo de la solicitud")]
        [MaxLength(300)]
        public string Motivo { get; set; } = string.Empty;

        public string Estado { get; set; } = Estados.Pendiente;
        public DateTime FechaCreacion { get; set; }
        public string NombreGestor { get; set; } = string.Empty;
        public DateTime? FechaGestion { get; set; }
        public string? ObservacionGestion { get; set; }
    }

    public class SolicitudResolverCLS
    {
        public int IdSolicitud { get; set; }
        public bool Aprobar { get; set; }
        public string? Observacion { get; set; }
    }

    public class UtilizacionCLS
    {
        public int IdUtilizacion { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Seleccione el usuario")]
        public int IdUsuario { get; set; }
        public string NombreUsuario { get; set; } = string.Empty;

        [Range(1, int.MaxValue, ErrorMessage = "Seleccione un laboratorio")]
        public int IdLaboratorio { get; set; }
        public string NombreLaboratorio { get; set; } = string.Empty;

        public int? IdEquipo { get; set; }
        public string CodigoEquipo { get; set; } = string.Empty;

        public DateTime Fecha { get; set; } = DateTime.Now;

        [MaxLength(300)]
        public string? Observacion { get; set; }
    }

    public class IncidenciaCLS
    {
        public int IdIncidencia { get; set; }
        public int IdUsuario { get; set; }
        public string NombreReporta { get; set; } = string.Empty;

        [Range(1, int.MaxValue, ErrorMessage = "Seleccione un laboratorio")]
        public int IdLaboratorio { get; set; }
        public string NombreLaboratorio { get; set; } = string.Empty;

        public int? IdEquipo { get; set; }
        public string CodigoEquipo { get; set; } = string.Empty;

        [Required(ErrorMessage = "Describa la falla")]
        [MaxLength(500)]
        public string Descripcion { get; set; } = string.Empty;

        public DateTime FechaReporte { get; set; }
        public string Estado { get; set; } = Estados.Pendiente;
        public DateTime? FechaAtencion { get; set; }
        public string? ObservacionTecnica { get; set; }
        public string NombreAtiende { get; set; } = string.Empty;
    }

    public class IncidenciaActualizarCLS
    {
        public int IdIncidencia { get; set; }
        public string Estado { get; set; } = Estados.Pendiente;
        public string? ObservacionTecnica { get; set; }
    }

    public class NotificacionCLS
    {
        public int IdNotificacion { get; set; }
        public string Mensaje { get; set; } = string.Empty;
        public string? Enlace { get; set; }
        public DateTime Fecha { get; set; }
        public bool Leida { get; set; }
    }

    public class UsoLaboratorioCLS
    {
        public string Laboratorio { get; set; } = string.Empty;
        public int ReservasAprobadas { get; set; }
        public double HorasReservadas { get; set; }
        public int Utilizaciones { get; set; }
        public int Incidencias { get; set; }
    }

    public class MesCantidadCLS
    {
        public string Mes { get; set; } = string.Empty;
        public int Cantidad { get; set; }
    }

    public class IndicadoresCLS
    {
        public int TotalLaboratorios { get; set; }
        public int LaboratoriosDisponibles { get; set; }
        public int TotalEquipos { get; set; }
        public int EquiposConFalla { get; set; }
        public int SolicitudesPendientes { get; set; }
        public int SolicitudesAprobadas { get; set; }
        public int SolicitudesRechazadas { get; set; }
        public double TasaAprobacion { get; set; }
        public int IncidenciasPendientes { get; set; }
        public int IncidenciasEnAtencion { get; set; }
        public int IncidenciasResueltas { get; set; }
        public double? HorasMediasAtencion { get; set; }
        public int UtilizacionesDelMes { get; set; }
        public List<UsoLaboratorioCLS> UsoPorLaboratorio { get; set; } = new();
        public List<MesCantidadCLS> SolicitudesPorMes { get; set; } = new();
    }
}
