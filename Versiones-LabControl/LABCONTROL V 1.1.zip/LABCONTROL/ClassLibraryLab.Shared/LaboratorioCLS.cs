using System;
using System.ComponentModel.DataAnnotations;

namespace BlazorAppLab.entities
{
    public class LaboratorioCLS
    {
        public int IdLaboratorio { get; set; }

        [Required(ErrorMessage = "El nombre es obligatorio")]
        [MaxLength(100)]
        public string Nombre { get; set; } = string.Empty;

        [Required(ErrorMessage = "La ubicación es obligatoria")]
        [MaxLength(150)]
        public string Ubicacion { get; set; } = string.Empty;

        [Range(1, 500, ErrorMessage = "La capacidad debe estar entre 1 y 500")]
        public int Capacidad { get; set; } = 20;

        public string Estado { get; set; } = Estados.Disponible;

        [MaxLength(500)]
        public string? Descripcion { get; set; }

        public int TotalEquipos { get; set; }
        public int EquiposOperativos { get; set; }
    }

    public class EquipoCLS
    {
        public int IdEquipo { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Seleccione un laboratorio")]
        public int IdLaboratorio { get; set; }
        public string NombreLaboratorio { get; set; } = string.Empty;

        [Required(ErrorMessage = "El código es obligatorio")]
        [MaxLength(30)]
        public string Codigo { get; set; } = string.Empty;

        [Required(ErrorMessage = "El nombre es obligatorio")]
        [MaxLength(100)]
        public string Nombre { get; set; } = string.Empty;

        public string Estado { get; set; } = Estados.Operativo;
    }

    public class PeriodoCLS
    {
        public int IdPeriodo { get; set; }

        [Required(ErrorMessage = "El nombre es obligatorio")]
        [MaxLength(50)]
        public string Nombre { get; set; } = string.Empty;

        public DateOnly FechaInicio { get; set; } = DateOnly.FromDateTime(DateTime.Today);
        public DateOnly FechaFin { get; set; } = DateOnly.FromDateTime(DateTime.Today.AddMonths(4));
        public bool Vigente { get; set; } = true;
    }

    public class HorarioCLS
    {
        public int IdHorario { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Seleccione un laboratorio")]
        public int IdLaboratorio { get; set; }
        public string NombreLaboratorio { get; set; } = string.Empty;

        [Range(1, int.MaxValue, ErrorMessage = "Seleccione un periodo")]
        public int IdPeriodo { get; set; }
        public string NombrePeriodo { get; set; } = string.Empty;

        public int Dia { get; set; } = 1;
        public TimeOnly HoraInicio { get; set; } = new TimeOnly(8, 0);
        public TimeOnly HoraFin { get; set; } = new TimeOnly(10, 0);

        [MaxLength(150)]
        public string? Actividad { get; set; }
    }

    public class DisponibilidadCLS
    {
        public int IdLaboratorio { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Ubicacion { get; set; } = string.Empty;
        public int Capacidad { get; set; }
        public bool Disponible { get; set; }
        public string Motivo { get; set; } = string.Empty;
    }
}
