using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BlazorAppLab.API.Models;
using BlazorAppLab.API.Seguridad;
using BlazorAppLab.entities;

namespace BlazorAppLab.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UtilizacionController : ApiBaseController
    {
        public UtilizacionController(BdlabcontrolContext _bd) : base(_bd)
        {
        }

        // HU-09 / HU-18: registros de utilizacion con filtros opcionales
        [Autorizar(Roles.Gestion)]
        [HttpGet]
        public async Task<IActionResult> listarUtilizaciones([FromQuery] DateOnly? desde, [FromQuery] DateOnly? hasta,
            [FromQuery] int? idLaboratorio, [FromQuery] int top = 200)
        {
            try
            {
                DateTime? fechaDesde = desde?.ToDateTime(TimeOnly.MinValue);
                DateTime? fechaHasta = hasta?.ToDateTime(TimeOnly.MaxValue);

                var lista = await (from uso in bd.Utilizaciones
                                   join usuario in bd.Usuarios on uso.Iidusuario equals usuario.Iidusuario
                                   join lab in bd.Laboratorios on uso.Iidlaboratorio equals lab.Iidlaboratorio
                                   join equipo in bd.Equipos on uso.Iidequipo equals (int?)equipo.Iidequipo into equipos
                                   from equipo in equipos.DefaultIfEmpty()
                                   where (fechaDesde == null || uso.Fecha >= fechaDesde)
                                         && (fechaHasta == null || uso.Fecha <= fechaHasta)
                                         && (idLaboratorio == null || uso.Iidlaboratorio == idLaboratorio)
                                   orderby uso.Fecha descending
                                   select new UtilizacionCLS
                                   {
                                       IdUtilizacion = uso.Iidutilizacion,
                                       IdUsuario = uso.Iidusuario,
                                       NombreUsuario = usuario.Nombrecompleto,
                                       IdLaboratorio = uso.Iidlaboratorio,
                                       NombreLaboratorio = lab.Nombre,
                                       IdEquipo = uso.Iidequipo,
                                       CodigoEquipo = equipo != null ? equipo.Codigo : "",
                                       Fecha = uso.Fecha,
                                       Observacion = uso.Observacion
                                   }).Take(top).ToListAsync();

                return Ok(lista);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        // HU-09: registra el uso de un laboratorio o equipo
        [Autorizar(Roles.Gestion)]
        [HttpPost]
        public async Task<IActionResult> registrarUtilizacion([FromBody] UtilizacionCLS oUso)
        {
            try
            {
                if (oUso.IdUsuario <= 0)
                {
                    return BadRequest("Seleccione el usuario.");
                }
                if (oUso.IdLaboratorio <= 0)
                {
                    return BadRequest("Seleccione el laboratorio.");
                }
                if (!await bd.Usuarios.AnyAsync(u => u.Iidusuario == oUso.IdUsuario))
                {
                    return BadRequest("Usuario no valido.");
                }
                if (!await bd.Laboratorios.AnyAsync(l => l.Iidlaboratorio == oUso.IdLaboratorio))
                {
                    return BadRequest("Laboratorio no valido.");
                }
                if (oUso.IdEquipo.HasValue
                    && !await bd.Equipos.AnyAsync(e => e.Iidequipo == oUso.IdEquipo.Value && e.Iidlaboratorio == oUso.IdLaboratorio))
                {
                    return BadRequest("El equipo no pertenece al laboratorio seleccionado.");
                }

                Utilizacion nuevo = new Utilizacion
                {
                    Iidusuario = oUso.IdUsuario,
                    Iidlaboratorio = oUso.IdLaboratorio,
                    Iidequipo = oUso.IdEquipo,
                    Fecha = oUso.Fecha,
                    Observacion = string.IsNullOrWhiteSpace(oUso.Observacion) ? null : oUso.Observacion.Trim(),
                    Iidusuarioregistro = idUsuarioActual
                };
                bd.Utilizaciones.Add(nuevo);

                await bd.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }
    }
}
