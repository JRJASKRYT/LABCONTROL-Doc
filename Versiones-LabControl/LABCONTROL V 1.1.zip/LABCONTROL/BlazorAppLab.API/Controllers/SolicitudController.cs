using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BlazorAppLab.API.Logica;
using BlazorAppLab.API.Models;
using BlazorAppLab.API.Seguridad;
using BlazorAppLab.entities;

namespace BlazorAppLab.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SolicitudController : ApiBaseController
    {
        public SolicitudController(BdlabcontrolContext _bd) : base(_bd)
        {
        }

        // Consulta base reutilizada por "mis solicitudes", pendientes e historial
        private IQueryable<SolicitudCLS> consulta()
        {
            return from solicitud in bd.Solicitudes
                   join lab in bd.Laboratorios on solicitud.Iidlaboratorio equals lab.Iidlaboratorio
                   join usuario in bd.Usuarios on solicitud.Iidusuario equals usuario.Iidusuario
                   join tipo in bd.TipoUsuarios on usuario.Iidtipousuario equals tipo.Iidtipousuario
                   join gestor in bd.Usuarios on solicitud.Iidusuariogestion equals (int?)gestor.Iidusuario into gestores
                   from gestor in gestores.DefaultIfEmpty()
                   select new SolicitudCLS
                   {
                       IdSolicitud = solicitud.Iidsolicitud,
                       IdUsuario = solicitud.Iidusuario,
                       NombreSolicitante = usuario.Nombrecompleto,
                       RolSolicitante = tipo.Nombre,
                       IdLaboratorio = solicitud.Iidlaboratorio,
                       NombreLaboratorio = lab.Nombre,
                       Fecha = solicitud.Fecha,
                       HoraInicio = solicitud.Horainicio,
                       HoraFin = solicitud.Horafin,
                       Motivo = solicitud.Motivo,
                       Estado = solicitud.Estado,
                       FechaCreacion = solicitud.Fechacreacion,
                       NombreGestor = gestor != null ? gestor.Nombrecompleto : "",
                       FechaGestion = solicitud.Fechagestion,
                       ObservacionGestion = solicitud.Observaciongestion
                   };
        }

        // HU-06 / HU-07: solo las solicitudes del usuario autenticado
        [Autorizar(Roles.Solicitantes)]
        [HttpGet("mis")]
        public async Task<IActionResult> listarMisSolicitudes([FromQuery] string? estado)
        {
            try
            {
                var idUsuario = idUsuarioActual;
                var lista = await consulta()
                    .Where(s => s.IdUsuario == idUsuario && (estado == null || estado == "" || s.Estado == estado))
                    .OrderByDescending(s => s.FechaCreacion)
                    .ToListAsync();

                return Ok(lista);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        // HU-08: solicitudes pendientes de resolver
        [Autorizar(Roles.Gestion)]
        [HttpGet("pendientes")]
        public async Task<IActionResult> listarPendientes()
        {
            try
            {
                var lista = await consulta()
                    .Where(s => s.Estado == Estados.Pendiente)
                    .OrderBy(s => s.Fecha).ThenBy(s => s.HoraInicio)
                    .ToListAsync();

                return Ok(lista);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        // HU-16 / HU-18: historial con filtros
        [Autorizar(Roles.Gestion)]
        [HttpGet("historial")]
        public async Task<IActionResult> historial([FromQuery] DateOnly? desde, [FromQuery] DateOnly? hasta,
            [FromQuery] int? idLaboratorio, [FromQuery] string? estado)
        {
            try
            {
                var lista = await consulta()
                    .Where(s => (desde == null || s.Fecha >= desde)
                                && (hasta == null || s.Fecha <= hasta)
                                && (idLaboratorio == null || s.IdLaboratorio == idLaboratorio)
                                && (estado == null || estado == "" || s.Estado == estado))
                    .OrderByDescending(s => s.Fecha).ThenByDescending(s => s.HoraInicio)
                    .ToListAsync();

                return Ok(lista);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        // HU-05: registra la solicitud con estado inicial Pendiente, validando datos y disponibilidad
        [Autorizar(Roles.Solicitantes)]
        [HttpPost]
        public async Task<IActionResult> crearSolicitud([FromBody] SolicitudCLS oSolicitud)
        {
            try
            {
                if (oSolicitud.IdLaboratorio <= 0)
                {
                    return BadRequest("Seleccione un laboratorio.");
                }
                if (string.IsNullOrWhiteSpace(oSolicitud.Motivo))
                {
                    return BadRequest("Indique el motivo de la solicitud.");
                }
                if (oSolicitud.HoraFin <= oSolicitud.HoraInicio)
                {
                    return BadRequest("La hora de fin debe ser posterior a la hora de inicio.");
                }
                if (oSolicitud.Fecha < DateOnly.FromDateTime(DateTime.Today))
                {
                    return BadRequest("La fecha no puede ser anterior a hoy.");
                }

                var lab = await bd.Laboratorios.FirstOrDefaultAsync(l => l.Iidlaboratorio == oSolicitud.IdLaboratorio);
                if (lab == null)
                {
                    return BadRequest("Laboratorio no encontrado.");
                }

                var motivo = await DisponibilidadHelper.motivoNoDisponibleAsync(bd, lab, oSolicitud.Fecha, oSolicitud.HoraInicio, oSolicitud.HoraFin);
                if (motivo != null)
                {
                    return BadRequest("El laboratorio no esta disponible: " + motivo + ".");
                }

                var idUsuario = idUsuarioActual;
                var solicitante = await bd.Usuarios.FirstOrDefaultAsync(u => u.Iidusuario == idUsuario);
                if (solicitante == null)
                {
                    return Unauthorized("Usuario no valido.");
                }

                Solicitud nueva = new Solicitud
                {
                    Iidusuario = idUsuario,
                    Iidlaboratorio = oSolicitud.IdLaboratorio,
                    Fecha = oSolicitud.Fecha,
                    Horainicio = oSolicitud.HoraInicio,
                    Horafin = oSolicitud.HoraFin,
                    Motivo = oSolicitud.Motivo.Trim(),
                    Estado = Estados.Pendiente,
                    Fechacreacion = DateTime.Now
                };
                bd.Solicitudes.Add(nueva);

                await Avisos.aRolesAsync(bd, new[] { Roles.Encargado, Roles.Administrador },
                    $"Nueva solicitud de {solicitante.Nombrecompleto} para {lab.Nombre} el {oSolicitud.Fecha:dd/MM/yyyy} ({oSolicitud.HoraInicio:HH:mm}-{oSolicitud.HoraFin:HH:mm}).",
                    "gestion-solicitudes");

                await bd.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        // HU-08: aprobar o rechazar. Registra quien, cuando y la observacion; avisa al solicitante
        [Autorizar(Roles.Gestion)]
        [HttpPost("resolver")]
        public async Task<IActionResult> resolverSolicitud([FromBody] SolicitudResolverCLS oResolver)
        {
            try
            {
                var solicitud = await bd.Solicitudes.FirstOrDefaultAsync(s => s.Iidsolicitud == oResolver.IdSolicitud);
                if (solicitud == null)
                {
                    return NotFound("Solicitud no encontrada.");
                }
                if (solicitud.Estado != Estados.Pendiente)
                {
                    return BadRequest("La solicitud ya fue resuelta.");
                }

                var lab = await bd.Laboratorios.FirstAsync(l => l.Iidlaboratorio == solicitud.Iidlaboratorio);

                if (oResolver.Aprobar)
                {
                    var motivo = await DisponibilidadHelper.motivoNoDisponibleAsync(bd, lab, solicitud.Fecha,
                        solicitud.Horainicio, solicitud.Horafin, solicitud.Iidsolicitud);
                    if (motivo != null)
                    {
                        return BadRequest("No se puede aprobar: " + motivo + ".");
                    }
                }
                else if (string.IsNullOrWhiteSpace(oResolver.Observacion))
                {
                    return BadRequest("Indique el motivo del rechazo.");
                }

                solicitud.Estado = oResolver.Aprobar ? Estados.Aprobada : Estados.Rechazada;
                solicitud.Iidusuariogestion = idUsuarioActual;
                solicitud.Fechagestion = DateTime.Now;
                solicitud.Observaciongestion = string.IsNullOrWhiteSpace(oResolver.Observacion) ? null : oResolver.Observacion.Trim();

                Avisos.aUsuario(bd, solicitud.Iidusuario,
                    $"Tu solicitud para {lab.Nombre} el {solicitud.Fecha:dd/MM/yyyy} fue {(oResolver.Aprobar ? "aprobada" : "rechazada")}.",
                    "mis-solicitudes");

                await bd.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }
    }
}
