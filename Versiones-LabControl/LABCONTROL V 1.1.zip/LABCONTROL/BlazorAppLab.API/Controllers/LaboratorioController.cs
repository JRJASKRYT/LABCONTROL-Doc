using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BlazorAppLab.API.Models;
using BlazorAppLab.API.Seguridad;
using BlazorAppLab.entities;

namespace BlazorAppLab.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LaboratorioController : ApiBaseController
    {
        public LaboratorioController(BdlabcontrolContext _bd) : base(_bd)
        {
        }

        private IQueryable<LaboratorioCLS> consulta()
        {
            return from lab in bd.Laboratorios
                   select new LaboratorioCLS
                   {
                       IdLaboratorio = lab.Iidlaboratorio,
                       Nombre = lab.Nombre,
                       Ubicacion = lab.Ubicacion,
                       Capacidad = lab.Capacidad,
                       Estado = lab.Estado,
                       Descripcion = lab.Descripcion,
                       TotalEquipos = bd.Equipos.Count(e => e.Iidlaboratorio == lab.Iidlaboratorio && e.Estado != Estados.DadoDeBaja),
                       EquiposOperativos = bd.Equipos.Count(e => e.Iidlaboratorio == lab.Iidlaboratorio && e.Estado == Estados.Operativo)
                   };
        }

        // HU-04 / HU-10: listado de laboratorios
        [Autorizar]
        [HttpGet]
        public async Task<IActionResult> listarLaboratorios([FromQuery] bool incluirInactivos = false)
        {
            try
            {
                var lista = await consulta()
                    .Where(l => incluirInactivos || l.Estado != Estados.Inactivo)
                    .OrderBy(l => l.Nombre)
                    .ToListAsync();

                return Ok(lista);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        // HU-04: ficha de un laboratorio
        [Autorizar]
        [HttpGet("{id}")]
        public async Task<IActionResult> recuperarLaboratorio(int id)
        {
            try
            {
                var obj = await consulta().Where(l => l.IdLaboratorio == id).FirstOrDefaultAsync();
                if (obj == null)
                {
                    return NotFound("Laboratorio no encontrado.");
                }
                return Ok(obj);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        // HU-10: registrar o actualizar un laboratorio (el estado "Inactivo" reemplaza al borrado)
        [Autorizar(Roles.Gestion)]
        [HttpPost]
        public async Task<IActionResult> guardarLaboratorio([FromBody] LaboratorioCLS oLab)
        {
            try
            {
                var nombre = (oLab.Nombre ?? "").Trim();
                var ubicacion = (oLab.Ubicacion ?? "").Trim();

                if (nombre == "" || ubicacion == "")
                {
                    return BadRequest("El nombre y la ubicacion son obligatorios.");
                }
                if (oLab.Capacidad <= 0)
                {
                    return BadRequest("La capacidad debe ser mayor que cero.");
                }
                if (!Estados.Laboratorio.Contains(oLab.Estado))
                {
                    return BadRequest("Estado no valido.");
                }
                if (await bd.Laboratorios.AnyAsync(l => l.Nombre == nombre && l.Iidlaboratorio != oLab.IdLaboratorio))
                {
                    return BadRequest("Ya existe un laboratorio con ese nombre.");
                }

                if (oLab.IdLaboratorio == 0)
                {
                    Laboratorio nuevo = new Laboratorio
                    {
                        Nombre = nombre,
                        Ubicacion = ubicacion,
                        Capacidad = oLab.Capacidad,
                        Estado = oLab.Estado,
                        Descripcion = string.IsNullOrWhiteSpace(oLab.Descripcion) ? null : oLab.Descripcion.Trim()
                    };
                    bd.Laboratorios.Add(nuevo);
                }
                else
                {
                    var actual = await bd.Laboratorios.FirstOrDefaultAsync(l => l.Iidlaboratorio == oLab.IdLaboratorio);
                    if (actual == null)
                    {
                        return NotFound("Laboratorio no encontrado.");
                    }
                    actual.Nombre = nombre;
                    actual.Ubicacion = ubicacion;
                    actual.Capacidad = oLab.Capacidad;
                    actual.Estado = oLab.Estado;
                    actual.Descripcion = string.IsNullOrWhiteSpace(oLab.Descripcion) ? null : oLab.Descripcion.Trim();
                }

                await bd.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }
    }
}
