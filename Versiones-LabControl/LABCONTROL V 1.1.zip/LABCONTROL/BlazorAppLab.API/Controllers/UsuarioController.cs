using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BlazorAppLab.API.Models;
using BlazorAppLab.API.Seguridad;
using BlazorAppLab.entities;

namespace BlazorAppLab.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ApiBaseController
    {
        private readonly TokenService tokenService;

        public UsuarioController(BdlabcontrolContext _bd, TokenService _tokenService) : base(_bd)
        {
            this.tokenService = _tokenService;
        }

        // HU-01: valida usuario o correo + contrasena y devuelve los datos de sesion con el token
        [HttpPost("login")]
        public async Task<IActionResult> login([FromBody] UsuarioLoginCLS oLogin)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(oLogin.Login) || string.IsNullOrWhiteSpace(oLogin.Password))
                {
                    return BadRequest("Debe ingresar usuario y contrasena.");
                }

                var texto = oLogin.Login.Trim();

                var datos = await (from usuario in bd.Usuarios
                                   join tipo in bd.TipoUsuarios on usuario.Iidtipousuario equals tipo.Iidtipousuario
                                   where (usuario.Login == texto || usuario.Correo == texto)
                                         && usuario.Bhabilitado == 1
                                   select new { usuario, nombreTipo = tipo.Nombre }).FirstOrDefaultAsync();

                if (datos == null || !PasswordHasher.verificar(oLogin.Password, datos.usuario.Password))
                {
                    return Unauthorized("Usuario o contrasena incorrectos.");
                }

                var obj = new UsuarioSesionCLS
                {
                    IdUsuario = datos.usuario.Iidusuario,
                    Login = datos.usuario.Login,
                    NombreCompleto = datos.usuario.Nombrecompleto,
                    IdTipoUsuario = datos.usuario.Iidtipousuario,
                    NombreTipoUsuario = datos.nombreTipo,
                    Token = tokenService.crear(datos.usuario.Iidusuario, datos.nombreTipo)
                };

                return Ok(obj);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        // HU-12: listado de usuarios (solo administrador). Nunca se devuelve la contrasena.
        [Autorizar(Roles.Administrador)]
        [HttpGet]
        public async Task<IActionResult> listarUsuarios()
        {
            try
            {
                var lista = await (from usuario in bd.Usuarios
                                   join tipo in bd.TipoUsuarios on usuario.Iidtipousuario equals tipo.Iidtipousuario
                                   orderby usuario.Nombrecompleto
                                   select new UsuarioCLS
                                   {
                                       IdUsuario = usuario.Iidusuario,
                                       NombreCompleto = usuario.Nombrecompleto,
                                       Login = usuario.Login,
                                       Correo = usuario.Correo,
                                       IdTipoUsuario = usuario.Iidtipousuario,
                                       NombreTipoUsuario = tipo.Nombre,
                                       Habilitado = usuario.Bhabilitado == 1
                                   }).ToListAsync();

                return Ok(lista);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        // Usuarios activos para elegir en el registro de utilizacion (HU-09)
        [Autorizar(Roles.Gestion)]
        [HttpGet("activos")]
        public async Task<IActionResult> listarActivos()
        {
            try
            {
                var lista = await (from usuario in bd.Usuarios
                                   join tipo in bd.TipoUsuarios on usuario.Iidtipousuario equals tipo.Iidtipousuario
                                   where usuario.Bhabilitado == 1
                                   orderby usuario.Nombrecompleto
                                   select new UsuarioCLS
                                   {
                                       IdUsuario = usuario.Iidusuario,
                                       NombreCompleto = usuario.Nombrecompleto,
                                       Login = usuario.Login,
                                       IdTipoUsuario = usuario.Iidtipousuario,
                                       NombreTipoUsuario = tipo.Nombre,
                                       Habilitado = true
                                   }).ToListAsync();

                return Ok(lista);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        // HU-12: crear o actualizar un usuario y asignar su rol (solo administrador)
        [Autorizar(Roles.Administrador)]
        [HttpPost]
        public async Task<IActionResult> guardarUsuario([FromBody] UsuarioCLS oUsuario)
        {
            try
            {
                var nombre = (oUsuario.NombreCompleto ?? "").Trim();
                var login = (oUsuario.Login ?? "").Trim();
                var correo = (oUsuario.Correo ?? "").Trim();

                if (nombre == "" || login == "" || correo == "")
                {
                    return BadRequest("Complete todos los campos obligatorios.");
                }

                if (!await bd.TipoUsuarios.AnyAsync(t => t.Iidtipousuario == oUsuario.IdTipoUsuario && t.Bhabilitado == 1))
                {
                    return BadRequest("Seleccione un rol valido.");
                }

                if (await bd.Usuarios.AnyAsync(u => u.Login == login && u.Iidusuario != oUsuario.IdUsuario))
                {
                    return BadRequest("Ese nombre de usuario ya esta registrado.");
                }

                if (await bd.Usuarios.AnyAsync(u => u.Correo == correo && u.Iidusuario != oUsuario.IdUsuario))
                {
                    return BadRequest("Ese correo ya esta registrado.");
                }

                if (oUsuario.IdUsuario == 0)
                {
                    if (string.IsNullOrWhiteSpace(oUsuario.Password) || oUsuario.Password.Length < 6)
                    {
                        return BadRequest("La contrasena es obligatoria (minimo 6 caracteres).");
                    }

                    Usuario nuevo = new Usuario
                    {
                        Nombrecompleto = nombre,
                        Login = login,
                        Correo = correo,
                        Password = PasswordHasher.calcularHash(oUsuario.Password),
                        Iidtipousuario = oUsuario.IdTipoUsuario,
                        Bhabilitado = oUsuario.Habilitado ? 1 : 0,
                        Fecharegistro = DateTime.Now
                    };
                    bd.Usuarios.Add(nuevo);
                }
                else
                {
                    var actual = await bd.Usuarios.FirstOrDefaultAsync(u => u.Iidusuario == oUsuario.IdUsuario);
                    if (actual == null)
                    {
                        return NotFound("Usuario no encontrado.");
                    }

                    if (actual.Iidusuario == idUsuarioActual
                        && (!oUsuario.Habilitado || actual.Iidtipousuario != oUsuario.IdTipoUsuario))
                    {
                        return BadRequest("No puede desactivar su propia cuenta ni cambiar su propio rol.");
                    }

                    actual.Nombrecompleto = nombre;
                    actual.Login = login;
                    actual.Correo = correo;
                    actual.Iidtipousuario = oUsuario.IdTipoUsuario;
                    actual.Bhabilitado = oUsuario.Habilitado ? 1 : 0;

                    if (!string.IsNullOrWhiteSpace(oUsuario.Password))
                    {
                        if (oUsuario.Password.Length < 6)
                        {
                            return BadRequest("La contrasena debe tener minimo 6 caracteres.");
                        }
                        actual.Password = PasswordHasher.calcularHash(oUsuario.Password);
                    }
                }

                await bd.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }
    }
}
