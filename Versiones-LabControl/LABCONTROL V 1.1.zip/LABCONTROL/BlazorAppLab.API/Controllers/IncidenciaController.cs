using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BlazorAppLab.API.Logica;
using BlazorAppLab.API.Models;
using BlazorAppLab.API.Seguridad;
using BlazorAppLab.entities;

namespace BlazorAppLab.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IncidenciaController : ApiBaseController
    {
        public IncidenciaController(BdlabcontrolContext _bd) : base(_bd)
        {
        }

        private IQueryable<IncidenciaCLS> consulta()
        {
            return from incidencia in bd.Incidencias
                   join lab in bd.Laboratorios on incidencia.Iidlaboratorio equals lab.Iidlaboratorio
                   join usuario in bd.Usuarios on incidencia.Iidusuario equals usuario.Iidusuario
                   join equipo in bd.Equipos on incidencia.Iidequipo equals (int?)equipo.Iidequipo into equipos
                   from equipo in equipos.DefaultIfEmpty()
                   join atiende in bd.Usuarios on incidencia.Iidusuarioatencion equals (int?)atiende.Iidusuario into atienden
                   from atiende in atienden.DefaultIfEmpty()
                   select new IncidenciaCLS
                   {
                       IdIncidencia = incidencia.Iidincidencia,
                       IdUsuario = incidencia.Iidusuario,
                       NombreReporta = usuario.Nombrecompleto,
                       IdLaboratorio = incidencia.Iidlaboratorio,
                       NombreLaboratorio = lab.Nombre,
                       IdEquipo = incidencia.Iidequipo,
                       CodigoEquipo = equipo != null ? equipo.Codigo : "",
                       Descripcion = incidencia.Descripcion,
                       FechaReporte = incidencia.Fechareporte,
                       Estado = incidencia.Estado,
                       FechaAtencion = incidencia.Fechaatencion,
                       ObservacionTecnica = incidencia.Observaciontecnica,
                       NombreAtiende = atiende != null ? atiende.Nombrecompleto : ""
                   };
        }

        // HU-14 / HU-17 / HU-18: el personal autorizado ve todas; los demas usuarios solo las que reportaron
        [Autorizar]
        [HttpGet]
        public async Task<IActionResult> listarIncidencias([FromQuery] string? estado, [FromQuery] int? idLaboratorio,
            [FromQuery] int? idEquipo, [FromQuery] DateOnly? desde, [FromQuery] DateOnly? hasta)
        {
            try
            {
                var veTodas = Roles.Contiene(Roles.AtencionIncidencias, rolActual);
                var idUsuario = idUsuarioActual;
                DateTime? fechaDesde = desde?.ToDateTime(TimeOnly.MinValue);
                DateTime? fechaHasta = hasta?.ToDateTime(TimeOnly.MaxValue);

                var lista = await consulta()
                    .Where(i => (veTodas || i.IdUsuario == idUsuario)
                                && (estado == null || estado == "" || i.Estado == estado)
                                && (idLaboratorio == null || i.IdLaboratorio == idLaboratorio)
                                && (idEquipo == null || i.IdEquipo == idEquipo)
                                && (fechaDesde == null || i.FechaReporte >= fechaDesde)
                                && (fechaHasta == null || i.FechaReporte <= fechaHasta))
                    .OrderByDescending(i => i.FechaReporte)
                    .ToListAsync();

                return Ok(lista);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        // HU-13: registra la incidencia con estado inicial Pendiente
        [Autorizar]
        [HttpPost]
        public async Task<IActionResult> reportarIncidencia([FromBody] IncidenciaCLS oIncidencia)
        {
            try
            {
                if (oIncidencia.IdLaboratorio <= 0)
                {
                    return BadRequest("Seleccione un laboratorio.");
                }
                if (string.IsNullOrWhiteSpace(oIncidencia.Descripcion))
                {
                    return BadRequest("Describa la falla.");
                }

                var lab = await bd.Laboratorios.FirstOrDefaultAsync(l => l.Iidlaboratorio == oIncidencia.IdLaboratorio);
                if (lab == null)
                {
                    return BadRequest("Laboratorio no encontrado.");
                }

                Equipo? equipo = null;
                if (oIncidencia.IdEquipo.HasValue)
                {
                    equipo = await bd.Equipos.FirstOrDefaultAsync(e => e.Iidequipo == oIncidencia.IdEquipo.Value
                                                                        && e.Iidlaboratorio == oIncidencia.IdLaboratorio);
                    if (equipo == null)
                    {
                        return BadRequest("El equipo no pertenece al laboratorio seleccionado.");
                    }
                    if (equipo.Estado == Estados.Operativo)
                    {
                        equipo.Estado = Estados.EnFalla;
                    }
                }

                var idUsuario = idUsuarioActual;
                var reporta = await bd.Usuarios.FirstOrDefaultAsync(u => u.Iidusuario == idUsuario);
                if (reporta == null)
                {
                    return Unauthorized("Usuario no valido.");
                }

                Incidencia nueva = new Incidencia
                {
                    Iidusuario = idUsuario,
                    Iidlaboratorio = oIncidencia.IdLaboratorio,
                    Iidequipo = oIncidencia.IdEquipo,
                    Descripcion = oIncidencia.Descripcion.Trim(),
                    Fechareporte = DateTime.Now,
                    Estado = Estados.Pendiente
                };
                bd.Incidencias.Add(nueva);

                await Avisos.aRolesAsync(bd, new[] { Roles.Encargado, Roles.Tecnico },
                    $"Nueva incidencia en {lab.Nombre}{(equipo != null ? " (" + equipo.Codigo + ")" : "")} reportada por {reporta.Nombrecompleto}.",
                    "gestion-incidencias");

                await bd.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        // HU-15: actualiza estado, fecha de atencion y observacion tecnica
        [Autorizar(Roles.AtencionIncidencias)]
        [HttpPost("actualizar")]
        public async Task<IActionResult> actualizarIncidencia([FromBody] IncidenciaActualizarCLS oActualizar)
        {
            try
            {
                if (!Estados.Incidencia.Contains(oActualizar.Estado))
                {
                    return BadRequest("Estado no valido.");
                }

                var incidencia = await bd.Incidencias.FirstOrDefaultAsync(i => i.Iidincidencia == oActualizar.IdIncidencia);
                if (incidencia == null)
                {
                    return NotFound("Incidencia no encontrada.");
                }
                if (oActualizar.Estado != Estados.Pendiente && string.IsNullOrWhiteSpace(oActualizar.ObservacionTecnica))
                {
                    return BadRequest("Registre la observacion tecnica.");
                }

                var lab = await bd.Laboratorios.FirstAsync(l => l.Iidlaboratorio == incidencia.Iidlaboratorio);

                incidencia.Estado = oActualizar.Estado;
                if (!string.IsNullOrWhiteSpace(oActualizar.ObservacionTecnica))
                {
                    incidencia.Observaciontecnica = oActualizar.ObservacionTecnica.Trim();
                }
                if (oActualizar.Estado != Estados.Pendiente)
                {
                    incidencia.Fechaatencion ??= DateTime.Now;
                    incidencia.Iidusuarioatencion = idUsuarioActual;
                }

                // El estado del equipo acompana a la incidencia
                if (incidencia.Iidequipo.HasValue)
                {
                    var equipo = await bd.Equipos.FirstOrDefaultAsync(e => e.Iidequipo == incidencia.Iidequipo.Value);
                    if (equipo != null)
                    {
                        if (oActualizar.Estado == Estados.Resuelta
                            && (equipo.Estado == Estados.EnFalla || equipo.Estado == Estados.EnMantenimiento))
                        {
                            equipo.Estado = Estados.Operativo;
                        }
                        else if (oActualizar.Estado == Estados.EnAtencion && equipo.Estado == Estados.EnFalla)
                        {
                            equipo.Estado = Estados.EnMantenimiento;
                        }
                    }
                }

                Avisos.aUsuario(bd, incidencia.Iidusuario,
                    $"Tu incidencia en {lab.Nombre} cambio a: {Estados.Texto(oActualizar.Estado)}.", "mis-incidencias");

                await bd.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }
    }
}
