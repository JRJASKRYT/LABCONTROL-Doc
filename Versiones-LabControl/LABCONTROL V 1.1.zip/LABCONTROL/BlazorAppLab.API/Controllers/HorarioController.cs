using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BlazorAppLab.API.Models;
using BlazorAppLab.API.Seguridad;
using BlazorAppLab.entities;

namespace BlazorAppLab.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HorarioController : ApiBaseController
    {
        public HorarioController(BdlabcontrolContext _bd) : base(_bd)
        {
        }

        // HU-03 / HU-11: horarios filtrados por laboratorio y/o periodo
        [Autorizar]
        [HttpGet]
        public async Task<IActionResult> listarHorarios([FromQuery] int? idLaboratorio, [FromQuery] int? idPeriodo)
        {
            try
            {
                var lista = await (from horario in bd.Horarios
                                   join lab in bd.Laboratorios on horario.Iidlaboratorio equals lab.Iidlaboratorio
                                   join periodo in bd.Periodos on horario.Iidperiodo equals periodo.Iidperiodo
                                   where (idLaboratorio == null || horario.Iidlaboratorio == idLaboratorio)
                                         && (idPeriodo == null || horario.Iidperiodo == idPeriodo)
                                   orderby lab.Nombre, horario.Dia, horario.Horainicio
                                   select new HorarioCLS
                                   {
                                       IdHorario = horario.Iidhorario,
                                       IdLaboratorio = horario.Iidlaboratorio,
                                       NombreLaboratorio = lab.Nombre,
                                       IdPeriodo = horario.Iidperiodo,
                                       NombrePeriodo = periodo.Nombre,
                                       Dia = horario.Dia,
                                       HoraInicio = horario.Horainicio,
                                       HoraFin = horario.Horafin,
                                       Actividad = horario.Actividad
                                   }).ToListAsync();

                return Ok(lista);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        // HU-11: registrar o actualizar un horario asociado a laboratorio y periodo
        [Autorizar(Roles.Gestion)]
        [HttpPost]
        public async Task<IActionResult> guardarHorario([FromBody] HorarioCLS oHorario)
        {
            try
            {
                if (oHorario.HoraFin <= oHorario.HoraInicio)
                {
                    return BadRequest("La hora de fin debe ser posterior a la de inicio.");
                }
                if (oHorario.Dia < 1 || oHorario.Dia > 7)
                {
                    return BadRequest("Dia no valido.");
                }
                if (!await bd.Laboratorios.AnyAsync(l => l.Iidlaboratorio == oHorario.IdLaboratorio))
                {
                    return BadRequest("Laboratorio no valido.");
                }
                if (!await bd.Periodos.AnyAsync(p => p.Iidperiodo == oHorario.IdPeriodo))
                {
                    return BadRequest("Periodo no valido.");
                }

                var choque = await bd.Horarios.AnyAsync(h =>
                    h.Iidhorario != oHorario.IdHorario
                    && h.Iidlaboratorio == oHorario.IdLaboratorio
                    && h.Iidperiodo == oHorario.IdPeriodo
                    && h.Dia == oHorario.Dia
                    && h.Horainicio < oHorario.HoraFin && oHorario.HoraInicio < h.Horafin);
                if (choque)
                {
                    return BadRequest("El horario se cruza con otro ya registrado para ese laboratorio, periodo y dia.");
                }

                var actividad = string.IsNullOrWhiteSpace(oHorario.Actividad) ? null : oHorario.Actividad.Trim();

                if (oHorario.IdHorario == 0)
                {
                    Horario nuevo = new Horario
                    {
                        Iidlaboratorio = oHorario.IdLaboratorio,
                        Iidperiodo = oHorario.IdPeriodo,
                        Dia = oHorario.Dia,
                        Horainicio = oHorario.HoraInicio,
                        Horafin = oHorario.HoraFin,
                        Actividad = actividad
                    };
                    bd.Horarios.Add(nuevo);
                }
                else
                {
                    var actual = await bd.Horarios.FirstOrDefaultAsync(h => h.Iidhorario == oHorario.IdHorario);
                    if (actual == null)
                    {
                        return NotFound("Horario no encontrado.");
                    }
                    actual.Iidlaboratorio = oHorario.IdLaboratorio;
                    actual.Iidperiodo = oHorario.IdPeriodo;
                    actual.Dia = oHorario.Dia;
                    actual.Horainicio = oHorario.HoraInicio;
                    actual.Horafin = oHorario.HoraFin;
                    actual.Actividad = actividad;
                }

                await bd.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        [Autorizar(Roles.Gestion)]
        [HttpDelete("{id}")]
        public async Task<IActionResult> eliminarHorario(int id)
        {
            try
            {
                var actual = await bd.Horarios.FirstOrDefaultAsync(h => h.Iidhorario == id);
                if (actual == null)
                {
                    return NotFound("Horario no encontrado.");
                }

                bd.Horarios.Remove(actual);
                await bd.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }
    }
}
