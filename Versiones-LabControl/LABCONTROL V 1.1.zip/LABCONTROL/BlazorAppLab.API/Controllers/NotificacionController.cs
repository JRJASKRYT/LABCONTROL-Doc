using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BlazorAppLab.API.Models;
using BlazorAppLab.API.Seguridad;
using BlazorAppLab.entities;

namespace BlazorAppLab.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificacionController : ApiBaseController
    {
        public NotificacionController(BdlabcontrolContext _bd) : base(_bd)
        {
        }

        // HU-19: cada usuario solo ve sus propias notificaciones
        [Autorizar]
        [HttpGet]
        public async Task<IActionResult> listarMisNotificaciones()
        {
            try
            {
                var idUsuario = idUsuarioActual;
                var lista = await (from n in bd.Notificaciones
                                   where n.Iidusuario == idUsuario
                                   orderby n.Fecha descending
                                   select new NotificacionCLS
                                   {
                                       IdNotificacion = n.Iidnotificacion,
                                       Mensaje = n.Mensaje,
                                       Enlace = n.Enlace,
                                       Fecha = n.Fecha,
                                       Leida = n.Bleida == 1
                                   }).Take(100).ToListAsync();

                return Ok(lista);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        [Autorizar]
        [HttpGet("noleidas")]
        public async Task<IActionResult> contarNoLeidas()
        {
            try
            {
                var idUsuario = idUsuarioActual;
                var cantidad = await bd.Notificaciones.CountAsync(n => n.Iidusuario == idUsuario && n.Bleida == 0);
                return Ok(cantidad);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        [Autorizar]
        [HttpPost("leida/{id}")]
        public async Task<IActionResult> marcarLeida(int id)
        {
            try
            {
                var idUsuario = idUsuarioActual;
                var n = await bd.Notificaciones.FirstOrDefaultAsync(x => x.Iidnotificacion == id && x.Iidusuario == idUsuario);
                if (n != null)
                {
                    n.Bleida = 1;
                    await bd.SaveChangesAsync();
                }
                return Ok();
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        [Autorizar]
        [HttpPost("leidas")]
        public async Task<IActionResult> marcarTodasLeidas()
        {
            try
            {
                var idUsuario = idUsuarioActual;
                var pendientes = await bd.Notificaciones.Where(n => n.Iidusuario == idUsuario && n.Bleida == 0).ToListAsync();
                foreach (var n in pendientes)
                {
                    n.Bleida = 1;
                }
                await bd.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }
    }
}
