using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BlazorAppLab.API.Models;
using BlazorAppLab.API.Seguridad;
using BlazorAppLab.entities;

namespace BlazorAppLab.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TipoUsuarioController : ApiBaseController
    {
        public TipoUsuarioController(BdlabcontrolContext _bd) : base(_bd)
        {
        }

        [Autorizar(Roles.Administrador)]
        [HttpGet]
        public async Task<IActionResult> listarTipoUsuario()
        {
            try
            {
                var lista = await (from tipo in bd.TipoUsuarios
                                   where tipo.Bhabilitado == 1
                                   orderby tipo.Iidtipousuario
                                   select new TipoUsuarioCLS
                                   {
                                       IdTipoUsuario = tipo.Iidtipousuario,
                                       Nombre = tipo.Nombre
                                   }).ToListAsync();

                return Ok(lista);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }
    }
}
