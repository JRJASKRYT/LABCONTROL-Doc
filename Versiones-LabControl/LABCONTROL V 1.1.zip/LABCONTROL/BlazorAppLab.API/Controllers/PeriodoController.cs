using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BlazorAppLab.API.Models;
using BlazorAppLab.API.Seguridad;
using BlazorAppLab.entities;

namespace BlazorAppLab.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PeriodoController : ApiBaseController
    {
        public PeriodoController(BdlabcontrolContext _bd) : base(_bd)
        {
        }

        [Autorizar]
        [HttpGet]
        public async Task<IActionResult> listarPeriodos()
        {
            try
            {
                var lista = await (from periodo in bd.Periodos
                                   orderby periodo.Fechainicio descending
                                   select new PeriodoCLS
                                   {
                                       IdPeriodo = periodo.Iidperiodo,
                                       Nombre = periodo.Nombre,
                                       FechaInicio = periodo.Fechainicio,
                                       FechaFin = periodo.Fechafin,
                                       Vigente = periodo.Bvigente == 1
                                   }).ToListAsync();

                return Ok(lista);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        [Autorizar(Roles.Gestion)]
        [HttpPost]
        public async Task<IActionResult> guardarPeriodo([FromBody] PeriodoCLS oPeriodo)
        {
            try
            {
                var nombre = (oPeriodo.Nombre ?? "").Trim();
                if (nombre == "")
                {
                    return BadRequest("El nombre del periodo es obligatorio.");
                }
                if (oPeriodo.FechaFin < oPeriodo.FechaInicio)
                {
                    return BadRequest("La fecha de fin no puede ser anterior a la de inicio.");
                }

                if (oPeriodo.IdPeriodo == 0)
                {
                    PeriodoAcademico nuevo = new PeriodoAcademico
                    {
                        Nombre = nombre,
                        Fechainicio = oPeriodo.FechaInicio,
                        Fechafin = oPeriodo.FechaFin,
                        Bvigente = oPeriodo.Vigente ? 1 : 0
                    };
                    bd.Periodos.Add(nuevo);
                }
                else
                {
                    var actual = await bd.Periodos.FirstOrDefaultAsync(p => p.Iidperiodo == oPeriodo.IdPeriodo);
                    if (actual == null)
                    {
                        return NotFound("Periodo no encontrado.");
                    }
                    actual.Nombre = nombre;
                    actual.Fechainicio = oPeriodo.FechaInicio;
                    actual.Fechafin = oPeriodo.FechaFin;
                    actual.Bvigente = oPeriodo.Vigente ? 1 : 0;
                }

                await bd.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }
    }
}
