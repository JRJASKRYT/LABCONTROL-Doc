using BlazorAppLab.API.Models;
using Microsoft.AspNetCore.Mvc;

namespace BlazorAppLab.API.Controllers
{
    /// <summary>Base comun: contexto de base de datos y datos del usuario autenticado (tomados del token).</summary>
    public abstract class ApiBaseController : ControllerBase
    {
        protected readonly BdlabcontrolContext bd;

        protected ApiBaseController(BdlabcontrolContext _bd)
        {
            this.bd = _bd;
        }

        protected int idUsuarioActual => HttpContext.Items["IdUsuario"] is int id ? id : 0;

        protected string rolActual => HttpContext.Items["Rol"] as string ?? "";

        protected IActionResult errorServidor(Exception ex)
        {
            return StatusCode(500, ex.InnerException?.Message ?? ex.Message);
        }
    }
}
