using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BlazorAppLab.API.Models;
using BlazorAppLab.API.Seguridad;
using BlazorAppLab.entities;

namespace BlazorAppLab.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EquipoController : ApiBaseController
    {
        public EquipoController(BdlabcontrolContext _bd) : base(_bd)
        {
        }

        // Equipos de un laboratorio (por defecto sin los dados de baja)
        [Autorizar]
        [HttpGet("laboratorio/{idLaboratorio}")]
        public async Task<IActionResult> listarPorLaboratorio(int idLaboratorio, [FromQuery] bool todos = false)
        {
            try
            {
                var lista = await (from equipo in bd.Equipos
                                   join lab in bd.Laboratorios on equipo.Iidlaboratorio equals lab.Iidlaboratorio
                                   where equipo.Iidlaboratorio == idLaboratorio
                                         && (todos || equipo.Estado != Estados.DadoDeBaja)
                                   orderby equipo.Codigo
                                   select new EquipoCLS
                                   {
                                       IdEquipo = equipo.Iidequipo,
                                       IdLaboratorio = equipo.Iidlaboratorio,
                                       NombreLaboratorio = lab.Nombre,
                                       Codigo = equipo.Codigo,
                                       Nombre = equipo.Nombre,
                                       Estado = equipo.Estado
                                   }).ToListAsync();

                return Ok(lista);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        [Autorizar(Roles.Gestion)]
        [HttpPost]
        public async Task<IActionResult> guardarEquipo([FromBody] EquipoCLS oEquipo)
        {
            try
            {
                var codigo = (oEquipo.Codigo ?? "").Trim();
                var nombre = (oEquipo.Nombre ?? "").Trim();

                if (codigo == "" || nombre == "")
                {
                    return BadRequest("El codigo y el nombre son obligatorios.");
                }
                if (!Estados.Equipo.Contains(oEquipo.Estado))
                {
                    return BadRequest("Estado no valido.");
                }
                if (!await bd.Laboratorios.AnyAsync(l => l.Iidlaboratorio == oEquipo.IdLaboratorio))
                {
                    return BadRequest("Laboratorio no valido.");
                }
                if (await bd.Equipos.AnyAsync(e => e.Codigo == codigo && e.Iidequipo != oEquipo.IdEquipo))
                {
                    return BadRequest("Ya existe un equipo con ese codigo.");
                }

                if (oEquipo.IdEquipo == 0)
                {
                    Equipo nuevo = new Equipo
                    {
                        Iidlaboratorio = oEquipo.IdLaboratorio,
                        Codigo = codigo,
                        Nombre = nombre,
                        Estado = oEquipo.Estado
                    };
                    bd.Equipos.Add(nuevo);
                }
                else
                {
                    var actual = await bd.Equipos.FirstOrDefaultAsync(e => e.Iidequipo == oEquipo.IdEquipo);
                    if (actual == null)
                    {
                        return NotFound("Equipo no encontrado.");
                    }
                    actual.Codigo = codigo;
                    actual.Nombre = nombre;
                    actual.Estado = oEquipo.Estado;
                }

                await bd.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }

        // Cambia solo el estado de un equipo
        [Autorizar(Roles.AtencionIncidencias)]
        [HttpPost("estado")]
        public async Task<IActionResult> cambiarEstado([FromBody] EquipoCLS oEquipo)
        {
            try
            {
                if (!Estados.Equipo.Contains(oEquipo.Estado))
                {
                    return BadRequest("Estado no valido.");
                }

                var actual = await bd.Equipos.FirstOrDefaultAsync(e => e.Iidequipo == oEquipo.IdEquipo);
                if (actual == null)
                {
                    return NotFound("Equipo no encontrado.");
                }

                actual.Estado = oEquipo.Estado;
                await bd.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }
    }
}
