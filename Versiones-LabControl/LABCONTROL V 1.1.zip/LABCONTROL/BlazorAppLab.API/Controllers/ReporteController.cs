using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BlazorAppLab.API.Models;
using BlazorAppLab.API.Seguridad;
using BlazorAppLab.entities;

namespace BlazorAppLab.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReporteController : ApiBaseController
    {
        public ReporteController(BdlabcontrolContext _bd) : base(_bd)
        {
        }

        // HU-20: indicadores y estadisticas calculados con los datos registrados
        [Autorizar(Roles.Gestion)]
        [HttpGet("indicadores")]
        public async Task<IActionResult> indicadores()
        {
            try
            {
                var r = new IndicadoresCLS
                {
                    TotalLaboratorios = await bd.Laboratorios.CountAsync(l => l.Estado != Estados.Inactivo),
                    LaboratoriosDisponibles = await bd.Laboratorios.CountAsync(l => l.Estado == Estados.Disponible),
                    TotalEquipos = await bd.Equipos.CountAsync(e => e.Estado != Estados.DadoDeBaja),
                    EquiposConFalla = await bd.Equipos.CountAsync(e => e.Estado == Estados.EnFalla || e.Estado == Estados.EnMantenimiento),
                    SolicitudesPendientes = await bd.Solicitudes.CountAsync(s => s.Estado == Estados.Pendiente),
                    SolicitudesAprobadas = await bd.Solicitudes.CountAsync(s => s.Estado == Estados.Aprobada),
                    SolicitudesRechazadas = await bd.Solicitudes.CountAsync(s => s.Estado == Estados.Rechazada),
                    IncidenciasPendientes = await bd.Incidencias.CountAsync(i => i.Estado == Estados.Pendiente),
                    IncidenciasEnAtencion = await bd.Incidencias.CountAsync(i => i.Estado == Estados.EnAtencion),
                    IncidenciasResueltas = await bd.Incidencias.CountAsync(i => i.Estado == Estados.Resuelta)
                };

                var resueltas = r.SolicitudesAprobadas + r.SolicitudesRechazadas;
                r.TasaAprobacion = resueltas == 0 ? 0 : Math.Round(100.0 * r.SolicitudesAprobadas / resueltas, 1);

                var inicioMes = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
                r.UtilizacionesDelMes = await bd.Utilizaciones.CountAsync(u => u.Fecha >= inicioMes);

                var tiempos = await (from i in bd.Incidencias
                                     where i.Estado == Estados.Resuelta && i.Fechaatencion != null
                                     select new { i.Fechareporte, i.Fechaatencion }).ToListAsync();
                if (tiempos.Count > 0)
                {
                    r.HorasMediasAtencion = Math.Round(tiempos.Average(t => (t.Fechaatencion!.Value - t.Fechareporte).TotalHours), 1);
                }

                var labs = await bd.Laboratorios.Where(l => l.Estado != Estados.Inactivo).OrderBy(l => l.Nombre).ToListAsync();
                var aprobadas = await (from s in bd.Solicitudes
                                       where s.Estado == Estados.Aprobada
                                       select new { s.Iidlaboratorio, s.Horainicio, s.Horafin }).ToListAsync();
                var usos = await (from u in bd.Utilizaciones
                                  group u by u.Iidlaboratorio into g
                                  select new { Id = g.Key, N = g.Count() }).ToListAsync();
                var incs = await (from i in bd.Incidencias
                                  group i by i.Iidlaboratorio into g
                                  select new { Id = g.Key, N = g.Count() }).ToListAsync();

                foreach (var lab in labs)
                {
                    var mias = aprobadas.Where(a => a.Iidlaboratorio == lab.Iidlaboratorio).ToList();
                    r.UsoPorLaboratorio.Add(new UsoLaboratorioCLS
                    {
                        Laboratorio = lab.Nombre,
                        ReservasAprobadas = mias.Count,
                        HorasReservadas = Math.Round(mias.Sum(a => (a.Horafin - a.Horainicio).TotalHours), 1),
                        Utilizaciones = usos.FirstOrDefault(x => x.Id == lab.Iidlaboratorio)?.N ?? 0,
                        Incidencias = incs.FirstOrDefault(x => x.Id == lab.Iidlaboratorio)?.N ?? 0
                    });
                }

                var desde = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-5);
                var fechas = await (from s in bd.Solicitudes where s.Fechacreacion >= desde select s.Fechacreacion).ToListAsync();
                for (int m = 0; m < 6; m++)
                {
                    var mes = desde.AddMonths(m);
                    r.SolicitudesPorMes.Add(new MesCantidadCLS
                    {
                        Mes = mes.ToString("MM/yyyy"),
                        Cantidad = fechas.Count(f => f.Year == mes.Year && f.Month == mes.Month)
                    });
                }

                return Ok(r);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }
    }
}
