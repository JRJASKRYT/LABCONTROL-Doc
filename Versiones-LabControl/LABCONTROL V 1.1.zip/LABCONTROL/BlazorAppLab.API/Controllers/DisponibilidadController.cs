using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BlazorAppLab.API.Logica;
using BlazorAppLab.API.Models;
using BlazorAppLab.API.Seguridad;
using BlazorAppLab.entities;

namespace BlazorAppLab.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DisponibilidadController : ApiBaseController
    {
        public DisponibilidadController(BdlabcontrolContext _bd) : base(_bd)
        {
        }

        // HU-02: laboratorios disponibles / no disponibles segun fecha y horario
        [Autorizar]
        [HttpGet]
        public async Task<IActionResult> consultar([FromQuery] DateOnly fecha, [FromQuery] TimeOnly horaInicio, [FromQuery] TimeOnly horaFin)
        {
            try
            {
                if (horaFin <= horaInicio)
                {
                    return BadRequest("La hora de fin debe ser posterior a la hora de inicio.");
                }

                var labs = await bd.Laboratorios
                    .Where(l => l.Estado != Estados.Inactivo)
                    .OrderBy(l => l.Nombre)
                    .ToListAsync();

                var lista = new List<DisponibilidadCLS>();
                foreach (var lab in labs)
                {
                    var motivo = await DisponibilidadHelper.motivoNoDisponibleAsync(bd, lab, fecha, horaInicio, horaFin);
                    lista.Add(new DisponibilidadCLS
                    {
                        IdLaboratorio = lab.Iidlaboratorio,
                        Nombre = lab.Nombre,
                        Ubicacion = lab.Ubicacion,
                        Capacidad = lab.Capacidad,
                        Disponible = motivo == null,
                        Motivo = motivo ?? "Libre en la franja seleccionada"
                    });
                }

                return Ok(lista);
            }
            catch (Exception ex)
            {
                return errorServidor(ex);
            }
        }
    }
}
