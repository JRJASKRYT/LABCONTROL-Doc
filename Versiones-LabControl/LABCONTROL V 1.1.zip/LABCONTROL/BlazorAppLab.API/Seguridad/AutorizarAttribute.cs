using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace BlazorAppLab.API.Seguridad
{
    /// <summary>
    /// Exige una sesion valida (cabecera Authorization: Bearer token).
    /// Con una lista de roles separada por comas, ademas exige que el usuario tenga alguno de esos roles.
    /// Ejemplos: [Autorizar]  /  [Autorizar(Roles.Gestion)]
    /// </summary>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class AutorizarAttribute : Attribute, IAuthorizationFilter
    {
        private readonly string[] roles;

        public AutorizarAttribute(string rolesPermitidos = "")
        {
            roles = rolesPermitidos.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
        }

        public void OnAuthorization(AuthorizationFilterContext contexto)
        {
            var cabecera = contexto.HttpContext.Request.Headers.Authorization.ToString();
            if (!cabecera.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            {
                contexto.Result = new UnauthorizedObjectResult("Debe iniciar sesion.");
                return;
            }

            var tokenService = contexto.HttpContext.RequestServices.GetRequiredService<TokenService>();
            var datos = tokenService.validar(cabecera.Substring(7).Trim());
            if (datos == null)
            {
                contexto.Result = new UnauthorizedObjectResult("La sesion no es valida o ya vencio. Inicie sesion nuevamente.");
                return;
            }

            if (roles.Length > 0 && !roles.Contains(datos.Value.rol))
            {
                contexto.Result = new ObjectResult("No tiene permiso para realizar esta accion.") { StatusCode = 403 };
                return;
            }

            contexto.HttpContext.Items["IdUsuario"] = datos.Value.idUsuario;
            contexto.HttpContext.Items["Rol"] = datos.Value.rol;
        }
    }
}
