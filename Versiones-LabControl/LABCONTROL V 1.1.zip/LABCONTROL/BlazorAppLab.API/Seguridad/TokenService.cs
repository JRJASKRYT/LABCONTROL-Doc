using System.Security.Cryptography;
using System.Text;

namespace BlazorAppLab.API.Seguridad
{
    /// <summary>
    /// Token de sesion firmado con HMAC-SHA256: base64url(idUsuario|rol|expiracion).firma
    /// El cliente lo envia en "Authorization: Bearer ..." y la API lo valida en cada peticion.
    /// </summary>
    public class TokenService
    {
        private readonly byte[] clave;
        private readonly int horasSesion;

        public TokenService(IConfiguration configuracion)
        {
            var texto = configuracion["Seguridad:ClaveToken"];
            if (string.IsNullOrWhiteSpace(texto) || texto.Length < 32)
            {
                throw new InvalidOperationException("Configure Seguridad:ClaveToken en appsettings.json (minimo 32 caracteres).");
            }
            clave = Encoding.UTF8.GetBytes(texto);
            horasSesion = int.TryParse(configuracion["Seguridad:HorasSesion"], out var h) && h > 0 ? h : 8;
        }

        public string crear(int idUsuario, string rol)
        {
            var expira = DateTimeOffset.UtcNow.AddHours(horasSesion).ToUnixTimeSeconds();
            var cuerpo = aBase64Url(Encoding.UTF8.GetBytes($"{idUsuario}|{rol}|{expira}"));
            return cuerpo + "." + firmar(cuerpo);
        }

        public (int idUsuario, string rol)? validar(string token)
        {
            var partes = token.Split('.');
            if (partes.Length != 2) return null;

            var firmaEsperada = Encoding.ASCII.GetBytes(firmar(partes[0]));
            var firmaRecibida = Encoding.ASCII.GetBytes(partes[1]);
            if (!CryptographicOperations.FixedTimeEquals(firmaEsperada, firmaRecibida)) return null;

            try
            {
                var datos = Encoding.UTF8.GetString(deBase64Url(partes[0])).Split('|');
                if (datos.Length != 3) return null;
                if (!int.TryParse(datos[0], out var id) || !long.TryParse(datos[2], out var expira)) return null;
                if (DateTimeOffset.UtcNow.ToUnixTimeSeconds() > expira) return null;
                return (id, datos[1]);
            }
            catch (FormatException)
            {
                return null;
            }
        }

        private string firmar(string cuerpo) =>
            aBase64Url(HMACSHA256.HashData(clave, Encoding.ASCII.GetBytes(cuerpo)));

        private static string aBase64Url(byte[] datos) =>
            Convert.ToBase64String(datos).TrimEnd('=').Replace('+', '-').Replace('/', '_');

        private static byte[] deBase64Url(string texto)
        {
            var s = texto.Replace('-', '+').Replace('_', '/');
            switch (s.Length % 4)
            {
                case 2: s += "=="; break;
                case 3: s += "="; break;
            }
            return Convert.FromBase64String(s);
        }
    }
}
