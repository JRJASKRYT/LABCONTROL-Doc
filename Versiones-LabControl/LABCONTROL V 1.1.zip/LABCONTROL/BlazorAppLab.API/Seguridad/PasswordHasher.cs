using System.Security.Cryptography;

namespace BlazorAppLab.API.Seguridad
{
    /// <summary>Hash de contrasenas con PBKDF2 (SHA-256, 100000 iteraciones, sal aleatoria). Formato: iteraciones.sal.hash</summary>
    public static class PasswordHasher
    {
        private const int Iteraciones = 100_000;

        public static string calcularHash(string password)
        {
            var sal = RandomNumberGenerator.GetBytes(16);
            var hash = Rfc2898DeriveBytes.Pbkdf2(password, sal, Iteraciones, HashAlgorithmName.SHA256, 32);
            return $"{Iteraciones}.{Convert.ToBase64String(sal)}.{Convert.ToBase64String(hash)}";
        }

        public static bool verificar(string password, string almacenado)
        {
            var partes = almacenado.Split('.');
            if (partes.Length != 3 || !int.TryParse(partes[0], out var iteraciones)) return false;
            try
            {
                var sal = Convert.FromBase64String(partes[1]);
                var esperado = Convert.FromBase64String(partes[2]);
                var actual = Rfc2898DeriveBytes.Pbkdf2(password, sal, iteraciones, HashAlgorithmName.SHA256, esperado.Length);
                return CryptographicOperations.FixedTimeEquals(actual, esperado);
            }
            catch (FormatException)
            {
                return false;
            }
        }
    }
}
