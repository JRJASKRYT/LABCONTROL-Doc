using BlazorAppLab.API.Models;
using BlazorAppLab.API.Seguridad;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers(options =>
{
    // Las propiedades no nulas no se tratan como obligatorias de forma implicita (solo las marcadas con [Required])
    options.SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true;
})
.ConfigureApiBehaviorOptions(options =>
{
    // Los errores de validacion de los DTO se devuelven como un texto simple para mostrarlos en pantalla
    options.InvalidModelStateResponseFactory = contexto =>
    {
        var mensajes = contexto.ModelState.Values
            .SelectMany(v => v.Errors)
            .Select(e => e.ErrorMessage)
            .Where(m => !string.IsNullOrWhiteSpace(m));
        return new Microsoft.AspNetCore.Mvc.BadRequestObjectResult(string.Join(" ", mensajes));
    };
});
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<BdlabcontrolContext>(option =>
{
    option.UseSqlServer(builder.Configuration.GetConnectionString("CadenaSQL"));
});

// Genera y valida los tokens de sesion que se envian en la cabecera Authorization
builder.Services.AddSingleton<TokenService>();

builder.Services.AddCors(option =>
{
    option.AddPolicy("CorsPolicy", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("CorsPolicy");

app.UseAuthorization();

app.MapControllers();

app.Run();
