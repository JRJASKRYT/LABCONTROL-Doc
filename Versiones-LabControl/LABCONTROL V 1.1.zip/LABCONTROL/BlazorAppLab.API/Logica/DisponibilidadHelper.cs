using BlazorAppLab.API.Models;
using BlazorAppLab.entities;
using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.API.Logica
{
    public static class DisponibilidadHelper
    {
        /// <summary>
        /// Devuelve null si el laboratorio esta libre en la fecha y franja indicadas; si no, el motivo.
        /// No esta disponible si: su estado no es "Disponible", choca con un horario academico del periodo vigente
        /// o ya tiene una solicitud aprobada que se cruza.
        /// </summary>
        public static async Task<string?> motivoNoDisponibleAsync(BdlabcontrolContext bd, Laboratorio lab,
            DateOnly fecha, TimeOnly inicio, TimeOnly fin, int excluirSolicitud = 0)
        {
            if (lab.Estado != Estados.Disponible)
            {
                return "Laboratorio " + Estados.Texto(lab.Estado).ToLower();
            }

            var dia = Dias.DeFecha(fecha);

            var horario = await (from h in bd.Horarios
                                 join p in bd.Periodos on h.Iidperiodo equals p.Iidperiodo
                                 where h.Iidlaboratorio == lab.Iidlaboratorio
                                       && h.Dia == dia
                                       && p.Bvigente == 1
                                       && p.Fechainicio <= fecha && p.Fechafin >= fecha
                                       && h.Horainicio < fin && inicio < h.Horafin
                                 select h).FirstOrDefaultAsync();
            if (horario != null)
            {
                var actividad = string.IsNullOrWhiteSpace(horario.Actividad) ? "" : " " + horario.Actividad;
                return $"Ocupado por clase ({horario.Horainicio:HH:mm}-{horario.Horafin:HH:mm}{actividad})";
            }

            var reserva = await (from s in bd.Solicitudes
                                 where s.Iidlaboratorio == lab.Iidlaboratorio
                                       && s.Fecha == fecha
                                       && s.Estado == Estados.Aprobada
                                       && s.Iidsolicitud != excluirSolicitud
                                       && s.Horainicio < fin && inicio < s.Horafin
                                 select s).FirstOrDefaultAsync();
            if (reserva != null)
            {
                return $"Reservado ({reserva.Horainicio:HH:mm}-{reserva.Horafin:HH:mm})";
            }

            return null;
        }
    }
}
