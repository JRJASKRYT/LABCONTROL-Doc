using BlazorAppLab.API.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.API.Logica
{
    /// <summary>Genera las notificaciones (HU-19) en el mismo SaveChanges que el evento que las origina.</summary>
    public static class Avisos
    {
        public static void aUsuario(BdlabcontrolContext bd, int idUsuario, string mensaje, string? enlace = null)
        {
            bd.Notificaciones.Add(new Notificacion
            {
                Iidusuario = idUsuario,
                Mensaje = mensaje.Length > 300 ? mensaje.Substring(0, 300) : mensaje,
                Enlace = enlace,
                Fecha = DateTime.Now,
                Bleida = 0
            });
        }

        public static async Task aRolesAsync(BdlabcontrolContext bd, string[] roles, string mensaje, string? enlace = null)
        {
            var ids = await (from usuario in bd.Usuarios
                             join tipo in bd.TipoUsuarios on usuario.Iidtipousuario equals tipo.Iidtipousuario
                             where usuario.Bhabilitado == 1 && roles.Contains(tipo.Nombre)
                             select usuario.Iidusuario).ToListAsync();

            foreach (var id in ids)
            {
                aUsuario(bd, id, mensaje, enlace);
            }
        }
    }
}
