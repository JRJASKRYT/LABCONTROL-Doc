using System;

namespace BlazorAppLab.API.Models;

public partial class Notificacion
{
    public int Iidnotificacion { get; set; }
    public int Iidusuario { get; set; }
    public string Mensaje { get; set; } = string.Empty;
    public string? Enlace { get; set; }
    public DateTime Fecha { get; set; }
    public int Bleida { get; set; }
}
