using System;

namespace BlazorAppLab.API.Models;

public partial class Solicitud
{
    public int Iidsolicitud { get; set; }
    public int Iidusuario { get; set; }
    public int Iidlaboratorio { get; set; }
    public DateOnly Fecha { get; set; }
    public TimeOnly Horainicio { get; set; }
    public TimeOnly Horafin { get; set; }
    public string Motivo { get; set; } = string.Empty;
    public string Estado { get; set; } = string.Empty;
    public DateTime Fechacreacion { get; set; }
    public int? Iidusuariogestion { get; set; }
    public DateTime? Fechagestion { get; set; }
    public string? Observaciongestion { get; set; }
}
