using System;

namespace BlazorAppLab.API.Models;

public partial class Utilizacion
{
    public int Iidutilizacion { get; set; }
    public int Iidusuario { get; set; }
    public int Iidlaboratorio { get; set; }
    public int? Iidequipo { get; set; }
    public DateTime Fecha { get; set; }
    public string? Observacion { get; set; }
    public int Iidusuarioregistro { get; set; }
}
