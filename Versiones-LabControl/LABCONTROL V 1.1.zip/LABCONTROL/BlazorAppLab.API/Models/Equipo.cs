using System;

namespace BlazorAppLab.API.Models;

public partial class Equipo
{
    public int Iidequipo { get; set; }
    public int Iidlaboratorio { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public string Estado { get; set; } = string.Empty;
}
