using System;

namespace BlazorAppLab.API.Models;

public partial class Horario
{
    public int Iidhorario { get; set; }
    public int Iidlaboratorio { get; set; }
    public int Iidperiodo { get; set; }
    public int Dia { get; set; }
    public TimeOnly Horainicio { get; set; }
    public TimeOnly Horafin { get; set; }
    public string? Actividad { get; set; }
}
