using System;

namespace BlazorAppLab.API.Models;

public partial class PeriodoAcademico
{
    public int Iidperiodo { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public DateOnly Fechainicio { get; set; }
    public DateOnly Fechafin { get; set; }
    public int Bvigente { get; set; }
}
