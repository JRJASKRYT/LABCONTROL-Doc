using System;

namespace BlazorAppLab.API.Models;

public partial class TipoUsuario
{
    public int Iidtipousuario { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public int Bhabilitado { get; set; }
}
