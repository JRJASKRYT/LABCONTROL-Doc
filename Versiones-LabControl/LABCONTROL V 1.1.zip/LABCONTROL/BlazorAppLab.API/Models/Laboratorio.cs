using System;

namespace BlazorAppLab.API.Models;

public partial class Laboratorio
{
    public int Iidlaboratorio { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string Ubicacion { get; set; } = string.Empty;
    public int Capacidad { get; set; }
    public string Estado { get; set; } = string.Empty;
    public string? Descripcion { get; set; }
}
