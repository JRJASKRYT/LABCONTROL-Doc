using System;

namespace BlazorAppLab.API.Models;

public partial class Incidencia
{
    public int Iidincidencia { get; set; }
    public int Iidusuario { get; set; }
    public int Iidlaboratorio { get; set; }
    public int? Iidequipo { get; set; }
    public string Descripcion { get; set; } = string.Empty;
    public DateTime Fechareporte { get; set; }
    public string Estado { get; set; } = string.Empty;
    public DateTime? Fechaatencion { get; set; }
    public string? Observaciontecnica { get; set; }
    public int? Iidusuarioatencion { get; set; }
}
