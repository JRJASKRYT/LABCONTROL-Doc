using System;
using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.API.Models;

public partial class BdlabcontrolContext : DbContext
{
    public BdlabcontrolContext()
    {
    }

    public BdlabcontrolContext(DbContextOptions<BdlabcontrolContext> options)
        : base(options)
    {
    }

    public virtual DbSet<TipoUsuario> TipoUsuarios { get; set; }

    public virtual DbSet<Usuario> Usuarios { get; set; }

    public virtual DbSet<Laboratorio> Laboratorios { get; set; }

    public virtual DbSet<Equipo> Equipos { get; set; }

    public virtual DbSet<PeriodoAcademico> Periodos { get; set; }

    public virtual DbSet<Horario> Horarios { get; set; }

    public virtual DbSet<Solicitud> Solicitudes { get; set; }

    public virtual DbSet<Utilizacion> Utilizaciones { get; set; }

    public virtual DbSet<Incidencia> Incidencias { get; set; }

    public virtual DbSet<Notificacion> Notificaciones { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<TipoUsuario>(entity =>
        {
            entity.HasKey(e => e.Iidtipousuario);
            entity.ToTable("TipoUsuario");
            entity.Property(e => e.Iidtipousuario).HasColumnName("IIDTIPOUSUARIO");
            entity.Property(e => e.Nombre).HasColumnName("NOMBRE");
            entity.Property(e => e.Bhabilitado).HasColumnName("BHABILITADO");
        });

        modelBuilder.Entity<Usuario>(entity =>
        {
            entity.HasKey(e => e.Iidusuario);
            entity.ToTable("Usuario");
            entity.Property(e => e.Iidusuario).HasColumnName("IIDUSUARIO");
            entity.Property(e => e.Nombrecompleto).HasColumnName("NOMBRECOMPLETO");
            entity.Property(e => e.Login).HasColumnName("LOGIN");
            entity.Property(e => e.Correo).HasColumnName("CORREO");
            entity.Property(e => e.Password).HasColumnName("PASSWORD");
            entity.Property(e => e.Iidtipousuario).HasColumnName("IIDTIPOUSUARIO");
            entity.Property(e => e.Bhabilitado).HasColumnName("BHABILITADO");
            entity.Property(e => e.Fecharegistro).HasColumnName("FECHAREGISTRO");
        });

        modelBuilder.Entity<Laboratorio>(entity =>
        {
            entity.HasKey(e => e.Iidlaboratorio);
            entity.ToTable("Laboratorio");
            entity.Property(e => e.Iidlaboratorio).HasColumnName("IIDLABORATORIO");
            entity.Property(e => e.Nombre).HasColumnName("NOMBRE");
            entity.Property(e => e.Ubicacion).HasColumnName("UBICACION");
            entity.Property(e => e.Capacidad).HasColumnName("CAPACIDAD");
            entity.Property(e => e.Estado).HasColumnName("ESTADO");
            entity.Property(e => e.Descripcion).HasColumnName("DESCRIPCION");
        });

        modelBuilder.Entity<Equipo>(entity =>
        {
            entity.HasKey(e => e.Iidequipo);
            entity.ToTable("Equipo");
            entity.Property(e => e.Iidequipo).HasColumnName("IIDEQUIPO");
            entity.Property(e => e.Iidlaboratorio).HasColumnName("IIDLABORATORIO");
            entity.Property(e => e.Codigo).HasColumnName("CODIGO");
            entity.Property(e => e.Nombre).HasColumnName("NOMBRE");
            entity.Property(e => e.Estado).HasColumnName("ESTADO");
        });

        modelBuilder.Entity<PeriodoAcademico>(entity =>
        {
            entity.HasKey(e => e.Iidperiodo);
            entity.ToTable("PeriodoAcademico");
            entity.Property(e => e.Iidperiodo).HasColumnName("IIDPERIODO");
            entity.Property(e => e.Nombre).HasColumnName("NOMBRE");
            entity.Property(e => e.Fechainicio).HasColumnName("FECHAINICIO");
            entity.Property(e => e.Fechafin).HasColumnName("FECHAFIN");
            entity.Property(e => e.Bvigente).HasColumnName("BVIGENTE");
        });

        modelBuilder.Entity<Horario>(entity =>
        {
            entity.HasKey(e => e.Iidhorario);
            entity.ToTable("Horario");
            entity.Property(e => e.Iidhorario).HasColumnName("IIDHORARIO");
            entity.Property(e => e.Iidlaboratorio).HasColumnName("IIDLABORATORIO");
            entity.Property(e => e.Iidperiodo).HasColumnName("IIDPERIODO");
            entity.Property(e => e.Dia).HasColumnName("DIA");
            entity.Property(e => e.Horainicio).HasColumnName("HORAINICIO");
            entity.Property(e => e.Horafin).HasColumnName("HORAFIN");
            entity.Property(e => e.Actividad).HasColumnName("ACTIVIDAD");
        });

        modelBuilder.Entity<Solicitud>(entity =>
        {
            entity.HasKey(e => e.Iidsolicitud);
            entity.ToTable("Solicitud");
            entity.Property(e => e.Iidsolicitud).HasColumnName("IIDSOLICITUD");
            entity.Property(e => e.Iidusuario).HasColumnName("IIDUSUARIO");
            entity.Property(e => e.Iidlaboratorio).HasColumnName("IIDLABORATORIO");
            entity.Property(e => e.Fecha).HasColumnName("FECHA");
            entity.Property(e => e.Horainicio).HasColumnName("HORAINICIO");
            entity.Property(e => e.Horafin).HasColumnName("HORAFIN");
            entity.Property(e => e.Motivo).HasColumnName("MOTIVO");
            entity.Property(e => e.Estado).HasColumnName("ESTADO");
            entity.Property(e => e.Fechacreacion).HasColumnName("FECHACREACION");
            entity.Property(e => e.Iidusuariogestion).HasColumnName("IIDUSUARIOGESTION");
            entity.Property(e => e.Fechagestion).HasColumnName("FECHAGESTION");
            entity.Property(e => e.Observaciongestion).HasColumnName("OBSERVACIONGESTION");
        });

        modelBuilder.Entity<Utilizacion>(entity =>
        {
            entity.HasKey(e => e.Iidutilizacion);
            entity.ToTable("Utilizacion");
            entity.Property(e => e.Iidutilizacion).HasColumnName("IIDUTILIZACION");
            entity.Property(e => e.Iidusuario).HasColumnName("IIDUSUARIO");
            entity.Property(e => e.Iidlaboratorio).HasColumnName("IIDLABORATORIO");
            entity.Property(e => e.Iidequipo).HasColumnName("IIDEQUIPO");
            entity.Property(e => e.Fecha).HasColumnName("FECHA");
            entity.Property(e => e.Observacion).HasColumnName("OBSERVACION");
            entity.Property(e => e.Iidusuarioregistro).HasColumnName("IIDUSUARIOREGISTRO");
        });

        modelBuilder.Entity<Incidencia>(entity =>
        {
            entity.HasKey(e => e.Iidincidencia);
            entity.ToTable("Incidencia");
            entity.Property(e => e.Iidincidencia).HasColumnName("IIDINCIDENCIA");
            entity.Property(e => e.Iidusuario).HasColumnName("IIDUSUARIO");
            entity.Property(e => e.Iidlaboratorio).HasColumnName("IIDLABORATORIO");
            entity.Property(e => e.Iidequipo).HasColumnName("IIDEQUIPO");
            entity.Property(e => e.Descripcion).HasColumnName("DESCRIPCION");
            entity.Property(e => e.Fechareporte).HasColumnName("FECHAREPORTE");
            entity.Property(e => e.Estado).HasColumnName("ESTADO");
            entity.Property(e => e.Fechaatencion).HasColumnName("FECHAATENCION");
            entity.Property(e => e.Observaciontecnica).HasColumnName("OBSERVACIONTECNICA");
            entity.Property(e => e.Iidusuarioatencion).HasColumnName("IIDUSUARIOATENCION");
        });

        modelBuilder.Entity<Notificacion>(entity =>
        {
            entity.HasKey(e => e.Iidnotificacion);
            entity.ToTable("Notificacion");
            entity.Property(e => e.Iidnotificacion).HasColumnName("IIDNOTIFICACION");
            entity.Property(e => e.Iidusuario).HasColumnName("IIDUSUARIO");
            entity.Property(e => e.Mensaje).HasColumnName("MENSAJE");
            entity.Property(e => e.Enlace).HasColumnName("ENLACE");
            entity.Property(e => e.Fecha).HasColumnName("FECHA");
            entity.Property(e => e.Bleida).HasColumnName("BLEIDA");
        });

    }
}
