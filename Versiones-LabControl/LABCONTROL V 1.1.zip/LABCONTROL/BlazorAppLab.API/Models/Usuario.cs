using System;

namespace BlazorAppLab.API.Models;

public partial class Usuario
{
    public int Iidusuario { get; set; }
    public string Nombrecompleto { get; set; } = string.Empty;
    public string Login { get; set; } = string.Empty;
    public string Correo { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public int Iidtipousuario { get; set; }
    public int Bhabilitado { get; set; }
    public DateTime Fecharegistro { get; set; }
}
