using System.Text.Json;
using BlazorAppLab.entities;
using Microsoft.JSInterop;

namespace BlazorAppLab.Services
{
    // Guarda el usuario que inicio sesion y su token. Se registra como Scoped, asi que se comparte
    // entre todos los componentes. Ademas se guarda en el sessionStorage del navegador para que
    // no se pierda al recargar la pagina (se borra al cerrar la pestana).
    public class SesionService
    {
        private const string Clave = "labcontrol_sesion";

        private readonly HttpClient http;
        private readonly IJSRuntime js;
        private Task? restauracion;

        public UsuarioSesionCLS? UsuarioActual { get; private set; }

        public bool EstaLogueado => UsuarioActual != null;

        public event Action? OnCambio;

        public SesionService(HttpClient _http, IJSRuntime _js)
        {
            this.http = _http;
            this.js = _js;
        }

        // Se puede llamar muchas veces: la restauracion solo se hace una vez
        public Task RestaurarAsync()
        {
            restauracion ??= restaurarInterno();
            return restauracion;
        }

        private async Task restaurarInterno()
        {
            try
            {
                var json = await js.InvokeAsync<string?>("sessionStorage.getItem", Clave);
                if (!string.IsNullOrEmpty(json))
                {
                    var usuario = JsonSerializer.Deserialize<UsuarioSesionCLS>(json);
                    if (usuario != null && !string.IsNullOrEmpty(usuario.Token))
                    {
                        aplicar(usuario);
                    }
                }
            }
            catch
            {
                // sin sessionStorage disponible: simplemente no hay sesion que restaurar
            }
            OnCambio?.Invoke();
        }

        private void aplicar(UsuarioSesionCLS usuario)
        {
            UsuarioActual = usuario;
            http.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", usuario.Token);
        }

        public async Task IniciarSesionAsync(UsuarioSesionCLS usuario)
        {
            restauracion = Task.CompletedTask;
            aplicar(usuario);
            try
            {
                await js.InvokeVoidAsync("sessionStorage.setItem", Clave, JsonSerializer.Serialize(usuario));
            }
            catch
            {
            }
            OnCambio?.Invoke();
        }

        public void CerrarSesion()
        {
            UsuarioActual = null;
            http.DefaultRequestHeaders.Authorization = null;
            _ = olvidar();
            OnCambio?.Invoke();
        }

        private async Task olvidar()
        {
            try
            {
                await js.InvokeVoidAsync("sessionStorage.removeItem", Clave);
            }
            catch
            {
            }
        }

        // Espera a que se restaure la sesion y comprueba (opcionalmente) que el rol este permitido
        public async Task<bool> AutorizadoAsync(string? roles = null)
        {
            await RestaurarAsync();
            if (!EstaLogueado)
            {
                return false;
            }
            return roles == null || Roles.Contiene(roles, UsuarioActual!.NombreTipoUsuario);
        }

        public bool TieneRol(string roles) =>
            UsuarioActual != null && Roles.Contiene(roles, UsuarioActual.NombreTipoUsuario);
    }
}
