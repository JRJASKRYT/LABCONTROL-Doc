using BlazorAppLab.entities;

namespace BlazorAppLab.Services
{
    public class SolicitudService : ServicioBase
    {
        public SolicitudService(HttpClient _http, SesionService _sesion) : base(_http, _sesion)
        {
        }

        public Task<List<SolicitudCLS>> listarMisSolicitudes(string? estado = null) =>
            obtenerLista<SolicitudCLS>("api/Solicitud/mis" + consulta(("estado", estado)));

        public Task<List<SolicitudCLS>> listarPendientes() => obtenerLista<SolicitudCLS>("api/Solicitud/pendientes");

        public Task<List<SolicitudCLS>> historial(DateOnly? desde, DateOnly? hasta, int? idLaboratorio, string? estado) =>
            obtenerLista<SolicitudCLS>("api/Solicitud/historial" + consulta(
                ("desde", fecha(desde)),
                ("hasta", fecha(hasta)),
                ("idLaboratorio", idLaboratorio?.ToString()),
                ("estado", estado)));

        public Task<(bool exito, string mensaje)> crearSolicitud(SolicitudCLS oSolicitud) => enviar("api/Solicitud", oSolicitud);

        public Task<(bool exito, string mensaje)> resolverSolicitud(SolicitudResolverCLS oResolver) => enviar("api/Solicitud/resolver", oResolver);
    }
}
