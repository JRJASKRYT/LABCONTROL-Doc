using System.Net.Http.Json;
using BlazorAppLab.entities;

namespace BlazorAppLab.Services
{
    public class UsuarioService : ServicioBase
    {
        public UsuarioService(HttpClient _http, SesionService _sesion) : base(_http, _sesion)
        {
        }

        // Devuelve (exito, mensaje, usuario)
        public async Task<(bool exito, string mensaje, UsuarioSesionCLS? usuario)> login(UsuarioLoginCLS oLogin)
        {
            try
            {
                var respuesta = await http.PostAsJsonAsync("api/Usuario/login", oLogin);

                if (respuesta.IsSuccessStatusCode)
                {
                    var usuario = await respuesta.Content.ReadFromJsonAsync<UsuarioSesionCLS>();
                    return (true, "", usuario);
                }

                var mensaje = (await respuesta.Content.ReadAsStringAsync()).Trim().Trim('"');
                return (false, string.IsNullOrWhiteSpace(mensaje) ? "No se pudo iniciar sesion." : mensaje, null);
            }
            catch
            {
                return (false, "No se pudo conectar con la API. Verifique que BlazorAppLab.API este en ejecucion.", null);
            }
        }

        public Task<List<UsuarioCLS>> listarUsuarios() => obtenerLista<UsuarioCLS>("api/Usuario");

        public Task<List<UsuarioCLS>> listarActivos() => obtenerLista<UsuarioCLS>("api/Usuario/activos");

        public Task<List<TipoUsuarioCLS>> listarTipoUsuario() => obtenerLista<TipoUsuarioCLS>("api/TipoUsuario");

        public Task<(bool exito, string mensaje)> guardarUsuario(UsuarioCLS oUsuario) => enviar("api/Usuario", oUsuario);
    }
}
