using System.Net.Http.Json;
using BlazorAppLab.entities;

namespace BlazorAppLab.Services
{
    public class NotificacionService : ServicioBase
    {
        public NotificacionService(HttpClient _http, SesionService _sesion) : base(_http, _sesion)
        {
        }

        public Task<List<NotificacionCLS>> listarMisNotificaciones() => obtenerLista<NotificacionCLS>("api/Notificacion");

        public async Task<int> contarNoLeidas()
        {
            try
            {
                var respuesta = await http.GetAsync("api/Notificacion/noleidas");
                if (!respuesta.IsSuccessStatusCode)
                {
                    return 0;
                }
                return await respuesta.Content.ReadFromJsonAsync<int>();
            }
            catch
            {
                return 0;
            }
        }

        public Task<(bool exito, string mensaje)> marcarLeida(int idNotificacion) => enviarSinDatos($"api/Notificacion/leida/{idNotificacion}");

        public Task<(bool exito, string mensaje)> marcarTodasLeidas() => enviarSinDatos("api/Notificacion/leidas");
    }
}
