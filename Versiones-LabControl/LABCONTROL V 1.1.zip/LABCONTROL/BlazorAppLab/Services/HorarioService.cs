using BlazorAppLab.entities;

namespace BlazorAppLab.Services
{
    public class HorarioService : ServicioBase
    {
        public HorarioService(HttpClient _http, SesionService _sesion) : base(_http, _sesion)
        {
        }

        public Task<List<PeriodoCLS>> listarPeriodos() => obtenerLista<PeriodoCLS>("api/Periodo");

        public Task<(bool exito, string mensaje)> guardarPeriodo(PeriodoCLS oPeriodo) => enviar("api/Periodo", oPeriodo);

        public Task<List<HorarioCLS>> listarHorarios(int? idLaboratorio, int? idPeriodo) =>
            obtenerLista<HorarioCLS>("api/Horario" + consulta(
                ("idLaboratorio", idLaboratorio?.ToString()),
                ("idPeriodo", idPeriodo?.ToString())));

        public Task<(bool exito, string mensaje)> guardarHorario(HorarioCLS oHorario) => enviar("api/Horario", oHorario);

        public async Task<(bool exito, string mensaje)> eliminarHorario(int idHorario)
        {
            try
            {
                var respuesta = await http.DeleteAsync($"api/Horario/{idHorario}");
                if (respuesta.IsSuccessStatusCode)
                {
                    return (true, "");
                }
                var mensaje = (await respuesta.Content.ReadAsStringAsync()).Trim().Trim('"');
                return (false, string.IsNullOrWhiteSpace(mensaje) ? "No se pudo eliminar el horario." : mensaje);
            }
            catch
            {
                return (false, "No se pudo conectar con la API.");
            }
        }
    }
}
