using BlazorAppLab.entities;

namespace BlazorAppLab.Services
{
    public class IncidenciaService : ServicioBase
    {
        public IncidenciaService(HttpClient _http, SesionService _sesion) : base(_http, _sesion)
        {
        }

        public Task<List<IncidenciaCLS>> listarIncidencias(string? estado = null, int? idLaboratorio = null, int? idEquipo = null,
            DateOnly? desde = null, DateOnly? hasta = null) =>
            obtenerLista<IncidenciaCLS>("api/Incidencia" + consulta(
                ("estado", estado),
                ("idLaboratorio", idLaboratorio?.ToString()),
                ("idEquipo", idEquipo?.ToString()),
                ("desde", fecha(desde)),
                ("hasta", fecha(hasta))));

        public Task<(bool exito, string mensaje)> reportarIncidencia(IncidenciaCLS oIncidencia) => enviar("api/Incidencia", oIncidencia);

        public Task<(bool exito, string mensaje)> actualizarIncidencia(IncidenciaActualizarCLS oActualizar) => enviar("api/Incidencia/actualizar", oActualizar);
    }
}
