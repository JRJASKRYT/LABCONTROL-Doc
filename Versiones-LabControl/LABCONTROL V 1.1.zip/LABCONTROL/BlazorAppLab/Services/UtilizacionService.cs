using BlazorAppLab.entities;

namespace BlazorAppLab.Services
{
    public class UtilizacionService : ServicioBase
    {
        public UtilizacionService(HttpClient _http, SesionService _sesion) : base(_http, _sesion)
        {
        }

        public Task<List<UtilizacionCLS>> listarUtilizaciones(DateOnly? desde = null, DateOnly? hasta = null, int? idLaboratorio = null, int top = 200) =>
            obtenerLista<UtilizacionCLS>("api/Utilizacion" + consulta(
                ("desde", fecha(desde)),
                ("hasta", fecha(hasta)),
                ("idLaboratorio", idLaboratorio?.ToString()),
                ("top", top.ToString())));

        public Task<(bool exito, string mensaje)> registrarUtilizacion(UtilizacionCLS oUso) => enviar("api/Utilizacion", oUso);
    }
}
