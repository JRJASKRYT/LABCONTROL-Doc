using BlazorAppLab.entities;

namespace BlazorAppLab.Services
{
    public class ReporteService : ServicioBase
    {
        public ReporteService(HttpClient _http, SesionService _sesion) : base(_http, _sesion)
        {
        }

        public Task<IndicadoresCLS?> indicadores() => obtener<IndicadoresCLS>("api/Reporte/indicadores");
    }
}
