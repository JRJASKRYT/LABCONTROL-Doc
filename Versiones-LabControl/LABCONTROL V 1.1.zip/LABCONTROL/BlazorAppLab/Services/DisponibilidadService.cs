using System.Net.Http.Json;
using BlazorAppLab.entities;

namespace BlazorAppLab.Services
{
    public class DisponibilidadService : ServicioBase
    {
        public DisponibilidadService(HttpClient _http, SesionService _sesion) : base(_http, _sesion)
        {
        }

        // Devuelve (exito, mensaje, lista)
        public async Task<(bool exito, string mensaje, List<DisponibilidadCLS> lista)> consultar(DateOnly fecha, TimeOnly horaInicio, TimeOnly horaFin)
        {
            try
            {
                var url = "api/Disponibilidad" + consulta(
                    ("fecha", fecha.ToString("yyyy-MM-dd")),
                    ("horaInicio", horaInicio.ToString("HH:mm")),
                    ("horaFin", horaFin.ToString("HH:mm")));

                var respuesta = await http.GetAsync(url);
                if (!respuesta.IsSuccessStatusCode)
                {
                    var mensaje = (await respuesta.Content.ReadAsStringAsync()).Trim().Trim('"');
                    if (respuesta.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {
                        sesion.CerrarSesion();
                    }
                    return (false, string.IsNullOrWhiteSpace(mensaje) ? "No se pudo consultar la disponibilidad." : mensaje, new List<DisponibilidadCLS>());
                }

                var lista = await respuesta.Content.ReadFromJsonAsync<List<DisponibilidadCLS>>() ?? new List<DisponibilidadCLS>();
                return (true, "", lista);
            }
            catch
            {
                return (false, "No se pudo conectar con la API.", new List<DisponibilidadCLS>());
            }
        }
    }
}
