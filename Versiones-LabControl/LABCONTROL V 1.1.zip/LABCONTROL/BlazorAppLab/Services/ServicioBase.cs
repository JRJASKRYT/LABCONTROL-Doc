using System.Net;
using System.Net.Http.Json;

namespace BlazorAppLab.Services
{
    // Metodos comunes para llamar a la API. Si la API responde 401 (sesion vencida) se cierra la sesion.
    public abstract class ServicioBase
    {
        protected readonly HttpClient http;
        protected readonly SesionService sesion;

        protected ServicioBase(HttpClient _http, SesionService _sesion)
        {
            this.http = _http;
            this.sesion = _sesion;
        }

        protected static string consulta(params (string nombre, string? valor)[] parametros)
        {
            var partes = parametros
                .Where(p => !string.IsNullOrEmpty(p.valor))
                .Select(p => p.nombre + "=" + Uri.EscapeDataString(p.valor!));
            var texto = string.Join("&", partes);
            return texto == "" ? "" : "?" + texto;
        }

        protected static string? fecha(DateOnly? valor) => valor?.ToString("yyyy-MM-dd");

        private async Task<string> mensajeDe(HttpResponseMessage respuesta, string porDefecto)
        {
            if (respuesta.StatusCode == HttpStatusCode.Unauthorized)
            {
                sesion.CerrarSesion();
            }
            var mensaje = (await respuesta.Content.ReadAsStringAsync()).Trim().Trim('"');
            return string.IsNullOrWhiteSpace(mensaje) ? porDefecto : mensaje;
        }

        protected async Task<List<T>> obtenerLista<T>(string url)
        {
            try
            {
                var respuesta = await http.GetAsync(url);
                if (!respuesta.IsSuccessStatusCode)
                {
                    await mensajeDe(respuesta, "");
                    return new List<T>();
                }
                return await respuesta.Content.ReadFromJsonAsync<List<T>>() ?? new List<T>();
            }
            catch
            {
                return new List<T>();
            }
        }

        protected async Task<T?> obtener<T>(string url) where T : class
        {
            try
            {
                var respuesta = await http.GetAsync(url);
                if (!respuesta.IsSuccessStatusCode)
                {
                    await mensajeDe(respuesta, "");
                    return null;
                }
                return await respuesta.Content.ReadFromJsonAsync<T>();
            }
            catch
            {
                return null;
            }
        }

        // Devuelve (exito, mensaje)
        protected async Task<(bool exito, string mensaje)> enviar<T>(string url, T datos)
        {
            try
            {
                var respuesta = await http.PostAsJsonAsync(url, datos);
                if (respuesta.IsSuccessStatusCode)
                {
                    return (true, "");
                }
                return (false, await mensajeDe(respuesta, "No se pudo completar la operacion."));
            }
            catch
            {
                return (false, "No se pudo conectar con la API. Verifique que BlazorAppLab.API este en ejecucion.");
            }
        }

        protected async Task<(bool exito, string mensaje)> enviarSinDatos(string url)
        {
            try
            {
                var respuesta = await http.PostAsync(url, null);
                if (respuesta.IsSuccessStatusCode)
                {
                    return (true, "");
                }
                return (false, await mensajeDe(respuesta, "No se pudo completar la operacion."));
            }
            catch
            {
                return (false, "No se pudo conectar con la API. Verifique que BlazorAppLab.API este en ejecucion.");
            }
        }
    }
}
