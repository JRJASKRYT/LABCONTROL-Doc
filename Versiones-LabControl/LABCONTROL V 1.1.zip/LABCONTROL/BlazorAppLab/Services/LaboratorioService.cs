using BlazorAppLab.entities;

namespace BlazorAppLab.Services
{
    public class LaboratorioService : ServicioBase
    {
        public LaboratorioService(HttpClient _http, SesionService _sesion) : base(_http, _sesion)
        {
        }

        public Task<List<LaboratorioCLS>> listarLaboratorios(bool incluirInactivos = false) =>
            obtenerLista<LaboratorioCLS>("api/Laboratorio" + consulta(("incluirInactivos", incluirInactivos ? "true" : "false")));

        public Task<LaboratorioCLS?> recuperarLaboratorio(int idLaboratorio) =>
            obtener<LaboratorioCLS>($"api/Laboratorio/{idLaboratorio}");

        public Task<(bool exito, string mensaje)> guardarLaboratorio(LaboratorioCLS oLab) => enviar("api/Laboratorio", oLab);

        public Task<List<EquipoCLS>> listarEquipos(int idLaboratorio, bool todos = false) =>
            obtenerLista<EquipoCLS>($"api/Equipo/laboratorio/{idLaboratorio}" + consulta(("todos", todos ? "true" : "false")));

        public Task<(bool exito, string mensaje)> guardarEquipo(EquipoCLS oEquipo) => enviar("api/Equipo", oEquipo);

        public Task<(bool exito, string mensaje)> cambiarEstadoEquipo(EquipoCLS oEquipo) => enviar("api/Equipo/estado", oEquipo);
    }
}
