using BlazorAppLab;
using BlazorAppLab.Services;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

// Direccion de la API (proyecto BlazorAppLab.API)
var urlApi = "http://localhost:5333/";

builder.Services.AddScoped(sp => new HttpClient
{
    BaseAddress = new Uri(urlApi)
});

builder.Services.AddScoped<SesionService>();
builder.Services.AddScoped<UsuarioService>();
builder.Services.AddScoped<LaboratorioService>();
builder.Services.AddScoped<HorarioService>();
builder.Services.AddScoped<DisponibilidadService>();
builder.Services.AddScoped<SolicitudService>();
builder.Services.AddScoped<UtilizacionService>();
builder.Services.AddScoped<IncidenciaService>();
builder.Services.AddScoped<NotificacionService>();
builder.Services.AddScoped<ReporteService>();

await builder.Build().RunAsync();
