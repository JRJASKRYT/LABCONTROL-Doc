# LABCONTROL — Sistema Web para la Gestión y Control de Laboratorios

Grupo SQLitos · Proyecto de Sistemas I · Centro de Cómputo Univalle La Paz

**Tecnología:** Blazor Web App (.NET 10, modo interactivo Server) sobre tu plantilla `BlazorAppLab` · C# · Entity Framework Core 10 · SQL Server

## Cómo ejecutarlo

1. Instala el **SDK de .NET 10** y ten **SQL Server** (o LocalDB) en tu equipo.
2. Abre `appsettings.json` y ajusta la cadena de conexión `LabControl` si hace falta:
   - SQL Server local: `Server=localhost;Database=BDLABCONTROL;Trusted_Connection=True;TrustServerCertificate=True;`
   - LocalDB: `Server=(localdb)\\MSSQLLocalDB;Database=BDLABCONTROL;Trusted_Connection=True;`
3. Abre `LABCONTROL.slnx` en Visual Studio (o en la carpeta `BlazorAppLab`: `dotnet restore` y `dotnet run`).
4. Al iniciar por primera vez **se crea la base de datos `BDLABCONTROL`** con sus tablas y datos de ejemplo.

### Usuarios de prueba (contraseña de todos: `Lab2026*`)

| Usuario     | Rol            |
|-------------|----------------|
| admin       | Administrador  |
| encargado   | Encargado      |
| tecnico     | Técnico        |
| docente     | Docente        |
| estudiante  | Estudiante     |

## Historias de usuario → dónde están

| HU | Funcionalidad | Pantalla (ruta) | Roles |
|----|---------------|-----------------|-------|
| HU-01 | Inicio de sesión y acceso por rol | `/login` | Todos |
| HU-02 | Consultar disponibilidad por fecha y horario | `/disponibilidad` | Todos |
| HU-03 | Consultar horarios de un laboratorio y periodo | `/horarios` | Todos |
| HU-04 | Ficha del laboratorio | `/laboratorios` | Todos |
| HU-05 | Solicitar uso (valida campos y disponibilidad, estado inicial Pendiente) | `/nueva-solicitud` | Estudiante, Docente |
| HU-06 | Consultar mis solicitudes (solo las del usuario) | `/mis-solicitudes` | Estudiante, Docente |
| HU-07 | Estado de la solicitud (Pendiente / Aprobada / Rechazada) | `/mis-solicitudes` | Estudiante, Docente |
| HU-08 | Aprobar o rechazar solicitudes | `/gestion-solicitudes` | Encargado, Administrador |
| HU-09 | Registrar utilización de laboratorio/equipo | `/utilizacion` | Encargado, Administrador |
| HU-10 | Administrar laboratorios (y sus equipos) | `/admin-laboratorios` | Encargado, Administrador |
| HU-11 | Administrar horarios y periodos | `/admin-horarios` | Encargado, Administrador |
| HU-12 | Administrar usuarios y roles | `/admin-usuarios` | Administrador |
| HU-13 | Reportar incidencia | `/nueva-incidencia` | Todos |
| HU-14 | Consultar estado/detalle de incidencias | `/mis-incidencias` | Todos (propias; personal autorizado ve todas) |
| HU-15 | Gestionar incidencias (estado, fecha de atención, observación técnica) | `/gestion-incidencias` | Encargado, Técnico, Administrador |
| HU-16 | Historial de solicitudes con filtros | `/historial-solicitudes` | Encargado, Administrador |
| HU-17 | Historial de incidencias con filtros | `/historial-incidencias` | Encargado, Administrador |
| HU-18 | Reportes de solicitudes, utilización e incidencias | `/reportes` | Encargado, Administrador |
| HU-19 | Notificaciones | `/notificaciones` (+ contador en el menú) | Todos |
| HU-20 | Indicadores y estadísticas | `/indicadores` | Encargado, Administrador |

## Reglas de negocio implementadas

- Un laboratorio **no está disponible** si su estado no es *Disponible*, si choca con un horario académico del periodo vigente, o si ya tiene una solicitud **aprobada** que se cruza.
- Al aprobar una solicitud se vuelve a verificar la disponibilidad (evita dobles reservas).
- Rechazar una solicitud exige una observación.
- Reportar una incidencia con equipo marca el equipo *En falla*; al pasar a *En atención* queda *En mantenimiento*; al *Resolverse* vuelve a *Operativo*.
- Notificaciones automáticas: nueva solicitud → encargados; solicitud resuelta → solicitante; nueva incidencia → encargados y técnicos; cambio de estado de incidencia → quien la reportó.
- Contraseñas guardadas con PBKDF2 (SHA-256 + sal); no se almacenan en texto plano.
- Baja lógica (estado/activo) en lugar de borrado físico, para conservar el historial.

## Estructura

```
BlazorAppLab/
  Models/      Entidades y enumeraciones
Data/        LabControlDbContext y DbSeeder (datos de ejemplo)
Services/    Lógica de negocio (una clase por área) + sesión/autenticación
Components/  Layout, componentes compartidos y Pages (una página por funcionalidad)
```

## Notas

- La base se crea con `EnsureCreated`. Si prefieres migraciones: `dotnet ef migrations add Inicial` y `dotnet ef database update`
  (y quita `EnsureCreatedAsync` de `DbSeeder`).
