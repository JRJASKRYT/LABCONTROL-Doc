using BlazorAppLab.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.Data;

public class LabControlDbContext : DbContext
{
    public LabControlDbContext(DbContextOptions<LabControlDbContext> options) : base(options) { }

    public DbSet<Usuario> Usuarios => Set<Usuario>();
    public DbSet<Laboratorio> Laboratorios => Set<Laboratorio>();
    public DbSet<Equipo> Equipos => Set<Equipo>();
    public DbSet<PeriodoAcademico> Periodos => Set<PeriodoAcademico>();
    public DbSet<Horario> Horarios => Set<Horario>();
    public DbSet<Solicitud> Solicitudes => Set<Solicitud>();
    public DbSet<RegistroUtilizacion> Utilizaciones => Set<RegistroUtilizacion>();
    public DbSet<Incidencia> Incidencias => Set<Incidencia>();
    public DbSet<Notificacion> Notificaciones => Set<Notificacion>();

    protected override void OnModelCreating(ModelBuilder mb)
    {
        mb.Entity<Usuario>(e =>
        {
            e.HasIndex(u => u.NombreUsuario).IsUnique();
            e.HasIndex(u => u.Correo).IsUnique();
            e.Property(u => u.Rol).HasConversion<string>().HasMaxLength(20);
        });

        mb.Entity<Laboratorio>(e =>
        {
            e.HasIndex(l => l.Nombre).IsUnique();
            e.Property(l => l.Estado).HasConversion<string>().HasMaxLength(20);
        });

        mb.Entity<Equipo>(e =>
        {
            e.HasIndex(x => x.Codigo).IsUnique();
            e.Property(x => x.Estado).HasConversion<string>().HasMaxLength(20);
        });

        mb.Entity<Solicitud>(e =>
        {
            e.Property(s => s.Estado).HasConversion<string>().HasMaxLength(20);
            e.HasOne(s => s.Solicitante).WithMany().HasForeignKey(s => s.SolicitanteId);
            e.HasOne(s => s.GestionadoPor).WithMany().HasForeignKey(s => s.GestionadoPorId);
        });

        mb.Entity<RegistroUtilizacion>(e =>
        {
            e.HasOne(r => r.Usuario).WithMany().HasForeignKey(r => r.UsuarioId);
            e.HasOne(r => r.RegistradoPor).WithMany().HasForeignKey(r => r.RegistradoPorId);
        });

        mb.Entity<Incidencia>(e =>
        {
            e.Property(i => i.Estado).HasConversion<string>().HasMaxLength(20);
            e.HasOne(i => i.ReportadoPor).WithMany().HasForeignKey(i => i.ReportadoPorId);
            e.HasOne(i => i.AtendidoPor).WithMany().HasForeignKey(i => i.AtendidoPorId);
        });

        // SQL Server no permite múltiples rutas de borrado en cascada:
        // todas las relaciones son Restrict (el sistema usa baja lógica, no borrado físico).
        foreach (var fk in mb.Model.GetEntityTypes().SelectMany(t => t.GetForeignKeys()))
            fk.DeleteBehavior = DeleteBehavior.Restrict;
    }
}
