using BlazorAppLab.Models;
using BlazorAppLab.Services;
using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.Data;

public static class DbSeeder
{
    public const string PasswordDemo = "Lab2026*";

    public static async Task InicializarAsync(LabControlDbContext db)
    {
        await db.Database.EnsureCreatedAsync();
        if (await db.Usuarios.AnyAsync()) return;

        var hash = PasswordHasher.Hash(PasswordDemo);
        db.Usuarios.AddRange(
            new Usuario { NombreCompleto = "Administrador del Sistema", NombreUsuario = "admin", Correo = "admin@labcontrol.edu.bo", PasswordHash = hash, Rol = RolUsuario.Administrador },
            new Usuario { NombreCompleto = "Encargado Centro de Cómputo", NombreUsuario = "encargado", Correo = "encargado@labcontrol.edu.bo", PasswordHash = hash, Rol = RolUsuario.Encargado },
            new Usuario { NombreCompleto = "Técnico de Soporte", NombreUsuario = "tecnico", Correo = "tecnico@labcontrol.edu.bo", PasswordHash = hash, Rol = RolUsuario.Tecnico },
            new Usuario { NombreCompleto = "Docente de Prueba", NombreUsuario = "docente", Correo = "docente@labcontrol.edu.bo", PasswordHash = hash, Rol = RolUsuario.Docente },
            new Usuario { NombreCompleto = "Estudiante de Prueba", NombreUsuario = "estudiante", Correo = "estudiante@labcontrol.edu.bo", PasswordHash = hash, Rol = RolUsuario.Estudiante });

        var labs = new[]
        {
            new Laboratorio { Nombre = "Laboratorio 1", Ubicacion = "Bloque A, Piso 1", Capacidad = 30, Descripcion = "Laboratorio de programación con 30 equipos de escritorio." },
            new Laboratorio { Nombre = "Laboratorio 2", Ubicacion = "Bloque A, Piso 2", Capacidad = 25, Descripcion = "Laboratorio para bases de datos y redes." },
            new Laboratorio { Nombre = "Laboratorio 3", Ubicacion = "Bloque B, Piso 1", Capacidad = 20, Descripcion = "Laboratorio de uso general y talleres." },
            new Laboratorio { Nombre = "Laboratorio 4", Ubicacion = "Bloque B, Piso 2", Capacidad = 20, Estado = EstadoLaboratorio.EnMantenimiento, Descripcion = "Laboratorio en remodelación." }
        };
        db.Laboratorios.AddRange(labs);

        int n = 1;
        foreach (var lab in labs)
            for (int i = 1; i <= 5; i++, n++)
                db.Equipos.Add(new Equipo { Laboratorio = lab, Codigo = $"PC-{n:000}", Nombre = $"Computadora {i} - {lab.Nombre}" });

        var periodo = new PeriodoAcademico { Nombre = "2026-II", FechaInicio = new(2026, 8, 3), FechaFin = new(2026, 12, 12), Activo = true };
        db.Periodos.Add(periodo);

        db.Horarios.AddRange(
            new Horario { Laboratorio = labs[0], Periodo = periodo, Dia = DayOfWeek.Monday, HoraInicio = new(8, 0), HoraFin = new(10, 0), Actividad = "Programación I" },
            new Horario { Laboratorio = labs[0], Periodo = periodo, Dia = DayOfWeek.Wednesday, HoraInicio = new(10, 0), HoraFin = new(12, 0), Actividad = "Estructuras de Datos" },
            new Horario { Laboratorio = labs[1], Periodo = periodo, Dia = DayOfWeek.Tuesday, HoraInicio = new(14, 0), HoraFin = new(16, 0), Actividad = "Bases de Datos I" },
            new Horario { Laboratorio = labs[1], Periodo = periodo, Dia = DayOfWeek.Thursday, HoraInicio = new(8, 0), HoraFin = new(10, 0), Actividad = "Redes" },
            new Horario { Laboratorio = labs[2], Periodo = periodo, Dia = DayOfWeek.Friday, HoraInicio = new(10, 0), HoraFin = new(12, 0), Actividad = "Taller de Ofimática" });

        await db.SaveChangesAsync();
    }
}
