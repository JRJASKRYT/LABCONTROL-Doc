using System.ComponentModel.DataAnnotations;

namespace BlazorAppLab.Models;

public enum RolUsuario { Estudiante, Docente, Encargado, Tecnico, Administrador }
public enum EstadoLaboratorio { Disponible, EnMantenimiento, Inactivo }
public enum EstadoEquipo { Operativo, EnFalla, EnMantenimiento, DadoDeBaja }
public enum EstadoSolicitud { Pendiente, Aprobada, Rechazada }
public enum EstadoIncidencia { Pendiente, EnAtencion, Resuelta }

public class Usuario
{
    public int Id { get; set; }

    [Required(ErrorMessage = "El nombre completo es obligatorio"), MaxLength(120)]
    public string NombreCompleto { get; set; } = "";

    [Required(ErrorMessage = "El nombre de usuario es obligatorio"), MaxLength(50)]
    public string NombreUsuario { get; set; } = "";

    [Required(ErrorMessage = "El correo es obligatorio"), EmailAddress(ErrorMessage = "Correo no válido"), MaxLength(120)]
    public string Correo { get; set; } = "";

    [MaxLength(200)]
    public string PasswordHash { get; set; } = "";

    public RolUsuario Rol { get; set; } = RolUsuario.Estudiante;
    public bool Activo { get; set; } = true;
    public DateTime FechaRegistro { get; set; } = DateTime.Now;
}

public class Laboratorio
{
    public int Id { get; set; }

    [Required(ErrorMessage = "El nombre es obligatorio"), MaxLength(100)]
    public string Nombre { get; set; } = "";

    [Required(ErrorMessage = "La ubicación es obligatoria"), MaxLength(150)]
    public string Ubicacion { get; set; } = "";

    [Range(1, 500, ErrorMessage = "La capacidad debe estar entre 1 y 500")]
    public int Capacidad { get; set; } = 20;

    public EstadoLaboratorio Estado { get; set; } = EstadoLaboratorio.Disponible;

    [MaxLength(500)]
    public string? Descripcion { get; set; }

    public List<Equipo> Equipos { get; set; } = new();
    public List<Horario> Horarios { get; set; } = new();
}

public class Equipo
{
    public int Id { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Seleccione un laboratorio")]
    public int LaboratorioId { get; set; }
    public Laboratorio Laboratorio { get; set; } = null!;

    [Required(ErrorMessage = "El código es obligatorio"), MaxLength(30)]
    public string Codigo { get; set; } = "";

    [Required(ErrorMessage = "El nombre es obligatorio"), MaxLength(100)]
    public string Nombre { get; set; } = "";

    public EstadoEquipo Estado { get; set; } = EstadoEquipo.Operativo;
}

public class PeriodoAcademico
{
    public int Id { get; set; }

    [Required(ErrorMessage = "El nombre es obligatorio"), MaxLength(50)]
    public string Nombre { get; set; } = "";

    public DateOnly FechaInicio { get; set; }
    public DateOnly FechaFin { get; set; }
    public bool Activo { get; set; } = true;
}

public class Horario
{
    public int Id { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Seleccione un laboratorio")]
    public int LaboratorioId { get; set; }
    public Laboratorio Laboratorio { get; set; } = null!;

    [Range(1, int.MaxValue, ErrorMessage = "Seleccione un periodo")]
    public int PeriodoAcademicoId { get; set; }
    public PeriodoAcademico Periodo { get; set; } = null!;

    public DayOfWeek Dia { get; set; } = DayOfWeek.Monday;
    public TimeOnly HoraInicio { get; set; } = new(8, 0);
    public TimeOnly HoraFin { get; set; } = new(10, 0);

    [MaxLength(150)]
    public string? Actividad { get; set; }
}

public class Solicitud
{
    public int Id { get; set; }

    public int SolicitanteId { get; set; }
    public Usuario Solicitante { get; set; } = null!;

    [Range(1, int.MaxValue, ErrorMessage = "Seleccione un laboratorio")]
    public int LaboratorioId { get; set; }
    public Laboratorio Laboratorio { get; set; } = null!;

    public DateOnly Fecha { get; set; } = DateOnly.FromDateTime(DateTime.Today);
    public TimeOnly HoraInicio { get; set; } = new(8, 0);
    public TimeOnly HoraFin { get; set; } = new(10, 0);

    [Required(ErrorMessage = "Indique el motivo de la solicitud"), MaxLength(300)]
    public string Motivo { get; set; } = "";

    public EstadoSolicitud Estado { get; set; } = EstadoSolicitud.Pendiente;
    public DateTime FechaCreacion { get; set; } = DateTime.Now;

    public int? GestionadoPorId { get; set; }
    public Usuario? GestionadoPor { get; set; }
    public DateTime? FechaGestion { get; set; }

    [MaxLength(300)]
    public string? ObservacionGestion { get; set; }
}

public class RegistroUtilizacion
{
    public int Id { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Seleccione el usuario")]
    public int UsuarioId { get; set; }
    public Usuario Usuario { get; set; } = null!;

    [Range(1, int.MaxValue, ErrorMessage = "Seleccione un laboratorio")]
    public int LaboratorioId { get; set; }
    public Laboratorio Laboratorio { get; set; } = null!;

    public int? EquipoId { get; set; }
    public Equipo? Equipo { get; set; }

    public DateTime Fecha { get; set; } = DateTime.Now;

    [MaxLength(300)]
    public string? Observacion { get; set; }

    public int RegistradoPorId { get; set; }
    public Usuario RegistradoPor { get; set; } = null!;
}

public class Incidencia
{
    public int Id { get; set; }

    public int ReportadoPorId { get; set; }
    public Usuario ReportadoPor { get; set; } = null!;

    [Range(1, int.MaxValue, ErrorMessage = "Seleccione un laboratorio")]
    public int LaboratorioId { get; set; }
    public Laboratorio Laboratorio { get; set; } = null!;

    public int? EquipoId { get; set; }
    public Equipo? Equipo { get; set; }

    [Required(ErrorMessage = "Describa la falla"), MaxLength(500)]
    public string Descripcion { get; set; } = "";

    public DateTime FechaReporte { get; set; } = DateTime.Now;
    public EstadoIncidencia Estado { get; set; } = EstadoIncidencia.Pendiente;

    public DateTime? FechaAtencion { get; set; }

    [MaxLength(500)]
    public string? ObservacionTecnica { get; set; }

    public int? AtendidoPorId { get; set; }
    public Usuario? AtendidoPor { get; set; }
}

public class Notificacion
{
    public int Id { get; set; }
    public int UsuarioId { get; set; }
    public Usuario Usuario { get; set; } = null!;

    [MaxLength(300)]
    public string Mensaje { get; set; } = "";

    [MaxLength(100)]
    public string? Enlace { get; set; }

    public DateTime Fecha { get; set; } = DateTime.Now;
    public bool Leida { get; set; }
}
