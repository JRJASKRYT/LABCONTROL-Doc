namespace BlazorAppLab.Models;

/// <summary>Constantes de roles para controlar el acceso a cada pantalla.</summary>
public static class RolesAcceso
{
    public const string Consulta = "Estudiante,Docente,Encargado,Tecnico,Administrador";
    public const string Solicitantes = "Estudiante,Docente";
    public const string Gestion = "Encargado,Administrador";
    public const string Incidencias = "Encargado,Tecnico,Administrador";
    public const string Administrador = "Administrador";
}

public static class EnumTexto
{
    private static readonly Dictionary<string, string> Especiales = new()
    {
        ["Tecnico"] = "Técnico",
        ["EnAtencion"] = "En atención",
        ["EnMantenimiento"] = "En mantenimiento",
        ["EnFalla"] = "En falla",
        ["DadoDeBaja"] = "Dado de baja"
    };

    public static string Texto(this Enum valor)
    {
        var s = valor.ToString();
        return Especiales.TryGetValue(s, out var t) ? t : s;
    }

    /// <summary>Clase de Bootstrap para pintar el estado como insignia.</summary>
    public static string Badge(this Enum valor) => valor.ToString() switch
    {
        "Aprobada" or "Resuelta" or "Disponible" or "Operativo" => "bg-success",
        "Rechazada" or "EnFalla" or "Inactivo" or "DadoDeBaja" => "bg-danger",
        "Pendiente" => "bg-warning text-dark",
        "EnAtencion" or "EnMantenimiento" => "bg-info text-dark",
        _ => "bg-secondary"
    };

    public static string DiaTexto(this DayOfWeek d) => d switch
    {
        DayOfWeek.Monday => "Lunes",
        DayOfWeek.Tuesday => "Martes",
        DayOfWeek.Wednesday => "Miércoles",
        DayOfWeek.Thursday => "Jueves",
        DayOfWeek.Friday => "Viernes",
        DayOfWeek.Saturday => "Sábado",
        _ => "Domingo"
    };

    public static readonly DayOfWeek[] DiasSemana =
    {
        DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday,
        DayOfWeek.Thursday, DayOfWeek.Friday, DayOfWeek.Saturday
    };
}
