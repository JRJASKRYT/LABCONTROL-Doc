using System.Security.Claims;
using BlazorAppLab.Models;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Server.ProtectedBrowserStorage;

namespace BlazorAppLab.Services;

public record SesionUsuario(int Id, string Nombre, string Rol);

/// <summary>
/// Mantiene la sesión del usuario (HU-01). Guarda los datos mínimos cifrados en el
/// sessionStorage del navegador y los expone como ClaimsPrincipal con su rol.
/// </summary>
public class SesionAuthStateProvider : AuthenticationStateProvider
{
    private const string Clave = "labcontrol_sesion";
    private readonly ProtectedSessionStorage _storage;
    private SesionUsuario? _actual;
    private bool _cargado;

    public SesionAuthStateProvider(ProtectedSessionStorage storage) => _storage = storage;

    public SesionUsuario? Actual => _actual;

    public override async Task<AuthenticationState> GetAuthenticationStateAsync()
    {
        if (!_cargado)
        {
            try
            {
                var r = await _storage.GetAsync<SesionUsuario>(Clave);
                _actual = r.Success ? r.Value : null;
                _cargado = true;
            }
            catch
            {
                return Anonimo();
            }
        }
        return Crear(_actual);
    }

    /// <summary>Devuelve la sesión si hay usuario autenticado (y, opcionalmente, con alguno de los roles indicados).</summary>
    public async Task<SesionUsuario?> ObtenerSesionAsync(string? rolesCsv = null)
    {
        await GetAuthenticationStateAsync();
        if (_actual == null) return null;
        if (rolesCsv == null) return _actual;
        var roles = rolesCsv.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
        return roles.Contains(_actual.Rol) ? _actual : null;
    }

    public async Task IniciarAsync(Usuario u)
    {
        _actual = new SesionUsuario(u.Id, u.NombreCompleto, u.Rol.ToString());
        _cargado = true;
        await _storage.SetAsync(Clave, _actual);
        NotifyAuthenticationStateChanged(Task.FromResult(Crear(_actual)));
    }

    public async Task CerrarAsync()
    {
        _actual = null;
        _cargado = true;
        await _storage.DeleteAsync(Clave);
        NotifyAuthenticationStateChanged(Task.FromResult(Anonimo()));
    }

    private static AuthenticationState Anonimo() => new(new ClaimsPrincipal(new ClaimsIdentity()));

    private static AuthenticationState Crear(SesionUsuario? s)
    {
        if (s == null) return Anonimo();
        var identidad = new ClaimsIdentity(new[]
        {
            new Claim(ClaimTypes.NameIdentifier, s.Id.ToString()),
            new Claim(ClaimTypes.Name, s.Nombre),
            new Claim(ClaimTypes.Role, s.Rol)
        }, "LabControlSesion");
        return new AuthenticationState(new ClaimsPrincipal(identidad));
    }
}
