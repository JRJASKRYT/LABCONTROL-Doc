using BlazorAppLab.Data;
using BlazorAppLab.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.Services;

public class AuthService
{
    private readonly IDbContextFactory<LabControlDbContext> _f;
    public AuthService(IDbContextFactory<LabControlDbContext> f) => _f = f;

    /// <summary>HU-01: valida usuario/correo + contraseña. Devuelve null si las credenciales no son válidas.</summary>
    public async Task<Usuario?> ValidarAsync(string identificador, string password)
    {
        await using var db = await _f.CreateDbContextAsync();
        var id = identificador.Trim();
        var u = await db.Usuarios.FirstOrDefaultAsync(x => x.NombreUsuario == id || x.Correo == id);
        if (u == null || !u.Activo) return null;
        return PasswordHasher.Verificar(password, u.PasswordHash) ? u : null;
    }
}
