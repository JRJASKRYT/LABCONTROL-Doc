using BlazorAppLab.Data;
using BlazorAppLab.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.Services;

/// <summary>Genera avisos (HU-19) dentro del mismo contexto/transacción que el evento que los origina.</summary>
public static class Notificar
{
    public static void AUsuario(LabControlDbContext db, int usuarioId, string mensaje, string? enlace = null) =>
        db.Notificaciones.Add(new Notificacion { UsuarioId = usuarioId, Mensaje = mensaje, Enlace = enlace, Fecha = DateTime.Now });

    public static async Task ARolesAsync(LabControlDbContext db, RolUsuario[] roles, string mensaje, string? enlace = null)
    {
        var ids = await db.Usuarios.Where(u => u.Activo && roles.Contains(u.Rol)).Select(u => u.Id).ToListAsync();
        foreach (var id in ids) AUsuario(db, id, mensaje, enlace);
    }
}
