using BlazorAppLab.Data;
using BlazorAppLab.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.Services;

public class IncidenciaService
{
    private readonly IDbContextFactory<LabControlDbContext> _f;
    public IncidenciaService(IDbContextFactory<LabControlDbContext> f) => _f = f;

    /// <summary>HU-13: registra una incidencia con estado inicial Pendiente.</summary>
    public async Task<(bool Ok, string? Error)> ReportarAsync(Incidencia i)
    {
        if (i.LaboratorioId <= 0) return (false, "Seleccione un laboratorio.");
        if (string.IsNullOrWhiteSpace(i.Descripcion)) return (false, "Describa la falla.");

        await using var db = await _f.CreateDbContextAsync();
        var lab = await db.Laboratorios.FindAsync(i.LaboratorioId);
        if (lab == null) return (false, "Laboratorio no encontrado.");

        Equipo? equipo = null;
        if (i.EquipoId.HasValue)
        {
            equipo = await db.Equipos.FirstOrDefaultAsync(e => e.Id == i.EquipoId.Value && e.LaboratorioId == i.LaboratorioId);
            if (equipo == null) return (false, "El equipo no pertenece al laboratorio seleccionado.");
            if (equipo.Estado == EstadoEquipo.Operativo) equipo.Estado = EstadoEquipo.EnFalla;
        }

        var reporta = await db.Usuarios.FindAsync(i.ReportadoPorId);
        db.Incidencias.Add(new Incidencia
        {
            ReportadoPorId = i.ReportadoPorId, LaboratorioId = i.LaboratorioId, EquipoId = i.EquipoId,
            Descripcion = i.Descripcion.Trim(), FechaReporte = DateTime.Now, Estado = EstadoIncidencia.Pendiente
        });

        await Notificar.ARolesAsync(db, new[] { RolUsuario.Encargado, RolUsuario.Tecnico },
            $"Nueva incidencia en {lab.Nombre}{(equipo != null ? " (" + equipo.Codigo + ")" : "")} reportada por {reporta?.NombreCompleto}.",
            "/gestion-incidencias");
        await db.SaveChangesAsync();
        return (true, null);
    }

    /// <summary>HU-14 / HU-17: listado con filtros. Si reportadoPorId tiene valor, solo devuelve las de ese usuario.</summary>
    public async Task<List<Incidencia>> ListarAsync(int? reportadoPorId = null, EstadoIncidencia? estado = null,
        int? laboratorioId = null, int? equipoId = null, DateOnly? desde = null, DateOnly? hasta = null)
    {
        await using var db = await _f.CreateDbContextAsync();
        var q = db.Incidencias.Include(i => i.Laboratorio).Include(i => i.Equipo)
            .Include(i => i.ReportadoPor).Include(i => i.AtendidoPor).AsQueryable();
        if (reportadoPorId.HasValue) q = q.Where(i => i.ReportadoPorId == reportadoPorId.Value);
        if (estado.HasValue) q = q.Where(i => i.Estado == estado.Value);
        if (laboratorioId.HasValue) q = q.Where(i => i.LaboratorioId == laboratorioId.Value);
        if (equipoId.HasValue) q = q.Where(i => i.EquipoId == equipoId.Value);
        if (desde.HasValue) { var d = desde.Value.ToDateTime(TimeOnly.MinValue); q = q.Where(i => i.FechaReporte >= d); }
        if (hasta.HasValue) { var h = hasta.Value.ToDateTime(TimeOnly.MaxValue); q = q.Where(i => i.FechaReporte <= h); }
        return await q.OrderByDescending(i => i.FechaReporte).ToListAsync();
    }

    /// <summary>HU-15: actualiza estado, fecha de atención y observación técnica.</summary>
    public async Task<(bool Ok, string? Error)> ActualizarAsync(int id, EstadoIncidencia nuevoEstado, string? observacion, int usuarioId)
    {
        await using var db = await _f.CreateDbContextAsync();
        var i = await db.Incidencias.Include(x => x.Laboratorio).Include(x => x.Equipo).FirstOrDefaultAsync(x => x.Id == id);
        if (i == null) return (false, "Incidencia no encontrada.");
        if (nuevoEstado != EstadoIncidencia.Pendiente && string.IsNullOrWhiteSpace(observacion))
            return (false, "Registre la observación técnica.");

        i.Estado = nuevoEstado;
        i.ObservacionTecnica = string.IsNullOrWhiteSpace(observacion) ? i.ObservacionTecnica : observacion.Trim();
        if (nuevoEstado != EstadoIncidencia.Pendiente)
        {
            i.FechaAtencion ??= DateTime.Now;
            i.AtendidoPorId = usuarioId;
        }
        if (nuevoEstado == EstadoIncidencia.Resuelta && i.Equipo is { Estado: EstadoEquipo.EnFalla or EstadoEquipo.EnMantenimiento })
            i.Equipo.Estado = EstadoEquipo.Operativo;
        else if (nuevoEstado == EstadoIncidencia.EnAtencion && i.Equipo is { Estado: EstadoEquipo.EnFalla })
            i.Equipo.Estado = EstadoEquipo.EnMantenimiento;

        Notificar.AUsuario(db, i.ReportadoPorId,
            $"Tu incidencia en {i.Laboratorio.Nombre} cambió a: {nuevoEstado.Texto()}.", "/mis-incidencias");
        await db.SaveChangesAsync();
        return (true, null);
    }
}
