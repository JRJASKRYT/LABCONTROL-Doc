using BlazorAppLab.Data;
using BlazorAppLab.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.Services;

public class LaboratorioService
{
    private readonly IDbContextFactory<LabControlDbContext> _f;
    public LaboratorioService(IDbContextFactory<LabControlDbContext> f) => _f = f;

    public async Task<List<Laboratorio>> ListarAsync(bool incluirInactivos = true)
    {
        await using var db = await _f.CreateDbContextAsync();
        var q = db.Laboratorios.AsQueryable();
        if (!incluirInactivos) q = q.Where(l => l.Estado != EstadoLaboratorio.Inactivo);
        return await q.OrderBy(l => l.Nombre).ToListAsync();
    }

    /// <summary>HU-04: ficha del laboratorio con sus equipos.</summary>
    public async Task<Laboratorio?> ObtenerAsync(int id)
    {
        await using var db = await _f.CreateDbContextAsync();
        return await db.Laboratorios.Include(l => l.Equipos.OrderBy(e => e.Codigo)).FirstOrDefaultAsync(l => l.Id == id);
    }

    /// <summary>HU-10: crear o actualizar un laboratorio.</summary>
    public async Task<(bool Ok, string? Error)> GuardarAsync(Laboratorio lab)
    {
        await using var db = await _f.CreateDbContextAsync();
        var nombre = lab.Nombre.Trim();
        if (await db.Laboratorios.AnyAsync(l => l.Nombre == nombre && l.Id != lab.Id))
            return (false, "Ya existe un laboratorio con ese nombre.");

        if (lab.Id == 0)
        {
            db.Laboratorios.Add(new Laboratorio
            {
                Nombre = nombre, Ubicacion = lab.Ubicacion.Trim(), Capacidad = lab.Capacidad,
                Estado = lab.Estado, Descripcion = lab.Descripcion?.Trim()
            });
        }
        else
        {
            var actual = await db.Laboratorios.FindAsync(lab.Id);
            if (actual == null) return (false, "Laboratorio no encontrado.");
            actual.Nombre = nombre;
            actual.Ubicacion = lab.Ubicacion.Trim();
            actual.Capacidad = lab.Capacidad;
            actual.Estado = lab.Estado;
            actual.Descripcion = lab.Descripcion?.Trim();
        }
        await db.SaveChangesAsync();
        return (true, null);
    }

    // ---- Equipos ----

    public async Task<List<Equipo>> EquiposAsync(int laboratorioId)
    {
        await using var db = await _f.CreateDbContextAsync();
        return await db.Equipos.Where(e => e.LaboratorioId == laboratorioId && e.Estado != EstadoEquipo.DadoDeBaja)
            .OrderBy(e => e.Codigo).ToListAsync();
    }

    public async Task<List<Equipo>> TodosEquiposAsync(int laboratorioId)
    {
        await using var db = await _f.CreateDbContextAsync();
        return await db.Equipos.Where(e => e.LaboratorioId == laboratorioId).OrderBy(e => e.Codigo).ToListAsync();
    }

    public async Task<(bool Ok, string? Error)> GuardarEquipoAsync(Equipo eq)
    {
        await using var db = await _f.CreateDbContextAsync();
        var codigo = eq.Codigo.Trim();
        if (await db.Equipos.AnyAsync(e => e.Codigo == codigo && e.Id != eq.Id))
            return (false, "Ya existe un equipo con ese código.");

        if (eq.Id == 0)
            db.Equipos.Add(new Equipo { LaboratorioId = eq.LaboratorioId, Codigo = codigo, Nombre = eq.Nombre.Trim(), Estado = eq.Estado });
        else
        {
            var actual = await db.Equipos.FindAsync(eq.Id);
            if (actual == null) return (false, "Equipo no encontrado.");
            actual.Codigo = codigo;
            actual.Nombre = eq.Nombre.Trim();
            actual.Estado = eq.Estado;
        }
        await db.SaveChangesAsync();
        return (true, null);
    }

    public async Task CambiarEstadoEquipoAsync(int equipoId, EstadoEquipo estado)
    {
        await using var db = await _f.CreateDbContextAsync();
        var e = await db.Equipos.FindAsync(equipoId);
        if (e == null) return;
        e.Estado = estado;
        await db.SaveChangesAsync();
    }
}
