using BlazorAppLab.Data;
using BlazorAppLab.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.Services;

public class SolicitudService
{
    private readonly IDbContextFactory<LabControlDbContext> _f;
    public SolicitudService(IDbContextFactory<LabControlDbContext> f) => _f = f;

    /// <summary>HU-05: registra una solicitud con estado inicial Pendiente, validando datos y disponibilidad.</summary>
    public async Task<(bool Ok, string? Error)> CrearAsync(Solicitud s)
    {
        if (s.LaboratorioId <= 0) return (false, "Seleccione un laboratorio.");
        if (string.IsNullOrWhiteSpace(s.Motivo)) return (false, "Indique el motivo de la solicitud.");
        if (s.HoraFin <= s.HoraInicio) return (false, "La hora de fin debe ser posterior a la hora de inicio.");
        if (s.Fecha < DateOnly.FromDateTime(DateTime.Today)) return (false, "La fecha no puede ser anterior a hoy.");

        await using var db = await _f.CreateDbContextAsync();
        var lab = await db.Laboratorios.FindAsync(s.LaboratorioId);
        if (lab == null) return (false, "Laboratorio no encontrado.");

        var motivo = await DisponibilidadService.MotivoNoDisponibleAsync(db, lab, s.Fecha, s.HoraInicio, s.HoraFin);
        if (motivo != null) return (false, "El laboratorio no está disponible: " + motivo + ".");

        var solicitante = await db.Usuarios.FindAsync(s.SolicitanteId);
        if (solicitante == null) return (false, "Usuario no válido.");

        db.Solicitudes.Add(new Solicitud
        {
            SolicitanteId = s.SolicitanteId, LaboratorioId = s.LaboratorioId, Fecha = s.Fecha,
            HoraInicio = s.HoraInicio, HoraFin = s.HoraFin, Motivo = s.Motivo.Trim(),
            Estado = EstadoSolicitud.Pendiente, FechaCreacion = DateTime.Now
        });

        await Notificar.ARolesAsync(db, new[] { RolUsuario.Encargado, RolUsuario.Administrador },
            $"Nueva solicitud de {solicitante.NombreCompleto} para {lab.Nombre} el {s.Fecha:dd/MM/yyyy} ({s.HoraInicio:HH:mm}-{s.HoraFin:HH:mm}).",
            "/gestion-solicitudes");
        await db.SaveChangesAsync();
        return (true, null);
    }

    /// <summary>HU-06 / HU-07: solo las solicitudes del usuario autenticado.</summary>
    public async Task<List<Solicitud>> DeUsuarioAsync(int usuarioId, EstadoSolicitud? estado = null)
    {
        await using var db = await _f.CreateDbContextAsync();
        var q = db.Solicitudes.Include(s => s.Laboratorio).Include(s => s.GestionadoPor)
            .Where(s => s.SolicitanteId == usuarioId);
        if (estado.HasValue) q = q.Where(s => s.Estado == estado.Value);
        return await q.OrderByDescending(s => s.FechaCreacion).ToListAsync();
    }

    public async Task<List<Solicitud>> PendientesAsync()
    {
        await using var db = await _f.CreateDbContextAsync();
        return await db.Solicitudes.Include(s => s.Laboratorio).Include(s => s.Solicitante)
            .Where(s => s.Estado == EstadoSolicitud.Pendiente)
            .OrderBy(s => s.Fecha).ThenBy(s => s.HoraInicio).ToListAsync();
    }

    /// <summary>HU-08: aprobar o rechazar. Registra quién, cuándo y la observación; avisa al solicitante.</summary>
    public async Task<(bool Ok, string? Error)> ResolverAsync(int id, bool aprobar, string? observacion, int gestorId)
    {
        await using var db = await _f.CreateDbContextAsync();
        var s = await db.Solicitudes.Include(x => x.Laboratorio).FirstOrDefaultAsync(x => x.Id == id);
        if (s == null) return (false, "Solicitud no encontrada.");
        if (s.Estado != EstadoSolicitud.Pendiente) return (false, "La solicitud ya fue resuelta.");

        if (aprobar)
        {
            var motivo = await DisponibilidadService.MotivoNoDisponibleAsync(db, s.Laboratorio, s.Fecha, s.HoraInicio, s.HoraFin, s.Id);
            if (motivo != null) return (false, "No se puede aprobar: " + motivo + ".");
        }
        else if (string.IsNullOrWhiteSpace(observacion))
            return (false, "Indique el motivo del rechazo.");

        s.Estado = aprobar ? EstadoSolicitud.Aprobada : EstadoSolicitud.Rechazada;
        s.GestionadoPorId = gestorId;
        s.FechaGestion = DateTime.Now;
        s.ObservacionGestion = string.IsNullOrWhiteSpace(observacion) ? null : observacion.Trim();

        Notificar.AUsuario(db, s.SolicitanteId,
            $"Tu solicitud para {s.Laboratorio.Nombre} el {s.Fecha:dd/MM/yyyy} fue {(aprobar ? "aprobada" : "rechazada")}.",
            "/mis-solicitudes");
        await db.SaveChangesAsync();
        return (true, null);
    }

    /// <summary>HU-16: historial con filtros.</summary>
    public async Task<List<Solicitud>> HistorialAsync(DateOnly? desde, DateOnly? hasta, int? laboratorioId, EstadoSolicitud? estado)
    {
        await using var db = await _f.CreateDbContextAsync();
        var q = db.Solicitudes.Include(s => s.Laboratorio).Include(s => s.Solicitante).Include(s => s.GestionadoPor).AsQueryable();
        if (desde.HasValue) q = q.Where(s => s.Fecha >= desde.Value);
        if (hasta.HasValue) q = q.Where(s => s.Fecha <= hasta.Value);
        if (laboratorioId.HasValue) q = q.Where(s => s.LaboratorioId == laboratorioId.Value);
        if (estado.HasValue) q = q.Where(s => s.Estado == estado.Value);
        return await q.OrderByDescending(s => s.Fecha).ThenByDescending(s => s.HoraInicio).ToListAsync();
    }
}
