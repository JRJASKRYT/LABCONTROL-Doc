using BlazorAppLab.Data;
using BlazorAppLab.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.Services;

public class UtilizacionService
{
    private readonly IDbContextFactory<LabControlDbContext> _f;
    public UtilizacionService(IDbContextFactory<LabControlDbContext> f) => _f = f;

    /// <summary>HU-09: registra el uso de un laboratorio o equipo.</summary>
    public async Task<(bool Ok, string? Error)> RegistrarAsync(RegistroUtilizacion r)
    {
        if (r.UsuarioId <= 0) return (false, "Seleccione el usuario.");
        if (r.LaboratorioId <= 0) return (false, "Seleccione el laboratorio.");

        await using var db = await _f.CreateDbContextAsync();
        if (r.EquipoId.HasValue)
        {
            var ok = await db.Equipos.AnyAsync(e => e.Id == r.EquipoId.Value && e.LaboratorioId == r.LaboratorioId);
            if (!ok) return (false, "El equipo no pertenece al laboratorio seleccionado.");
        }

        db.Utilizaciones.Add(new RegistroUtilizacion
        {
            UsuarioId = r.UsuarioId, LaboratorioId = r.LaboratorioId, EquipoId = r.EquipoId,
            Fecha = r.Fecha, Observacion = r.Observacion?.Trim(), RegistradoPorId = r.RegistradoPorId
        });
        await db.SaveChangesAsync();
        return (true, null);
    }

    public async Task<List<RegistroUtilizacion>> ListarAsync(DateOnly? desde, DateOnly? hasta, int? laboratorioId, int top = 200)
    {
        await using var db = await _f.CreateDbContextAsync();
        var q = db.Utilizaciones.Include(u => u.Usuario).Include(u => u.Laboratorio).Include(u => u.Equipo).AsQueryable();
        if (desde.HasValue) { var d = desde.Value.ToDateTime(TimeOnly.MinValue); q = q.Where(u => u.Fecha >= d); }
        if (hasta.HasValue) { var h = hasta.Value.ToDateTime(TimeOnly.MaxValue); q = q.Where(u => u.Fecha <= h); }
        if (laboratorioId.HasValue) q = q.Where(u => u.LaboratorioId == laboratorioId.Value);
        return await q.OrderByDescending(u => u.Fecha).Take(top).ToListAsync();
    }
}
