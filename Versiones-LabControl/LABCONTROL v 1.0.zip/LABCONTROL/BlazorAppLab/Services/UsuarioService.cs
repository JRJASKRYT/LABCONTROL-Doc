using BlazorAppLab.Data;
using BlazorAppLab.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.Services;

public class UsuarioService
{
    private readonly IDbContextFactory<LabControlDbContext> _f;
    public UsuarioService(IDbContextFactory<LabControlDbContext> f) => _f = f;

    public async Task<List<Usuario>> ListarAsync(bool soloActivos = false)
    {
        await using var db = await _f.CreateDbContextAsync();
        var q = db.Usuarios.AsQueryable();
        if (soloActivos) q = q.Where(u => u.Activo);
        return await q.OrderBy(u => u.NombreCompleto).ToListAsync();
    }

    /// <summary>HU-12: crear/editar usuarios y asignar su rol. En usuarios nuevos la contraseña es obligatoria.</summary>
    public async Task<(bool Ok, string? Error)> GuardarAsync(Usuario u, string? password)
    {
        await using var db = await _f.CreateDbContextAsync();
        var usuario = u.NombreUsuario.Trim();
        var correo = u.Correo.Trim();

        if (await db.Usuarios.AnyAsync(x => x.Id != u.Id && x.NombreUsuario == usuario))
            return (false, "Ya existe un usuario con ese nombre de usuario.");
        if (await db.Usuarios.AnyAsync(x => x.Id != u.Id && x.Correo == correo))
            return (false, "Ya existe un usuario con ese correo.");

        if (u.Id == 0)
        {
            if (string.IsNullOrWhiteSpace(password) || password.Length < 6)
                return (false, "La contraseña es obligatoria (mínimo 6 caracteres).");
            db.Usuarios.Add(new Usuario
            {
                NombreCompleto = u.NombreCompleto.Trim(), NombreUsuario = usuario, Correo = correo,
                Rol = u.Rol, Activo = u.Activo, PasswordHash = PasswordHasher.Hash(password), FechaRegistro = DateTime.Now
            });
        }
        else
        {
            var a = await db.Usuarios.FindAsync(u.Id);
            if (a == null) return (false, "Usuario no encontrado.");
            a.NombreCompleto = u.NombreCompleto.Trim(); a.NombreUsuario = usuario; a.Correo = correo;
            a.Rol = u.Rol; a.Activo = u.Activo;
            if (!string.IsNullOrWhiteSpace(password))
            {
                if (password.Length < 6) return (false, "La contraseña debe tener mínimo 6 caracteres.");
                a.PasswordHash = PasswordHasher.Hash(password);
            }
        }
        await db.SaveChangesAsync();
        return (true, null);
    }
}
