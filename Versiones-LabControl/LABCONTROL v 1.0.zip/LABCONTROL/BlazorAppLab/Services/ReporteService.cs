using BlazorAppLab.Data;
using BlazorAppLab.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.Services;

public record UsoLaboratorio(string Laboratorio, int Solicitudes, double HorasReservadas, int Utilizaciones, int Incidencias);

public class ResumenIndicadores
{
    public int TotalLaboratorios { get; set; }
    public int LaboratoriosDisponibles { get; set; }
    public int TotalEquipos { get; set; }
    public int EquiposEnFalla { get; set; }
    public int SolicitudesPendientes { get; set; }
    public int SolicitudesAprobadas { get; set; }
    public int SolicitudesRechazadas { get; set; }
    public double TasaAprobacion { get; set; }
    public int IncidenciasPendientes { get; set; }
    public int IncidenciasEnAtencion { get; set; }
    public int IncidenciasResueltas { get; set; }
    public double? HorasMediasResolucion { get; set; }
    public int UtilizacionesDelMes { get; set; }
    public List<UsoLaboratorio> UsoPorLaboratorio { get; set; } = new();
    public List<(string Mes, int Cantidad)> SolicitudesPorMes { get; set; } = new();
}

public class ReporteService
{
    private readonly IDbContextFactory<LabControlDbContext> _f;
    private readonly SolicitudService _solicitudes;
    private readonly UtilizacionService _utilizacion;
    private readonly IncidenciaService _incidencias;

    public ReporteService(IDbContextFactory<LabControlDbContext> f, SolicitudService s, UtilizacionService u, IncidenciaService i)
    {
        _f = f; _solicitudes = s; _utilizacion = u; _incidencias = i;
    }

    // HU-18: los reportes salen de los mismos registros que usan las demás pantallas.
    public Task<List<Solicitud>> SolicitudesAsync(DateOnly desde, DateOnly hasta, EstadoSolicitud? estado) =>
        _solicitudes.HistorialAsync(desde, hasta, null, estado);

    public Task<List<RegistroUtilizacion>> UtilizacionAsync(DateOnly desde, DateOnly hasta) =>
        _utilizacion.ListarAsync(desde, hasta, null, 1000);

    public Task<List<Incidencia>> IncidenciasAsync(DateOnly desde, DateOnly hasta, EstadoIncidencia? estado) =>
        _incidencias.ListarAsync(null, estado, null, null, desde, hasta);

    /// <summary>HU-20: indicadores y estadísticas calculados con datos registrados.</summary>
    public async Task<ResumenIndicadores> CalcularIndicadoresAsync()
    {
        await using var db = await _f.CreateDbContextAsync();
        var r = new ResumenIndicadores
        {
            TotalLaboratorios = await db.Laboratorios.CountAsync(l => l.Estado != EstadoLaboratorio.Inactivo),
            LaboratoriosDisponibles = await db.Laboratorios.CountAsync(l => l.Estado == EstadoLaboratorio.Disponible),
            TotalEquipos = await db.Equipos.CountAsync(e => e.Estado != EstadoEquipo.DadoDeBaja),
            EquiposEnFalla = await db.Equipos.CountAsync(e => e.Estado == EstadoEquipo.EnFalla || e.Estado == EstadoEquipo.EnMantenimiento),
            SolicitudesPendientes = await db.Solicitudes.CountAsync(s => s.Estado == EstadoSolicitud.Pendiente),
            SolicitudesAprobadas = await db.Solicitudes.CountAsync(s => s.Estado == EstadoSolicitud.Aprobada),
            SolicitudesRechazadas = await db.Solicitudes.CountAsync(s => s.Estado == EstadoSolicitud.Rechazada),
            IncidenciasPendientes = await db.Incidencias.CountAsync(i => i.Estado == EstadoIncidencia.Pendiente),
            IncidenciasEnAtencion = await db.Incidencias.CountAsync(i => i.Estado == EstadoIncidencia.EnAtencion),
            IncidenciasResueltas = await db.Incidencias.CountAsync(i => i.Estado == EstadoIncidencia.Resuelta)
        };

        var resueltas = r.SolicitudesAprobadas + r.SolicitudesRechazadas;
        r.TasaAprobacion = resueltas == 0 ? 0 : Math.Round(100.0 * r.SolicitudesAprobadas / resueltas, 1);

        var inicioMes = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
        r.UtilizacionesDelMes = await db.Utilizaciones.CountAsync(u => u.Fecha >= inicioMes);

        var tiempos = await db.Incidencias
            .Where(i => i.Estado == EstadoIncidencia.Resuelta && i.FechaAtencion != null)
            .Select(i => new { i.FechaReporte, Atencion = i.FechaAtencion!.Value }).ToListAsync();
        if (tiempos.Count > 0)
            r.HorasMediasResolucion = Math.Round(tiempos.Average(t => (t.Atencion - t.FechaReporte).TotalHours), 1);

        var labs = await db.Laboratorios.Where(l => l.Estado != EstadoLaboratorio.Inactivo).OrderBy(l => l.Nombre).ToListAsync();
        var aprobadas = await db.Solicitudes.Where(s => s.Estado == EstadoSolicitud.Aprobada)
            .Select(s => new { s.LaboratorioId, s.HoraInicio, s.HoraFin }).ToListAsync();
        var usos = await db.Utilizaciones.GroupBy(u => u.LaboratorioId).Select(g => new { Id = g.Key, N = g.Count() }).ToListAsync();
        var incs = await db.Incidencias.GroupBy(i => i.LaboratorioId).Select(g => new { Id = g.Key, N = g.Count() }).ToListAsync();

        foreach (var l in labs)
        {
            var mias = aprobadas.Where(a => a.LaboratorioId == l.Id).ToList();
            r.UsoPorLaboratorio.Add(new UsoLaboratorio(
                l.Nombre, mias.Count,
                Math.Round(mias.Sum(a => (a.HoraFin - a.HoraInicio).TotalHours), 1),
                usos.FirstOrDefault(x => x.Id == l.Id)?.N ?? 0,
                incs.FirstOrDefault(x => x.Id == l.Id)?.N ?? 0));
        }

        var desde = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-5);
        var fechas = await db.Solicitudes.Where(s => s.FechaCreacion >= desde).Select(s => s.FechaCreacion).ToListAsync();
        for (int m = 0; m < 6; m++)
        {
            var mes = desde.AddMonths(m);
            r.SolicitudesPorMes.Add((mes.ToString("MMM yyyy"), fechas.Count(f => f.Year == mes.Year && f.Month == mes.Month)));
        }
        return r;
    }
}
