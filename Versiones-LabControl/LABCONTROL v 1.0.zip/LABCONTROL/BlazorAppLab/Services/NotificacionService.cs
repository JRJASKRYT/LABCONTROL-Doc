using BlazorAppLab.Data;
using BlazorAppLab.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.Services;

public class NotificacionService
{
    private readonly IDbContextFactory<LabControlDbContext> _f;
    public NotificacionService(IDbContextFactory<LabControlDbContext> f) => _f = f;

    public async Task<List<Notificacion>> DeUsuarioAsync(int usuarioId, bool soloNoLeidas = false)
    {
        await using var db = await _f.CreateDbContextAsync();
        var q = db.Notificaciones.Where(n => n.UsuarioId == usuarioId);
        if (soloNoLeidas) q = q.Where(n => !n.Leida);
        return await q.OrderByDescending(n => n.Fecha).Take(100).ToListAsync();
    }

    public async Task<int> ContarNoLeidasAsync(int usuarioId)
    {
        await using var db = await _f.CreateDbContextAsync();
        return await db.Notificaciones.CountAsync(n => n.UsuarioId == usuarioId && !n.Leida);
    }

    public async Task MarcarLeidaAsync(int id, int usuarioId)
    {
        await using var db = await _f.CreateDbContextAsync();
        var n = await db.Notificaciones.FirstOrDefaultAsync(x => x.Id == id && x.UsuarioId == usuarioId);
        if (n == null) return;
        n.Leida = true;
        await db.SaveChangesAsync();
    }

    public async Task MarcarTodasAsync(int usuarioId)
    {
        await using var db = await _f.CreateDbContextAsync();
        await db.Notificaciones.Where(n => n.UsuarioId == usuarioId && !n.Leida)
            .ExecuteUpdateAsync(s => s.SetProperty(n => n.Leida, true));
    }
}
