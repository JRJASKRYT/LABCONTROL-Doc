using BlazorAppLab.Data;
using BlazorAppLab.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.Services;

public class HorarioService
{
    private readonly IDbContextFactory<LabControlDbContext> _f;
    public HorarioService(IDbContextFactory<LabControlDbContext> f) => _f = f;

    public async Task<List<PeriodoAcademico>> PeriodosAsync()
    {
        await using var db = await _f.CreateDbContextAsync();
        return await db.Periodos.OrderByDescending(p => p.FechaInicio).ToListAsync();
    }

    public async Task<(bool Ok, string? Error)> GuardarPeriodoAsync(PeriodoAcademico p)
    {
        if (p.FechaFin < p.FechaInicio) return (false, "La fecha de fin no puede ser anterior a la de inicio.");
        await using var db = await _f.CreateDbContextAsync();
        if (p.Id == 0)
            db.Periodos.Add(new PeriodoAcademico { Nombre = p.Nombre.Trim(), FechaInicio = p.FechaInicio, FechaFin = p.FechaFin, Activo = p.Activo });
        else
        {
            var a = await db.Periodos.FindAsync(p.Id);
            if (a == null) return (false, "Periodo no encontrado.");
            a.Nombre = p.Nombre.Trim(); a.FechaInicio = p.FechaInicio; a.FechaFin = p.FechaFin; a.Activo = p.Activo;
        }
        await db.SaveChangesAsync();
        return (true, null);
    }

    /// <summary>HU-03 / HU-11: horarios filtrados por laboratorio y/o periodo.</summary>
    public async Task<List<Horario>> ListarAsync(int? laboratorioId, int? periodoId)
    {
        await using var db = await _f.CreateDbContextAsync();
        var q = db.Horarios.Include(h => h.Laboratorio).Include(h => h.Periodo).AsQueryable();
        if (laboratorioId.HasValue) q = q.Where(h => h.LaboratorioId == laboratorioId.Value);
        if (periodoId.HasValue) q = q.Where(h => h.PeriodoAcademicoId == periodoId.Value);
        return await q.OrderBy(h => h.Laboratorio.Nombre).ThenBy(h => h.Dia).ThenBy(h => h.HoraInicio).ToListAsync();
    }

    public async Task<(bool Ok, string? Error)> GuardarAsync(Horario h)
    {
        if (h.HoraFin <= h.HoraInicio) return (false, "La hora de fin debe ser posterior a la de inicio.");
        await using var db = await _f.CreateDbContextAsync();

        var choque = await db.Horarios.AnyAsync(x =>
            x.Id != h.Id && x.LaboratorioId == h.LaboratorioId && x.PeriodoAcademicoId == h.PeriodoAcademicoId &&
            x.Dia == h.Dia && x.HoraInicio < h.HoraFin && h.HoraInicio < x.HoraFin);
        if (choque) return (false, "El horario se cruza con otro ya registrado para ese laboratorio, periodo y día.");

        if (h.Id == 0)
        {
            db.Horarios.Add(new Horario
            {
                LaboratorioId = h.LaboratorioId, PeriodoAcademicoId = h.PeriodoAcademicoId, Dia = h.Dia,
                HoraInicio = h.HoraInicio, HoraFin = h.HoraFin, Actividad = h.Actividad?.Trim()
            });
        }
        else
        {
            var a = await db.Horarios.FindAsync(h.Id);
            if (a == null) return (false, "Horario no encontrado.");
            a.LaboratorioId = h.LaboratorioId; a.PeriodoAcademicoId = h.PeriodoAcademicoId; a.Dia = h.Dia;
            a.HoraInicio = h.HoraInicio; a.HoraFin = h.HoraFin; a.Actividad = h.Actividad?.Trim();
        }
        await db.SaveChangesAsync();
        return (true, null);
    }

    public async Task EliminarAsync(int id)
    {
        await using var db = await _f.CreateDbContextAsync();
        var h = await db.Horarios.FindAsync(id);
        if (h == null) return;
        db.Horarios.Remove(h);
        await db.SaveChangesAsync();
    }
}
