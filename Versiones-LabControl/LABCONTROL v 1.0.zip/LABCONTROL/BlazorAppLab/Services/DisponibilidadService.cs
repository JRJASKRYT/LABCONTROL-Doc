using BlazorAppLab.Data;
using BlazorAppLab.Models;
using Microsoft.EntityFrameworkCore;

namespace BlazorAppLab.Services;

public record DisponibilidadItem(Laboratorio Laboratorio, bool Disponible, string Motivo);

public class DisponibilidadService
{
    private readonly IDbContextFactory<LabControlDbContext> _f;
    public DisponibilidadService(IDbContextFactory<LabControlDbContext> f) => _f = f;

    /// <summary>HU-02: laboratorios disponibles / no disponibles para una fecha y franja horaria.</summary>
    public async Task<List<DisponibilidadItem>> ConsultarAsync(DateOnly fecha, TimeOnly inicio, TimeOnly fin)
    {
        await using var db = await _f.CreateDbContextAsync();
        var labs = await db.Laboratorios.Where(l => l.Estado != EstadoLaboratorio.Inactivo).OrderBy(l => l.Nombre).ToListAsync();
        var res = new List<DisponibilidadItem>();
        foreach (var l in labs)
        {
            var motivo = await MotivoNoDisponibleAsync(db, l, fecha, inicio, fin);
            res.Add(new DisponibilidadItem(l, motivo == null, motivo ?? "Libre en la franja seleccionada"));
        }
        return res;
    }

    /// <summary>
    /// Devuelve null si el laboratorio está libre; si no, el motivo. Un laboratorio NO está disponible si
    /// no está en estado "Disponible", si choca con un horario académico del periodo activo,
    /// o si ya tiene una solicitud aprobada que se cruza.
    /// </summary>
    public static async Task<string?> MotivoNoDisponibleAsync(
        LabControlDbContext db, Laboratorio lab, DateOnly fecha, TimeOnly inicio, TimeOnly fin, int? excluirSolicitudId = null)
    {
        if (lab.Estado != EstadoLaboratorio.Disponible)
            return $"Laboratorio {lab.Estado.Texto().ToLower()}";

        var dia = fecha.DayOfWeek;
        var horario = await db.Horarios.FirstOrDefaultAsync(h =>
            h.LaboratorioId == lab.Id && h.Dia == dia &&
            h.Periodo.Activo && h.Periodo.FechaInicio <= fecha && h.Periodo.FechaFin >= fecha &&
            h.HoraInicio < fin && inicio < h.HoraFin);
        if (horario != null)
            return $"Ocupado por clase ({horario.HoraInicio:HH:mm}-{horario.HoraFin:HH:mm}{(string.IsNullOrWhiteSpace(horario.Actividad) ? "" : " " + horario.Actividad)})";

        var excluir = excluirSolicitudId ?? 0;
        var reserva = await db.Solicitudes.FirstOrDefaultAsync(s =>
            s.LaboratorioId == lab.Id && s.Fecha == fecha && s.Estado == EstadoSolicitud.Aprobada &&
            s.Id != excluir && s.HoraInicio < fin && inicio < s.HoraFin);
        if (reserva != null)
            return $"Reservado ({reserva.HoraInicio:HH:mm}-{reserva.HoraFin:HH:mm})";

        return null;
    }
}
