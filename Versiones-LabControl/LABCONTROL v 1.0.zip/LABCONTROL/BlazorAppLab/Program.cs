using BlazorAppLab.Components;
using BlazorAppLab.Data;
using BlazorAppLab.Services;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// Base de datos (SQL Server). Se usa DbContextFactory porque Blazor Server comparte el circuito entre operaciones.
builder.Services.AddDbContextFactory<LabControlDbContext>(opt =>
    opt.UseSqlServer(builder.Configuration.GetConnectionString("LabControl")));

// Autenticación / autorización por roles (HU-01, HU-12)
builder.Services.AddAuthorizationCore();
builder.Services.AddCascadingAuthenticationState();
builder.Services.AddScoped<SesionAuthStateProvider>();
builder.Services.AddScoped<AuthenticationStateProvider>(sp => sp.GetRequiredService<SesionAuthStateProvider>());

// Servicios de la aplicación
builder.Services.AddScoped<AuthService>();
builder.Services.AddScoped<LaboratorioService>();
builder.Services.AddScoped<HorarioService>();
builder.Services.AddScoped<DisponibilidadService>();
builder.Services.AddScoped<SolicitudService>();
builder.Services.AddScoped<UtilizacionService>();
builder.Services.AddScoped<IncidenciaService>();
builder.Services.AddScoped<UsuarioService>();
builder.Services.AddScoped<NotificacionService>();
builder.Services.AddScoped<ReporteService>();

var app = builder.Build();

// Crea la base de datos y carga datos de ejemplo la primera vez
using (var scope = app.Services.CreateScope())
{
    var factory = scope.ServiceProvider.GetRequiredService<IDbContextFactory<LabControlDbContext>>();
    await using var db = await factory.CreateDbContextAsync();
    await DbSeeder.InicializarAsync(db);
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}
app.UseStatusCodePagesWithReExecute("/not-found", createScopeForStatusCodePages: true);
app.UseHttpsRedirection();

app.UseAntiforgery();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
